# Driver do sensor ultrassônico HC-SR04 (o mesmo do protótipo em ~/Projects/FATEC/cOillect/esp32-ultrasonic).
from machine import Pin, time_pulse_us
import time


class HCSR04:
    def __init__(self, trigger_pin, echo_pin, timeout_us=30000):
        self.trigger = Pin(trigger_pin, Pin.OUT, value=0)
        self.echo = Pin(echo_pin, Pin.IN)
        self.timeout_us = timeout_us  # 30 ms ~ 5 m

    def distance_cm(self):
        """Distância em cm, ou None se não houver eco."""
        self.trigger.value(0)
        time.sleep_us(5)
        self.trigger.value(1)
        time.sleep_us(10)
        self.trigger.value(0)
        t = time_pulse_us(self.echo, 1, self.timeout_us)
        if t < 0:
            return None
        return t * 0.0343 / 2  # som: 343 m/s, ida e volta
