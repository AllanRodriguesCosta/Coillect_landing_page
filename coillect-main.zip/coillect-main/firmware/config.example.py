# Configuração do sensor cOillect. Copie para config.py (fora do Git) e preencha.

# Wi-Fi com acesso à internet (na apresentação, o roteador do celular é o mais seguro).
WIFI_SSID = "nome-da-rede"
WIFI_SENHA = "senha-da-rede"

# Nuvem. A chave "publishable" é pública e pode ficar no aparelho.
SUPABASE_URL = "https://sshzfagqjzydgesrmiyf.supabase.co"
SUPABASE_PUBLISHABLE_KEY = "sb_publishable_..."

# Chave do dispositivo: gerada pela empresa no app (Sensores > Gerar chave). É secreta.
CHAVE_DISPOSITIVO = "cole-aqui-a-chave-de-48-caracteres"

# Pinos (iguais ao protótipo em ~/Projects/FATEC/cOillect/esp32-ultrasonic).
PINO_TRIG = 5
PINO_ECHO = 18
PINO_LED = 23

# Medição: mediana de AMOSTRAS leituras; envia uma vez a cada INTERVALO_S segundos.
# Apresentação: 5 s. Uso normal: 60 s. O servidor ignora envios com menos de 1 s
# (configuracoes.intervalo_minimo_s). O intervalo conta do início de cada ciclo.
AMOSTRAS = 7
INTERVALO_S = 5

# O LED pisca a cada medição e fica aceso fixo quando o nível informado pela nuvem chega a
# LED_ACENDE_EM. Depois disso continua fixo mesmo se o nível oscilar, e só volta a piscar na
# troca (o sensor passa a outro galão) ou se o nível cair abaixo de LED_APAGA_ABAIXO.
LED_ACENDE_EM = 90
LED_APAGA_ABAIXO = 10

# Reinicia o ESP32 sozinho se o programa travar por mais de 2 minutos.
USAR_WATCHDOG = True
