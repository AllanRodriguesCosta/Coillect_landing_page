# Firmware do sensor (MicroPython)

ESP32 + HC-SR04 na tampa do galão. Mede a distância até o óleo e envia para a nuvem; o nível
é calculado lá, com a calibração cadastrada no app.

| Arquivo | Função |
|---|---|
| `main.py` | Laço principal: Wi-Fi, mediana de 7 medições, envio, LED, watchdog |
| `hcsr04.py` | Driver do sensor ultrassônico |
| `config.example.py` | Modelo de configuração; copie para `config.py` (fora do Git) |

## Uso rápido

```bash
cp config.example.py config.py   # Wi-Fi 2,4 GHz, chave pública, chave do dispositivo
M=~/.local/share/esp-venv/bin/mpremote
$M connect /dev/ttyUSB0 cp hcsr04.py config.py main.py :
$M connect /dev/ttyUSB0 reset
$M connect /dev/ttyUSB0 repl
```

Ligações: TRIG GPIO 5, ECHO GPIO 18, LED GPIO 23, VCC 3V3.

Contrato da requisição: [docs/06-contrato-iot.md](../docs/06-contrato-iot.md).
Montagem, calibração da bombona de 5 L e roteiro de testes:
[docs/08-integracao-iot.md](../docs/08-integracao-iot.md).
