# Sensor cOillect: mede a distância até o óleo e envia para a nuvem.
# Contrato em docs/06-contrato-iot.md. O nível, os alertas e a troca são calculados na nuvem.
import json
import time

import network
import requests
from machine import Pin, WDT

import config
from hcsr04 import HCSR04

URL = config.SUPABASE_URL.rstrip("/") + "/rest/v1/rpc/registrar_leitura"
CABECALHOS = {"Content-Type": "application/json", "apikey": config.SUPABASE_PUBLISHABLE_KEY}

sensor = HCSR04(config.PINO_TRIG, config.PINO_ECHO)
led = Pin(config.PINO_LED, Pin.OUT, value=0)
wlan = network.WLAN(network.STA_IF)
cao = WDT(timeout=120000) if config.USAR_WATCHDOG else None
LED_APAGA_ABAIXO = getattr(config, "LED_APAGA_ABAIXO", 10)
cheio = False  # travado em LED fixo desde que o nível chegou a LED_ACENDE_EM
galao_cheio = None


def atualizar_cheio(galao, nivel, aguardando=False):
    """Trava o LED fixo ao chegar a LED_ACENDE_EM; destrava só na troca ou no esvaziamento.
    Só trava com o nível confirmado pela nuvem (2ª leitura seguida), para um eco falso não prender o LED."""
    global cheio, galao_cheio
    if nivel >= config.LED_ACENDE_EM and not aguardando:
        cheio, galao_cheio = True, galao
    elif cheio and (galao != galao_cheio or nivel < LED_APAGA_ABAIXO):
        cheio, galao_cheio = False, None
    return cheio


def alimentar():
    if cao:
        cao.feed()


def conectar(espera_s=20):
    if wlan.isconnected():
        return True
    wlan.active(True)
    try:
        wlan.config(pm=network.WLAN.PM_NONE)  # sem economia de energia: cada envio sai sem atraso
    except (AttributeError, ValueError):
        pass
    print("Wi-Fi: conectando a", config.WIFI_SSID)
    wlan.connect(config.WIFI_SSID, config.WIFI_SENHA)
    inicio = time.ticks_ms()
    while not wlan.isconnected() and time.ticks_diff(time.ticks_ms(), inicio) < espera_s * 1000:
        time.sleep_ms(250)
        alimentar()
    print("Wi-Fi:", "conectado " + wlan.ifconfig()[0] if wlan.isconnected() else "sem conexão")
    if wlan.isconnected():
        time.sleep_ms(1000)  # o DNS ainda não responde logo após conectar (erro -202 no 1º envio)
    return wlan.isconnected()


def medir():
    """Mediana das amostras válidas (2 a 400 cm). None se a maioria falhar."""
    amostras = []
    for _ in range(config.AMOSTRAS):
        d = sensor.distance_cm()
        if d is not None and 2 <= d <= 400:
            amostras.append(d)
        time.sleep_ms(60)
    if len(amostras) <= config.AMOSTRAS // 2:
        return None
    amostras.sort()
    return amostras[len(amostras) // 2]


def enviar(distancia_cm):
    corpo = json.dumps({"chave": config.CHAVE_DISPOSITIVO, "distancia_cm": round(distancia_cm, 1)})
    try:
        r = requests.post(URL, headers=CABECALHOS, data=corpo, timeout=10)
    except TypeError:  # versões antigas do requests sem timeout
        r = requests.post(URL, headers=CABECALHOS, data=corpo)
    try:
        return r.status_code, r.json()
    finally:
        r.close()


def ciclo():
    if not cheio:
        led.value(1)  # pisca enquanto mede
    d = medir()
    if not cheio:
        led.value(0)
    if d is None:
        print("Sensor: sem eco estável; confira a fixação na tampa")
        return
    if not conectar():
        return
    try:
        status, resposta = enviar(d)
    except Exception as erro:  # falha de rede: tenta de novo no próximo ciclo
        print("Envio falhou:", erro)
        if not wlan.isconnected():  # só reconecta do zero se o Wi-Fi caiu de fato
            wlan.disconnect()
        return
    if status == 200 and resposta.get("ignorada"):
        print("%.1f cm: ignorada (intervalo mínimo de %s s)" % (d, resposta.get("intervalo_minimo_s")))
    elif status == 200 and resposta.get("vinculado"):
        nivel = resposta["nivel_pct"]
        led.value(1 if atualizar_cheio(resposta["galao"], nivel, resposta.get("aguardando_confirmacao")) else 0)
        print("%.1f cm: %s em %s%% (%s L)" % (d, resposta["galao"], nivel, resposta["litros"]))
    elif status == 200:
        print("%.1f cm: sensor sem galão vinculado (vincule no app, em Sensores)" % d)
    elif status == 403:
        print("Chave do dispositivo inválida: grave a chave nova no config.py. Pausando 5 min.")
        for _ in range(60):
            time.sleep(5)
            alimentar()
    else:
        print("Resposta %s: %s" % (status, resposta.get("message", resposta)))


print("cOillect: sensor iniciado, envio a cada", config.INTERVALO_S, "s")
while True:
    inicio = time.ticks_ms()
    alimentar()
    try:
        ciclo()
    except Exception as erro:
        print("Erro inesperado:", erro)
    # O intervalo conta do início do ciclo: o tempo de medir e enviar sai da espera.
    resta = config.INTERVALO_S * 1000 - time.ticks_diff(time.ticks_ms(), inicio)
    time.sleep_ms(max(resta, 0))
