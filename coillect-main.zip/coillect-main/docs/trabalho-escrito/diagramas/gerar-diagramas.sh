#!/usr/bin/env bash
# Converte os diagramas .mmd em PNG para o documento (usa o Chromium instalado no sistema).
# Uso: ./gerar-diagramas.sh   (CHROMIUM=/caminho/do/chromium para outro navegador)
set -e
cd "$(dirname "$0")"
echo "{\"executablePath\":\"${CHROMIUM:-/usr/lib/chromium/chromium}\",\"args\":[\"--no-sandbox\"]}" > /tmp/coillect-puppeteer.json
for f in *.mmd; do
  PUPPETEER_SKIP_DOWNLOAD=1 npx -y @mermaid-js/mermaid-cli@11.4.2 -q -p /tmp/coillect-puppeteer.json \
    -c config.json -b white -s 3 -i "$f" -o "../figuras/${f%.mmd}.png"
done
echo "Diagramas gerados em figuras/."
