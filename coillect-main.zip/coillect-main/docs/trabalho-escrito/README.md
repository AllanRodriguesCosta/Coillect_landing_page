# Trabalho escrito (ABNT)

Documento do Projeto Integrador entregue em 14/11/2026:
[`cOillect_Trabalho_Escrito_ABNT.pdf`](cOillect_Trabalho_Escrito_ABNT.pdf) (e o `.docx` editável).

## Como alterar

O `.docx` e o `.pdf` são gerados; não edite à mão. Altere os fontes e gere de novo:

| Arquivo | Conteúdo |
|---|---|
| `conteudo.js` | Texto, quadros, figuras, resumo, abstract, siglas e referências |
| `meta.js` | Capa e folha de rosto (instituição, curso, autores, professor) |
| `abnt.js` | Formatação ABNT (margens, fonte, títulos, listas, sumário) |
| `diagramas/*.mmd` | Diagramas em Mermaid; `diagramas/gerar-diagramas.sh` gera os PNG |
| `figuras/` | Imagens usadas no documento (diagramas e telas do app) |

```bash
cd docs/trabalho-escrito
./gerar.sh                      # gera .docx e .pdf com sumário e listas paginados
diagramas/gerar-diagramas.sh    # só se mudar algum diagrama
```

Requer Node.js, LibreOffice (`soffice`) e poppler (`pdftotext`). No texto, `{fig:id}` e
`{quadro:id}` viram "Figura N" e "Quadro N" automaticamente.
