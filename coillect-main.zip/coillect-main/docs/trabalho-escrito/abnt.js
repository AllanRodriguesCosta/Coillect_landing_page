// Gerador de trabalho acadêmico no formato ABNT (NBR 14724) com docx-js.
// Adaptado do gerador do trabalho de PLN: build(spec, saida.docx, paginas.json).
// As páginas do sumário e das listas vêm de uma passada anterior (paginar.py).
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, AlignmentType, Header, PageNumber, TabStopType,
  Table, TableRow, TableCell, WidthType, BorderStyle, ImageRun, PageBreak, VerticalAlign,
} = require("docx");

const FONTE = "Arial";
const LARGURA = 11906 - 1701 - 1134; // largura útil em DXA (A4, margens 3 cm e 2 cm)
const LINHA = 360; // espaçamento 1,5
const CM_PX = 37.8; // 96 dpi

// **negrito** e *itálico* dentro das strings
function runs(texto, o = {}) {
  return texto.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/).filter(Boolean).map(s => {
    if (s.startsWith("**")) return new TextRun({ text: s.slice(2, -2), bold: true, ...o });
    if (s.startsWith("*")) return new TextRun({ text: s.slice(1, -1), italics: true, ...o });
    return new TextRun({ text: s, ...o });
  });
}
const P = (texto, o = {}, r = {}) => new Paragraph({ children: runs(texto, r), ...o });
const vazias = (n = 1) => Array.from({ length: Math.max(0, n) }, () => new Paragraph({ children: [], spacing: { line: LINHA } }));
const centro = (texto, o = {}, r = {}) => P(texto, { alignment: AlignmentType.CENTER, spacing: { line: LINHA }, ...o }, r);
const quebra = () => new Paragraph({ children: [new PageBreak()] });
const pequeno = { size: 20 };

// ---------- numeração de seções, figuras e quadros ----------

function numerar(blocos) {
  const n = [0, 0, 0], cont = { fig: 0, quadro: 0 }, rotulos = {};
  for (const b of blocos) {
    const nivel = b.h1 ? 0 : b.h2 ? 1 : b.h3 ? 2 : -1;
    if (nivel >= 0 && !b.semNumero) {
      n[nivel]++; for (let i = nivel + 1; i < 3; i++) n[i] = 0;
      b.n = n.slice(0, nivel + 1).join(".");
    }
    if (b.fig) { b.fig.num = ++cont.fig; if (b.fig.id) rotulos[`fig:${b.fig.id}`] = `Figura ${b.fig.num}`; }
    if (b.quadro) { b.quadro.num = ++cont.quadro; if (b.quadro.id) rotulos[`quadro:${b.quadro.id}`] = `Quadro ${b.quadro.num}`; }
  }
  return rotulos;
}

// troca {fig:id} e {quadro:id} pelo rótulo numerado
function referenciar(blocos, rotulos) {
  const r = s => s.replace(/\{((?:fig|quadro):[\w-]+)\}/g, (m, k) => {
    if (!rotulos[k]) throw new Error("referência inexistente: " + m);
    return rotulos[k];
  });
  for (const b of blocos) {
    if (b.p) b.p = r(b.p);
    if (b.li) b.li = b.li.map(r);
  }
}

const tituloSecao = b => (b.n ? `${b.n} ` : "") + (b.h1 || b.h2 || b.h3);
const legendaFig = f => `Figura ${f.num} – ${f.titulo}`;
const legendaQuadro = q => `Quadro ${q.num} – ${q.titulo}`;

// ---------- elementos textuais ----------

function titulo(b) {
  if (b.h1) return new Paragraph({
    children: [new TextRun({ text: tituloSecao(b).toUpperCase(), bold: true })],
    pageBreakBefore: true, alignment: b.semNumero ? AlignmentType.CENTER : AlignmentType.LEFT,
    spacing: { line: LINHA, after: LINHA }, keepNext: true, outlineLevel: 0,
  });
  return new Paragraph({
    children: [new TextRun({ text: tituloSecao(b), bold: !!b.h2, italics: !!b.h3 })],
    spacing: { line: LINHA, before: LINHA, after: LINHA }, keepNext: true, outlineLevel: b.h2 ? 1 : 2,
  });
}

const paragrafo = texto => P(texto, { alignment: AlignmentType.JUSTIFIED, indent: { firstLine: 709 }, spacing: { line: LINHA } });

function alineas(itens) {
  return itens.map((t, i) => P(`${String.fromCharCode(97 + i)}) ${t}`, {
    alignment: AlignmentType.JUSTIFIED, spacing: { line: LINHA },
    indent: { left: 709 + 340, hanging: 340 },
  }));
}

const legenda = texto => P(texto, { alignment: AlignmentType.CENTER, spacing: { before: 240, after: 60 }, keepNext: true }, pequeno);
const fonte = texto => P(texto || "Fonte: elaborado pelos autores (2026).", { alignment: AlignmentType.CENTER, spacing: { before: 60, after: 240 } }, pequeno);

function quadro(q) {
  const linha = { style: BorderStyle.SINGLE, size: 6, color: "000000" };
  const bordas = { top: linha, bottom: linha, left: linha, right: linha };
  const total = q.larguras.reduce((a, b) => a + b, 0);
  const larguras = q.larguras.map(l => Math.round(l * LARGURA / total));
  // keepNext em todas as linhas: o quadro não se divide e fica junto da fonte
  const linhaTabela = (celulas, cabecalho, ultima) => new TableRow({
    tableHeader: cabecalho, cantSplit: true,
    children: celulas.map((c, j) => new TableCell({
      width: { size: larguras[j], type: WidthType.DXA }, borders: bordas,
      verticalAlign: VerticalAlign.CENTER,
      shading: cabecalho ? { fill: "E7E7E7" } : undefined,
      margins: { top: 50, bottom: 50, left: 90, right: 90 },
      children: [P(String(c), { alignment: cabecalho ? AlignmentType.CENTER : AlignmentType.LEFT, keepNext: true }, { ...pequeno, bold: cabecalho })],
    })),
  });
  return [
    legenda(legendaQuadro(q)),
    new Table({
      width: { size: LARGURA, type: WidthType.DXA }, columnWidths: larguras, alignment: AlignmentType.CENTER,
      rows: [linhaTabela(q.cab, true, false), ...q.linhas.map((l, i) => linhaTabela(l, false, i === q.linhas.length - 1))],
    }),
    fonte(q.fonte),
  ];
}

function figura(f) {
  const buf = fs.readFileSync(f.caminho);
  const w = buf.readUInt32BE(16), h = buf.readUInt32BE(20);
  let largura = (f.cm || 15) * CM_PX, altura = largura * h / w;
  const maxAltura = (f.maxAlturaCm || 20) * CM_PX;
  if (altura > maxAltura) { largura *= maxAltura / altura; altura = maxAltura; }
  return [
    legenda(legendaFig(f)),
    new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, children: [
      new ImageRun({ type: "png", data: buf, transformation: { width: Math.round(largura), height: Math.round(altura) } }),
    ] }),
    fonte(f.fonte),
  ];
}

// equação centralizada com o número entre parênteses à direita
let numEquacao = 0;
const equacao = texto => new Paragraph({
  tabStops: [{ type: TabStopType.CENTER, position: LARGURA / 2 }, { type: TabStopType.RIGHT, position: LARGURA }],
  spacing: { line: LINHA, before: 120, after: 120 },
  children: [new TextRun(`\t${texto}\t(${++numEquacao})`)],
});
const referencia = texto => P(texto, { alignment: AlignmentType.LEFT, spacing: { line: 240, after: 240 } });

function renderizar(blocos) {
  const out = [];
  for (const b of blocos) {
    if (b.h1 || b.h2 || b.h3) out.push(titulo(b));
    else if (b.p) out.push(paragrafo(b.p));
    else if (b.li) out.push(...alineas(b.li));
    else if (b.quadro) out.push(...quadro(b.quadro));
    else if (b.fig) out.push(...figura(b.fig));
    else if (b.eq) out.push(equacao(b.eq));
    else if (b.refs) out.push(...b.refs.map(referencia));
  }
  return out;
}

// ---------- elementos pré-textuais ----------

function capa(s) {
  return [
    centro(s.instituicao, {}, { bold: true }),
    centro(s.curso, {}, { bold: true }),
    ...vazias(3),
    ...s.autores.map(a => centro(a.toUpperCase())),
    ...vazias(6),
    centro(`${s.titulo}:`, {}, { bold: true, size: 32 }),
    ...s.subtitulo.split("\n").map(l => centro(l)),
    ...vazias(14 - s.autores.length),
    centro(s.cidade),
    centro(s.ano),
  ];
}

function folhaRosto(s) {
  return [
    quebra(),
    ...s.autores.map(a => centro(a.toUpperCase())),
    ...vazias(6),
    centro(`${s.titulo}:`, {}, { bold: true, size: 32 }),
    ...s.subtitulo.split("\n").map(l => centro(l)),
    ...vazias(3),
    P(s.natureza, { alignment: AlignmentType.JUSTIFIED, indent: { left: 4536 }, spacing: { line: 240, after: 240 } }, pequeno),
    P(s.orientador, { alignment: AlignmentType.LEFT, indent: { left: 4536 }, spacing: { line: 240 } }, pequeno),
    ...vazias(11 - s.autores.length),
    centro(s.cidade),
    centro(s.ano),
  ];
}

function resumo(rotulo, texto, rotuloChave, chaves) {
  return [
    quebra(),
    centro(rotulo, { spacing: { line: LINHA, after: LINHA } }, { bold: true }),
    P(texto, { alignment: AlignmentType.JUSTIFIED, spacing: { line: LINHA, after: LINHA } }),
    P(`**${rotuloChave}:** ${chaves}`, { alignment: AlignmentType.JUSTIFIED, spacing: { line: LINHA } }),
  ];
}

// linha com pontilhado até o número da página
function entrada(texto, pagina, o = {}) {
  return new Paragraph({
    tabStops: [{ type: TabStopType.RIGHT, position: LARGURA, leader: "dot" }],
    spacing: { line: LINHA }, indent: o.recuo ? { left: o.recuo, hanging: o.recuo } : undefined,
    children: [new TextRun({ text: texto, bold: !!o.negrito }), new TextRun({ text: `\t${pagina ?? 0}`, bold: !!o.negrito })],
  });
}

function lista(rotulo, itens, paginas) {
  return [
    quebra(),
    centro(rotulo, { spacing: { line: LINHA, after: LINHA } }, { bold: true }),
    ...itens.map(t => entrada(t, paginas && paginas[t.split(" – ")[0]], { recuo: 1300 })),
  ];
}

function siglas(lista) {
  return [
    quebra(),
    centro("LISTA DE ABREVIATURAS E SIGLAS", { spacing: { line: LINHA, after: LINHA } }, { bold: true }),
    ...lista.map(([s, d]) => new Paragraph({
      tabStops: [{ type: TabStopType.LEFT, position: 1700 }], spacing: { line: LINHA },
      indent: { left: 1700, hanging: 1700 },
      children: [new TextRun(s), new TextRun(`\t${d}`)],
    })),
  ];
}

function sumario(blocos, paginas) {
  return [
    quebra(),
    centro("SUMÁRIO", { spacing: { line: LINHA, after: LINHA } }, { bold: true }),
    ...blocos.filter(b => b.h1 || b.h2 || b.h3).map(b => {
      const texto = b.h1 ? tituloSecao(b).toUpperCase() : tituloSecao(b);
      return entrada(texto, paginas && paginas[tituloSecao(b)], { negrito: !b.h3 }); // mesmo destaque do texto
    }),
  ];
}

async function build(spec, saida, arquivoPaginas) {
  const paginas = arquivoPaginas && fs.existsSync(arquivoPaginas) ? JSON.parse(fs.readFileSync(arquivoPaginas)) : null;
  const blocos = spec.blocos;
  referenciar(blocos, numerar(blocos));
  const figuras = blocos.filter(b => b.fig).map(b => legendaFig(b.fig));
  const quadros = blocos.filter(b => b.quadro).map(b => legendaQuadro(b.quadro));

  const pagina = { size: { width: 11906, height: 16838 }, margin: { top: 1701, left: 1701, bottom: 1134, right: 1134, header: 1134 } };
  const doc = new Document({
    creator: spec.autores.join(", "), title: `${spec.titulo}: ${spec.subtitulo.replace("\n", " ")}`,
    styles: { default: { document: { run: { font: FONTE, size: 24 } } } },
    sections: [
      { properties: { page: pagina }, children: [
        ...capa(spec), ...folhaRosto(spec),
        ...resumo("RESUMO", spec.resumo, "Palavras-chave", spec.palavrasChave),
        ...resumo("ABSTRACT", spec.abstract, "Keywords", spec.keywords),
        ...lista("LISTA DE FIGURAS", figuras, paginas),
        ...lista("LISTA DE QUADROS", quadros, paginas),
        ...siglas(spec.siglas),
        ...sumario(blocos, paginas),
      ] },
      {
        properties: { page: { ...pagina, pageNumbers: { start: (paginas && paginas.__inicio) || 1 } } },
        headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ children: [PageNumber.CURRENT], size: 20 })] })] }) },
        children: renderizar(blocos),
      },
    ],
  });
  fs.writeFileSync(saida, await Packer.toBuffer(doc));
  // o que a paginação deve localizar no PDF: títulos (linha inteira) e legendas (início da linha)
  fs.writeFileSync(saida + ".alvos.json", JSON.stringify([
    ...blocos.filter(b => b.h1 || b.h2 || b.h3).map(b => ({ chave: tituloSecao(b), linha: b.h1 ? tituloSecao(b).toUpperCase() : tituloSecao(b) })),
    ...[...figuras, ...quadros].map(l => ({ chave: l.split(" – ")[0], prefixo: l.split(" – ")[0] + " – " })),
  ]));
}

module.exports = { build };
