// Dados da capa e da folha de rosto.
module.exports = {
  instituicao: "FACULDADE DE TECNOLOGIA DE COTIA – FATEC COTIA",
  curso: "CURSO SUPERIOR DE TECNOLOGIA EM DESENVOLVIMENTO DE SOFTWARE MULTIPLATAFORMA",
  autores: ["Allan Rodrigues", "Daniele Sismon", "Felippi Oliveira", "João Paulo de Amorim", "Leonardo Ked"],
  titulo: "cOillect",
  subtitulo: "plataforma de coleta de óleo de cozinha usado\ncom monitoramento por sensor IoT",
  natureza: "Projeto Integrador apresentado à disciplina de Laboratório de Desenvolvimento Multiplataforma, do 6º semestre do Curso Superior de Tecnologia em Desenvolvimento de Software Multiplataforma da Faculdade de Tecnologia de Cotia (Fatec Cotia), como requisito parcial de avaliação da disciplina.",
  orientador: "Professor: Junio Cesar dos Santos Gonçalves",
  cidade: "COTIA – SP",
  ano: "2026",
};
