#!/usr/bin/env bash
# Gera o trabalho escrito (ABNT) em .docx e .pdf, com sumário e listas paginados.
# Uso: ./gerar.sh        Requer Node.js, LibreOffice (soffice) e poppler (pdftotext).
# Texto em conteudo.js; capa e folha de rosto em meta.js; diagramas em diagramas/.
set -e
cd "$(dirname "$0")"
[ -d node_modules ] || npm install --no-audit --no-fund
N=cOillect_Trabalho_Escrito_ABNT
rm -f $N.paginas.json
for passada in 1 2 3; do   # o sumário ocupa páginas: repete até os números estabilizarem
  node conteudo.js $N.docx $N.paginas.json
  python3 -I paginar.py $N.docx $N.paginas.json
done
rm -f $N.docx.alvos.json
echo "Pronto: $N.docx e $N.pdf"
