# Uso: python3 -I paginar.py documento.docx paginas.json
# Converte o .docx para PDF (LibreOffice) e anota em que página aparece cada título e
# cada legenda. A capa não é contada, então a página exibida = índice físico (base 0).
import sys, json, subprocess, os, re

docx, saida = sys.argv[1], sys.argv[2]
pasta = os.path.dirname(os.path.abspath(docx))
subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", pasta, docx], check=True, capture_output=True)
pdf = docx[:-5] + ".pdf"
paginas = subprocess.run(["pdftotext", "-layout", pdf, "-"], capture_output=True, text=True).stdout.split("\f")
alvos = json.load(open(docx + ".alvos.json"))
norm = lambda s: re.sub(r"\s+", " ", s).strip()

res = {}
titulos = [a for a in alvos if "linha" in a]
legendas = [a for a in alvos if "prefixo" in a]
for a in titulos:
    for i, pg in enumerate(paginas):
        if any(norm(l) == a["linha"] for l in pg.splitlines()):
            res[a["chave"]] = i
            break
    else:
        print("NÃO ENCONTRADO:", a["linha"])
inicio = min(res.values())
# legendas só a partir do texto, para não confundir com as listas pré-textuais
for a in legendas:
    for i, pg in enumerate(paginas[inicio:], start=inicio):
        if any(norm(l).startswith(a["prefixo"]) for l in pg.splitlines()):
            res[a["chave"]] = i
            break
    else:
        print("NÃO ENCONTRADO:", a["prefixo"])
res["__inicio"] = inicio
json.dump(res, open(saida, "w"), ensure_ascii=False)
print("páginas:", len([p for p in paginas if p.strip()]), "| texto começa na página", inicio)
