# Casos de uso e fluxos

## Diagrama de casos de uso

```mermaid
flowchart LR
  cliente([Cliente])
  empresa([Empresa])
  sensor([Sensor ESP32])

  subgraph cOillect
    uc1[UC01 Cadastrar conta e local]
    uc2[UC02 Solicitar galão]
    uc3[UC03 Acompanhar nível e alertas]
    uc4[UC04 Solicitar coleta antecipada]
    uc5[UC05 Enviar leitura]
    uc6[UC06 Atender entrega]
    uc7[UC07 Atender coleta e trocar galão]
    uc8[UC08 Gerenciar galões e sensores]
    uc9[UC09 Acompanhar indicadores]
  end

  cliente --- uc1 & uc2 & uc3 & uc4
  sensor --- uc5
  empresa --- uc6 & uc7 & uc8 & uc9
```

## Descrição

### UC01 — Cadastrar conta e local
**Ator:** Cliente. **Fluxo:** informa nome, telefone, e-mail e senha → acessa o app → cadastra o local (condomínio, restaurante, lanchonete ou outro) com endereço. **Regra:** RN01.

### UC02 — Solicitar galão
**Ator:** Cliente. **Pré-condição:** local cadastrado. **Fluxo:** toca em "Solicitar galão" e pode deixar uma observação → a solicitação fica *pendente* para a empresa. **Exceção:** já existe pedido de entrega em aberto (RN05).

### UC03 — Acompanhar nível e alertas
**Ator:** Cliente. **Fluxo:** o painel mostra cada galão com nível, volume e horário da última leitura; atualiza sozinho a cada leitura; alertas de 70% e 90% aparecem em destaque e podem ser marcados como lidos.

### UC04 — Solicitar coleta antecipada
**Ator:** Cliente. **Fluxo:** escolhe um galão instalado e solicita a coleta antes dos 90%. **Exceção:** já existe coleta em aberto para o galão.

### UC05 — Enviar leitura
**Ator:** Sensor. **Fluxo:** mede a distância até o óleo → envia à nuvem com sua chave → o sistema calcula nível e volume (RN03), atualiza o galão e, ao cruzar 70% ou 90%, gera alertas e a coleta automática (RF10, RF11). **Exceção:** chave inválida → recusa (HTTP 403).

### UC06 — Atender entrega
**Ator:** Empresa. **Fluxo:** vê a solicitação → agenda data → no local, escolhe o galão do estoque e conclui → o galão passa a *instalado* no local.

### UC07 — Atender coleta e trocar galão
**Ator:** Empresa. **Fluxo:** recebe a coleta (automática ou do cliente) → agenda → na troca, escolhe o galão vazio e conclui → o galão cheio vai para *reciclagem*, o vazio é instalado, o sensor é transferido, os alertas são resolvidos e a reciclagem é registrada (RN07–RN09).

### UC08 — Gerenciar galões e sensores
**Ator:** Empresa. **Fluxo:** cadastra galões e capacidade, calibra as distâncias de vazio e cheio, cadastra dispositivos, gera a chave do sensor e libera para o estoque os galões higienizados.

### UC09 — Acompanhar indicadores
**Ator:** Empresa. **Fluxo:** painel com galões instalados, galões acima de 70%, coletas pendentes, litros reciclados e receita estimada.

## Ciclo de vida do galão

```mermaid
stateDiagram-v2
  [*] --> estoque: cadastro
  estoque --> instalado: entrega ou troca
  instalado --> reciclagem: troca (galão cheio retirado)
  reciclagem --> estoque: higienizado e liberado
```

## Ciclo de vida da solicitação

```mermaid
stateDiagram-v2
  [*] --> pendente: cliente solicita ou nível ≥ 90%
  pendente --> agendada: empresa agenda
  agendada --> agendada: reagendamento
  pendente --> concluida: empresa conclui
  agendada --> concluida: empresa conclui
  pendente --> cancelada
  agendada --> cancelada
  concluida --> [*]
  cancelada --> [*]
```

## Sequência: do sensor à troca do galão

```mermaid
sequenceDiagram
  participant S as Sensor ESP32
  participant DB as Supabase
  participant C as App Cliente
  participant E as App Empresa

  loop a cada intervalo
    S->>DB: registrar_leitura(chave, distância)
    DB-->>S: nível %, litros
    DB-->>C: nível atualizado (tempo real)
    DB-->>E: nível atualizado (tempo real)
  end
  Note over DB: nível ≥ 70% → alerta de atenção
  DB-->>C: alerta "galão enchendo"
  Note over DB: nível ≥ 90% → alerta de coleta + solicitação automática
  DB-->>C: alerta "coleta solicitada"
  DB-->>E: nova solicitação de coleta
  E->>DB: agendar_solicitacao(data)
  DB-->>C: coleta agendada
  E->>DB: concluir_coleta(galão vazio)
  Note over DB: galão cheio → reciclagem<br/>sensor → galão vazio<br/>reciclagem registrada
  DB-->>C: galão novo em 0%
```
