# Ambiente e testes

## Pré-requisitos

- Node.js 20 ou superior
- Supabase CLI via `npx supabase@2.122.0`, autenticado com `npx supabase login --token <token>`
- Projeto ligado: `npx supabase link --project-ref sshzfagqjzydgesrmiyf`

## Banco de dados

```bash
npx supabase db push --linked      # aplica as migrations pendentes
npx supabase db advisors --linked  # verificação de segurança e desempenho
```

Para alterar o esquema, crie uma nova migration em `supabase/migrations/` (nunca edite
uma já aplicada).

## Dados de demonstração

```bash
node tools/seed/demo.mjs > seed.txt
```

Apaga os dados operacionais e recria:

- conta **Empresa** `empresa@coillect.test` e conta **Cliente** `sindico@coillect.test`
  (senhas novas a cada execução, exibidas na saída; podem ser fixadas com
  `DEMO_SENHA_EMPRESA` e `DEMO_SENHA_CLIENTE`);
- local *Residencial Aurora*, galão G-001 instalado e G-002 a G-004 em estoque;
- dispositivo `ESP32-01` associado ao G-001, com chave nova.

`seed.txt` contém senhas e a chave do dispositivo: não versione.

## Teste de ponta a ponta

```bash
node tools/seed/demo.mjs > seed.txt && node tools/teste-fluxo.mjs seed.txt
```

Usa a API pública como o app e o sensor usam e verifica 20 comportamentos: cálculo de
nível, alertas de 70% e 90%, coleta automática, agendamento, troca do galão,
transferência do sensor, desfazer troca, litros informados, registro da reciclagem, cancelamento visível ao cliente e as regras de acesso entre perfis.

## Aplicativo

```bash
cd app && cp .env.example .env.local && npm install && npm run dev
```

Detalhes em [`app/README.md`](../app/README.md).

### Publicação (Vercel)

Cada push na `main` publica o app em https://coillect.vercel.app (pasta `app/`, variáveis
`VITE_SUPABASE_URL` e `VITE_SUPABASE_PUBLISHABLE_KEY` configuradas no projeto da Vercel).
No plano Hobby, a Vercel só publica commits cujo autor é a conta dona do projeto
(`DarchLord`). Neste repositório o autor é configurado localmente:

```bash
git config --local user.name DarchLord
git config --local user.email 134175050+DarchLord@users.noreply.github.com
```

Commits com outro e-mail aparecem como "Deployment was blocked" no GitHub.

## Cenário de apresentação

```bash
node tools/seed/apresentacao.mjs > apresentacao.txt
```

Recria o mesmo cenário do protótipo: empresa e 4 clientes (Residencial Aurora, Restaurante
Sabor da Granja, Lanchonete Ponto 7, Condomínio Vila Verde), galões em 58%, 91%, 74% (sensor
sem sinal) e 19%, pedidos em aberto, alertas, 9 dias de leituras, trocas antigas e uma
mensagem de cliente. A saída traz as senhas (fixe com `DEMO_SENHA`) e a chave do ESP32-01.
O teste de ponta a ponta usa outro seed (`demo.mjs`); rode a apresentação depois dele.

## Simulador do sensor

```bash
node tools/simulador/simulador.mjs --chave <CHAVE_ESP32-01> --distancia 15   # uma leitura
node tools/simulador/simulador.mjs --chave <CHAVE_ESP32-01> --encher         # despeja aos poucos
```

Usa o mesmo endpoint e a mesma chave do ESP32: serve para testar e como plano B na
apresentação.

## Design: Impeccable

O projeto usa a skill [Impeccable](https://impeccable.style) (v4.8.0) no Claude Code, em
`.claude/skills/impeccable`. O motor do detector (binário) e os hooks não são
versionados; depois de clonar, rode na raiz do repositório:

```bash
npx impeccable@4.8.0 install --project --providers=claude --yes
```

Em uma sessão nova do Claude Code: `/impeccable init` (uma vez), depois `/critique`,
`/audit`, `/polish` etc. Verificação sem IA: `npx impeccable@4.8.0 detect docs/prototipo`.
