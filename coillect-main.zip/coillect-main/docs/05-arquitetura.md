# Arquitetura

```mermaid
flowchart LR
  subgraph Local do cliente
    galao[(Galão)] --- sensor[ESP32 + HC-SR04]
  end

  subgraph Nuvem
    subgraph Supabase
      api[API REST<br/>PostgREST]
      auth[Auth]
      db[(PostgreSQL<br/>RLS + funções)]
      rt[Realtime]
    end
    vercel[Vercel<br/>app PWA]
  end

  cel1[Celular do cliente]
  cel2[Celular da empresa]

  sensor -- HTTPS: registrar_leitura --> api
  api --> db
  db --> rt
  vercel -- entrega o app --> cel1 & cel2
  cel1 & cel2 -- login --> auth
  cel1 & cel2 -- consultas e ações --> api
  rt -- nível e alertas em tempo real --> cel1 & cel2
```

## Componentes

| Componente | Tecnologia | Responsabilidade |
|---|---|---|
| Sensor | ESP32, MicroPython, HC-SR04 | Medir a distância até a superfície do óleo e enviar à nuvem |
| Banco e regras | Supabase PostgreSQL | Dados, cálculo de nível, alertas, fluxo de solicitações, segurança por linha |
| API | Supabase PostgREST | Expor tabelas e funções via HTTPS |
| Autenticação | Supabase Auth | Cadastro, login e sessão (JWT) |
| Tempo real | Supabase Realtime | Enviar mudanças de nível, alertas e solicitações aos apps |
| Aplicativo | React + Vite, PWA | Interface mobile-first dos perfis Cliente e Empresa |
| Hospedagem | Vercel | Publicar o app com deploy automático a partir do GitHub |
| Versionamento | GitHub | Código, migrations e documentação |

## Decisões de projeto

As regras de negócio ficam no banco (funções e gatilhos), não no aplicativo nem no
firmware. Assim, o sensor, o simulador e os dois perfis do app seguem as mesmas regras,
e o firmware só precisa medir e enviar a distância. Detalhes em
[01-decisoes.md](01-decisoes.md).

## Ambientes

| Item | Valor |
|---|---|
| Projeto Supabase | `sshzfagqjzydgesrmiyf` (região us-east-1) |
| URL da API | `https://sshzfagqjzydgesrmiyf.supabase.co` |
| App | https://coillect.vercel.app (Vercel, deploy automático a cada push na `main`, pasta `app/`) |
