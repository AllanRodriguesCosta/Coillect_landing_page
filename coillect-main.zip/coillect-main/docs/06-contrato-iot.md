# Contrato de comunicação do sensor

Especificação para o firmware do ESP32 enviar leituras à nuvem. Firmware de referência em
[`firmware/`](../firmware); guia de montagem, calibração e testes em
[08-integracao-iot.md](08-integracao-iot.md).

## Requisição

```
POST https://sshzfagqjzydgesrmiyf.supabase.co/rest/v1/rpc/registrar_leitura
Content-Type: application/json
apikey: <SUPABASE_PUBLISHABLE_KEY>

{"chave": "<CHAVE_DO_DISPOSITIVO>", "distancia_cm": 23.4}
```

| Campo | Tipo | Descrição |
|---|---|---|
| `apikey` (cabeçalho) | texto | Chave pública do projeto (`sb_publishable_…`). Pode ficar no firmware. |
| `chave` | texto (48 hex) | Chave secreta do dispositivo, gerada pela empresa no app (Sensores > Gerar chave). Uma por sensor. |
| `distancia_cm` | número | Distância do sensor até a superfície do óleo, em cm, com 1 casa decimal. Faixa aceita: 0 a 400. |

O firmware envia **apenas a distância**. O nível é calculado na nuvem com a calibração do
galão (distância vazio e distância cheio), então trocar de galão ou recalibrar não exige
regravar o ESP32.

## Regras aplicadas pela nuvem

| Regra | Efeito para o firmware |
|---|---|
| **Intervalo mínimo** de 1 s entre leituras do mesmo sensor (`configuracoes.intervalo_minimo_s`; o padrão do banco é 4 s, reduzido para 1 s em 06/11 porque o tempo de cada envio HTTPS varia de 0,5 a 2,5 s) | Leituras mais próximas voltam com `"ignorada": true` e não são gravadas. Envie a cada 3 s ou mais. |
| **Faixa** de 0 a 400 cm | Fora dela: HTTP 400. O firmware deve descartar amostras sem eco ou fora da faixa. |
| **Confirmação**: alertas (70% e 90%) e troca automática só disparam na **2ª leitura seguida** acima do limite | Uma leitura falsa isolada não pede troca. A resposta traz `"aguardando_confirmacao": true` quando a 1ª leitura passa do limite. |
| **Último contato**: o app considera o sensor "sem sinal" após 10 min sem leitura | Mantenha o intervalo bem abaixo de 10 min. |

## Respostas

| HTTP | Corpo | Significado | Ação do firmware |
|---|---|---|---|
| 200 | `{"ok":true,"vinculado":true,"galao":"G-001","nivel_pct":71.4,"litros":3.6,"aguardando_confirmacao":false}` | Leitura registrada | Seguir; pode usar `nivel_pct` para o LED |
| 200 | `{"ok":true,"ignorada":true,"motivo":"intervalo_minimo","intervalo_minimo_s":4}` | Enviada cedo demais | Aumentar o intervalo |
| 200 | `{"ok":true,"vinculado":false}` | Sensor sem galão associado | Seguir; a empresa associa no app |
| 400 | `{"code":"22003","message":"Distância fora da faixa do sensor (0 a 400 cm)."}` | Medição inválida | Descartar e medir de novo |
| 403 | `{"code":"28000","message":"Chave de dispositivo inválida."}` | Chave errada ou trocada | Parar de enviar e avisar (serial) |
| 404 | `{"code":"PGRST202",...}` | Campo ausente ou com nome errado | Corrigir o firmware |
| outros / sem rede | — | Falha temporária | Tentar de novo no próximo ciclo |

## Recomendações para o firmware

- **Filtrar ruído:** 7 medições seguidas (60 ms entre elas), descartar as sem eco ou fora de
  2–400 cm e enviar a **mediana**; se a maioria falhar, não enviar.
- **Intervalo:** 5 s na apresentação; 60 s em uso normal. Conte do início de cada ciclo.
- **Conexão:** reconectar ao Wi-Fi se cair; timeout de 10 s na requisição; watchdog para
  reiniciar se travar.
- **LED:** pisca a cada medição; ao chegar a 90% fica aceso fixo (alerta físico no galão) e continua fixo mesmo se o nível oscilar, até a troca (o sensor passa a outro galão) ou o nível cair abaixo de 10%.
- **Configuração** em `config.py`, fora do Git: Wi-Fi, URL, `apikey`, chave do dispositivo.

## Exemplo (MicroPython)

```python
import json, requests

URL = "https://sshzfagqjzydgesrmiyf.supabase.co/rest/v1/rpc/registrar_leitura"

def enviar(distancia_cm):
    r = requests.post(
        URL,
        headers={"Content-Type": "application/json", "apikey": config.SUPABASE_PUBLISHABLE_KEY},
        data=json.dumps({"chave": config.CHAVE_DISPOSITIVO, "distancia_cm": round(distancia_cm, 1)}),
        timeout=10,
    )
    try:
        return r.status_code, r.json()
    finally:
        r.close()
```

## Calibração

Nível = (vazio − medida) ÷ (vazio − cheio) × 100, limitado a 0–100%.

1. Com o galão **vazio** e o sensor na tampa, anote a distância → `distancia_vazio_cm`.
2. Com o óleo na altura considerada **cheia** (abaixo do “ombro” do galão), anote →
   `distancia_cheio_cm`.
3. Cadastre no app (Galões > Calibrar). Com o sensor enviando, a folha de calibração mostra a
   medição atual e tem os botões “Usar como vazio” e “Usar como cheio”.

Exemplo, bombona de 5 L: vazio = 28 cm, cheio = 9 cm, medida de 18,5 cm → 50%.
