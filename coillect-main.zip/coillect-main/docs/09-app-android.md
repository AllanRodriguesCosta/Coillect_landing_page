# App Android (APK)

O APK é o próprio PWA publicado na Vercel, empacotado como **Trusted Web Activity (TWA)**
com o [Bubblewrap](https://github.com/GoogleChromeLabs/bubblewrap) do Google. Ele abre
`https://coillect.vercel.app` em tela cheia, sem a barra do navegador, e se atualiza junto
com o site: só é preciso gerar um APK novo para mudar nome, ícone, cores ou versão.

| Item | Valor |
|---|---|
| Pacote | `app.vercel.coillect` |
| Versão | 1.0.0 (código 1) |
| Android mínimo | 7.0 (API 24), exigido pela biblioteca `androidbrowserhelper` |
| Navegador | Usa o Chrome do aparelho; sem Chrome, abre numa aba personalizada |

## Instalar no celular

1. Baixe o APK da [última release](https://github.com/DarchLord/coillect/releases/latest)
   (enquanto o repositório for privado, é preciso estar logado no GitHub no celular).
2. Abra o arquivo e permita **instalar apps desta fonte** quando o Android pedir.
3. O ícone **cOillect** aparece na gaveta de apps. Versões novas instalam por cima.

Com o celular ligado por USB e a depuração ativada:
`~/.local/share/android-sdk/platform-tools/adb install -r cOillect-<versão>.apk`.

## Barra do navegador e `assetlinks.json`

O Android só abre o app sem a barra de endereço se o site declarar o certificado do APK em
[`app/public/.well-known/assetlinks.json`](../app/public/.well-known/assetlinks.json)
(publicado em `https://coillect.vercel.app/.well-known/assetlinks.json`). Se a chave de
assinatura mudar, a impressão digital SHA-256 desse arquivo precisa mudar junto.

## Publicar uma versão nova

Mudanças nas telas e regras do app **não precisam de APK novo**: chegam sozinhas pelo site.
Gere um APK novo só para mudar nome, ícone, cores ou a versão exibida.

```bash
tools/publicar-apk.sh 1.0.1              # gera, assina, confere e cria a release v1.0.1
tools/publicar-apk.sh 1.0.1 --so-gerar   # só gera o APK, sem publicar
```

O script lê o nome, os ícones e as cores do manifesto do PWA publicado, aplica as
configurações de [`tools/android/twa-manifest.cjs`](../tools/android/twa-manifest.cjs)
(pacote, nome, Android mínimo) e aumenta sozinho o código da versão, que o Android exige
que só cresça.

O projeto Android gerado e a chave de assinatura ficam **fora do repositório**, em
`~/Projects/FATEC/cOillect/coillect-android` (`assinatura/coillect.keystore` e a senha em
`assinatura/SENHA.txt`). A chave **não pode ser perdida**: um APK assinado com outra chave
não instala por cima do anterior. Guarde uma cópia da pasta `assinatura/` fora do notebook.

Ambiente (sem sudo): Java 17 pelo `mise` (`java@temurin-17.0.21+9`), Android SDK em
`~/.local/share/android-sdk` (build-tools 36.1.0, platform android-36) e Bubblewrap em
`~/.local/share/bubblewrap`, configurado em `~/.bubblewrap/config.json`.
