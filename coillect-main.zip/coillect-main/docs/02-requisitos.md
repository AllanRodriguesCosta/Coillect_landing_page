# Requisitos

## Atores

| Ator | Descrição |
|---|---|
| **Cliente** | Síndico de condomínio ou responsável por estabelecimento (restaurante, lanchonete). Cadastra-se pelo aplicativo. |
| **Empresa** | Equipe da cOillect, responsável por entregar, trocar e reciclar os galões. Contas criadas internamente. |
| **Sensor** | Dispositivo ESP32 com sensor ultrassônico HC-SR04 instalado na tampa do galão. |

## Requisitos funcionais

| ID | Requisito | Ator |
|---|---|---|
| RF01 | Cadastrar conta de cliente com nome, e-mail, telefone e senha | Cliente |
| RF02 | Autenticar usuários e direcionar ao painel do seu perfil | Cliente, Empresa |
| RF03 | Cadastrar o local atendido (tipo, nome e endereço) | Cliente |
| RF04 | Solicitar a entrega de um galão | Cliente |
| RF05 | Visualizar o nível atual de cada galão do local, em tempo real | Cliente |
| RF06 | Visualizar alertas de nível e marcá-los como lidos | Cliente |
| RF07 | Solicitar coleta antecipada de um galão | Cliente |
| RF08 | Acompanhar o status das solicitações e o histórico de coletas | Cliente |
| RF09 | Receber leituras de distância do sensor e calcular nível (%) e volume (L) | Sensor |
| RF10 | Gerar alerta de atenção ao atingir 70% e alerta de coleta ao atingir 90% | Sistema |
| RF11 | Criar automaticamente uma solicitação de coleta no alerta de 90% | Sistema |
| RF12 | Listar locais, galões e níveis de todos os clientes | Empresa |
| RF13 | Agendar e cancelar solicitações | Empresa |
| RF14 | Concluir entrega associando um galão do estoque ao local | Empresa |
| RF15 | Concluir coleta: retirar o galão cheio, instalar um vazio e transferir o sensor | Empresa |
| RF16 | Registrar a reciclagem com volume e valor estimado | Sistema |
| RF17 | Cadastrar galões, calibrar o sensor e devolver galões higienizados ao estoque | Empresa |
| RF18 | Cadastrar dispositivos e gerar a chave de autenticação do sensor | Empresa |
| RF19 | Exibir indicadores: galões instalados, coletas pendentes, litros reciclados e receita | Empresa |
| RF20 | Configurar limites de alerta e valor pago por litro | Empresa |

## Requisitos não funcionais

| ID | Requisito |
|---|---|
| RNF01 | Interface mobile-first, responsiva, utilizável a partir de 360 px de largura |
| RNF02 | Aplicação instalável no celular (PWA) |
| RNF03 | Hospedagem em nuvem: banco e API no Supabase, aplicativo na Vercel |
| RNF04 | Atualização do nível na tela em até 5 segundos após a leitura, sem recarregar |
| RNF05 | Comunicação por HTTPS em todos os componentes, inclusive o sensor |
| RNF06 | Senhas armazenadas com hash pelo serviço de autenticação; chaves de sensor armazenadas como SHA-256 |
| RNF07 | Isolamento de dados por cliente garantido no banco (Row Level Security) |
| RNF08 | Código versionado no GitHub, com banco reproduzível por migrations |
| RNF09 | Custo zero de infraestrutura no escopo acadêmico (planos gratuitos) |

## Regras de negócio

| ID | Regra |
|---|---|
| RN01 | O cadastro público cria sempre um perfil **Cliente**; contas **Empresa** são habilitadas internamente |
| RN02 | Um cliente só acessa os locais, galões, leituras, alertas e solicitações que lhe pertencem |
| RN03 | Nível = (distância vazio − distância medida) ÷ (distância vazio − distância cheio) × 100, limitado a 0–100% |
| RN04 | Existe no máximo um alerta aberto de cada tipo por galão; ele é resolvido na troca do galão |
| RN05 | Existe no máximo uma solicitação de coleta em aberto por galão e uma de entrega por local |
| RN06 | Somente galões em estoque podem ser entregues ou instalados em uma troca |
| RN07 | Na troca, o galão cheio segue para reciclagem e o sensor é transferido para o galão vazio |
| RN08 | O volume reciclado é calculado pelo último nível registrado do galão retirado |
| RN09 | Valor da reciclagem = litros × valor por litro vigente na data da coleta |
| RN10 | Um galão só volta ao estoque após ser liberado (higienizado) pela empresa |
