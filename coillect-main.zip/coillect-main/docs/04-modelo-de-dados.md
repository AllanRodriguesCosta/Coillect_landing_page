# Modelo de dados

Banco PostgreSQL 17 no Supabase. O esquema é criado pelas migrations em
[`supabase/migrations`](../supabase/migrations).

## Diagrama entidade-relacionamento

```mermaid
erDiagram
  AUTH_USERS ||--|| PERFIS : "possui"
  PERFIS ||--o{ LOCAIS : "é responsável por"
  LOCAIS ||--o{ GALOES : "tem instalados"
  GALOES ||--o| DISPOSITIVOS : "monitorado por"
  DISPOSITIVOS ||--o{ LEITURAS : "envia"
  GALOES ||--o{ LEITURAS : "recebe"
  GALOES ||--o{ ALERTAS : "gera"
  LOCAIS ||--o{ ALERTAS : "recebe"
  LOCAIS ||--o{ SOLICITACOES : "faz"
  GALOES ||--o{ SOLICITACOES : "é coletado em"
  SOLICITACOES ||--o| RECICLAGENS : "resulta em"

  PERFIS {
    uuid id PK
    papel_usuario papel "cliente | empresa"
    text nome
    text telefone
  }
  LOCAIS {
    uuid id PK
    uuid cliente_id FK
    tipo_local tipo "condominio | restaurante | lanchonete | outro"
    text nome
    text logradouro
    text cidade
    char uf
    numeric latitude "mapa (OpenStreetMap)"
    numeric longitude
  }
  GALOES {
    uuid id PK
    text codigo UK
    numeric capacidade_litros
    numeric distancia_vazio_cm
    numeric distancia_cheio_cm
    status_galao status "estoque | instalado | reciclagem"
    uuid local_id FK
    numeric nivel_pct
    timestamptz ultima_leitura_em
  }
  DISPOSITIVOS {
    uuid id PK
    text codigo UK
    text chave_hash UK
    uuid galao_id FK
    timestamptz ultimo_contato_em
  }
  LEITURAS {
    bigint id PK
    uuid dispositivo_id FK
    uuid galao_id FK
    uuid local_id FK
    numeric distancia_cm
    numeric nivel_pct
    numeric litros
    timestamptz criado_em
  }
  ALERTAS {
    uuid id PK
    uuid galao_id FK
    uuid local_id FK
    tipo_alerta tipo "atencao | coleta"
    numeric nivel_pct
    timestamptz lido_em
    timestamptz resolvido_em
  }
  SOLICITACOES {
    uuid id PK
    uuid local_id FK
    uuid galao_id FK
    tipo_solicitacao tipo "entrega | coleta"
    origem_solicitacao origem "cliente | automatica"
    status_solicitacao status
    timestamptz agendada_para
    uuid galao_entregue_id FK
    numeric litros_coletados
    papel_usuario cancelado_por
  }
  RECICLAGENS {
    uuid id PK
    uuid solicitacao_id FK
    uuid galao_id FK
    numeric litros
    numeric valor_litro
    numeric valor_total "litros × valor_litro"
  }
  CONFIGURACOES {
    boolean id PK
    numeric limite_atencao "70"
    numeric limite_coleta "90"
    numeric valor_litro "2,00"
  }
```

## Dicionário resumido

| Tabela | Finalidade |
|---|---|
| `perfis` | Dados do usuário e seu papel; criado automaticamente no cadastro |
| `locais` | Condomínio ou estabelecimento do cliente, com endereço e coordenadas para o mapa (preenchidas no cadastro pelo Nominatim/OpenStreetMap) |
| `galoes` | Galão físico, calibração do sensor, status e último nível |
| `dispositivos` | Sensor ESP32; guarda apenas o hash SHA-256 da chave |
| `leituras` | Histórico de medições (distância, nível, litros), com o local, para o histórico atravessar as trocas |
| `alertas` | Alertas de 70% e 90%; um aberto por tipo e galão |
| `solicitacoes` | Pedidos de entrega e coleta, manuais ou automáticos |
| `reciclagens` | Volume destinado à reciclagem e receita estimada |
| `configuracoes` | Limites de alerta e valor por litro (linha única) |

## Funções (API de negócio)

| Função | Quem chama | O que faz |
|---|---|---|
| `registrar_leitura(chave, distancia_cm)` | Sensor | Valida a chave, grava a leitura, atualiza o nível, gera alertas e coleta automática |
| `solicitar(local, tipo, galao, observacoes)` | Cliente | Pede entrega de galão ou coleta antecipada |
| `cancelar_solicitacao(solicitacao)` | Cliente, Empresa | Cancela pedido pendente ou agendado e registra quem cancelou (o cliente é avisado quando é a equipe) |
| `agendar_solicitacao(solicitacao, data)` | Empresa | Define a data de atendimento |
| `concluir_entrega(solicitacao, galao)` | Empresa | Instala um galão do estoque no local |
| `concluir_coleta(solicitacao, galao_novo, litros)` | Empresa | Faz a troca, transfere o sensor e registra a reciclagem; `litros` (opcional) corrige a estimativa do sensor |
| `desfazer_coleta(solicitacao)` | Empresa | Desfaz uma troca concluída há até 30 minutos (galões, sensor, alertas, reciclagem e pedido) |
| `liberar_galao(galao)` | Empresa | Devolve ao estoque um galão higienizado |
| `gerar_chave_dispositivo(dispositivo)` | Empresa | Gera nova chave do sensor (exibida uma vez) |

## Segurança

Todas as tabelas usam **Row Level Security**. Clientes leem apenas os registros dos seus
locais; a empresa lê todos. Alterações de estado passam pelas funções acima, que validam
o perfil de quem chama. O cliente não pode alterar o próprio papel e só altera o campo
`lido_em` dos alertas.
