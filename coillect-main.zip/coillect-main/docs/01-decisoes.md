# Registro de decisões

## D1 — Recriar o projeto do zero

**Contexto:** a versão anterior tinha duas propostas divergentes (coleta doméstica com
gamificação, documentada em jun/2025; e monitoramento de galões em condomínios, no
protótipo Expo), backend incompleto ou ausente e documentação com inconsistências.

**Decisão:** recriar o projeto com escopo único: galões monitorados por sensor IoT em
condomínios e estabelecimentos, com dois perfis (Cliente e Empresa).

## D2 — Supabase como backend

**Decisão:** usar Supabase (PostgreSQL, autenticação, API, tempo real e Edge Functions).

**Motivos:** elimina a manutenção de um servidor próprio; banco relacional mantém a
modelagem com DER; tempo real atualiza o nível do galão na tela sem recarregar; plano
gratuito atende ao projeto.

## D3 — Aplicativo web mobile-first (PWA) com React + Vite

**Decisão:** construir o aplicativo como PWA, hospedado na Vercel.

**Motivos:** roda em qualquer celular pelo navegador e pode ser instalado na tela inicial;
dispensa build nativo e publicação em lojas; deploy automático a cada push no GitHub.

## D4 — ESP32 envia leituras diretamente para a nuvem

**Decisão:** o ESP32 (MicroPython + HC-SR04) envia a distância medida via HTTPS para a
função `registrar_leitura` do banco, exposta pela API REST do Supabase, autenticado por
uma chave única do dispositivo (armazenada no banco apenas como hash SHA-256). O cálculo
do nível e a geração de alertas ficam no banco.

**Motivos:** firmware simples; calibração (distâncias de vazio e cheio) ajustável sem
regravar o dispositivo; o simulador usa o mesmo endpoint. Uma Edge Function foi
considerada, mas uma função no banco atende ao mesmo contrato sem um serviço a mais
para publicar. Contrato em [06-contrato-iot.md](06-contrato-iot.md).

## D5 — Alertas em dois níveis

**Decisão:** alerta de atenção em 70% e alerta de coleta em 90%. O alerta de 90% cria
automaticamente uma solicitação de coleta para a empresa.

## D6 — Contas da empresa criadas internamente

**Decisão:** o cadastro pelo app cria sempre um perfil Cliente. Contas Empresa são
habilitadas pela equipe (script de administração).

**Motivo:** impedir que qualquer pessoa se cadastre como empresa e acesse os dados de
todos os clientes.

## D7 — Sensor reaproveitado na troca do galão

**Decisão:** o dispositivo é uma entidade separada do galão. Na troca, o sensor é
retirado do galão cheio e instalado no vazio.

**Motivos:** o sensor é o item de maior custo e é reutilizável; permite demonstrar o
ciclo completo com um único ESP32.

## D8 — Mapa com OpenStreetMap

**Decisão:** o mapa dos locais usa OpenStreetMap com a biblioteca Leaflet; as coordenadas
de cada local vêm do endereço, pelo serviço Nominatim, no momento do cadastro.

**Motivos:** gratuito e sem chave de API. O Google Maps exige projeto no Google Cloud com
faturamento ativo (cartão de crédito), mesmo dentro da cota gratuita. A empresa vê todos os
locais com a cor do nível (verde, âmbar, vermelho); o cliente vê só o próprio local.
