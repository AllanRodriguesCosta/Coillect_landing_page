# Plano e cronograma

## Marcos

| Data | Marco |
|---|---|
| 28/10/2026 | Início da recriação |
| 14/11/2026 | **Entrega do projeto escrito** (documentação ABNT) |
| 28/11/2026 | **Apresentação do projeto completo** (produto, slides e demonstração) |

## Escopo

### Dentro do escopo
- Dois perfis com login: **Cliente** (condomínio ou estabelecimento) e **Empresa** (coletora).
- Cadastro do local do cliente (tipo, nome, endereço, responsável).
- Solicitação de galão pelo cliente e atendimento pela empresa (agendar e confirmar entrega).
- Associação de galão e sensor a um local; chave de autenticação por dispositivo.
- Recebimento de leituras do ESP32 na nuvem e cálculo do nível (%).
- Nível em tempo real nos dois painéis.
- Alertas automáticos: **70%** (atenção) e **90%** (coleta necessária).
- Coleta: criação automática no alerta de 90%, agendamento, troca do galão e conclusão.
- Registro de reciclagem: litros coletados e valor estimado.
- Histórico de leituras, coletas e indicadores para a empresa.
- Aplicativo responsivo, mobile-first, instalável (PWA) e publicado na nuvem.

### Fora do escopo (evolução futura)
- Gamificação e recompensas para clientes.
- Roteirização com geolocalização.
- Notificações push e e-mail.
- Área de administração separada e múltiplas empresas coletoras.

## Etapas

| # | Etapa | Entregável | Período |
|---|---|---|---|
| 0 | ✅ Preparação: repositório, Supabase, Vercel | Infra criada | 28/10 |
| 1 | ✅ Documentação base: visão, requisitos, casos de uso, DER, arquitetura | `docs/` | 28/10 – 30/10 |
| 2 | ✅ Banco e autenticação: tabelas, perfis, regras de acesso, gatilhos de alerta | `supabase/migrations` | 29/10 – 31/10 |
| 3 | ✅ Endpoint IoT, contrato e simulador | `tools/simulador`, `docs/06-contrato-iot.md` | 31/10 – 01/11 |
| 4 | ✅ App Cliente: login, cadastro, painel do galão, alertas, solicitações | `app/` | 02/11 – 04/11 |
| 5 | ✅ App Empresa: locais, galões, alertas, solicitações, coletas, reciclagem | `app/` | 04/11 – 07/11 |
| 6 | Integração do ESP32 real e calibração do galão | `firmware/` | 06/11 – 08/11 |
| 7 | Documento ABNT completo com telas reais; revisão | `.docx` / `.pdf` | 09/11 – 13/11 |
| — | **Entrega do escrito** | | **14/11** |
| 8 | Polimento, testes, slides, vídeo de demonstração, ensaio | Apresentação | 15/11 – 27/11 |
| — | **Apresentação** | | **28/11** |

## Riscos

| Risco | Mitigação |
|---|---|
| Hardware atrasar ou falhar na apresentação | Simulador de sensor envia leituras pelo mesmo endpoint; vídeo gravado como reserva |
| Projeto gratuito do Supabase pausa após 7 dias sem uso | Uso contínuo pelo sensor/simulador; verificar o painel antes de 14/11 e 28/11 |
| Rede Wi-Fi do local de apresentação | Roteador do celular configurado no ESP32 como alternativa |
| Prazo curto | Escopo fechado acima; itens extras só após o 14/11 |
