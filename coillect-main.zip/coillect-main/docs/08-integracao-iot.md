# Integração do sensor (ESP32 + HC-SR04)

Guia para montar, gravar, calibrar e testar o sensor com a nuvem. O contrato de
comunicação está em [06-contrato-iot.md](06-contrato-iot.md) e o firmware de referência em
[`firmware/`](../firmware).

## Recipiente da apresentação

**Bombona de 5 L.** Galão `G-001` (Residencial Aurora), sensor `ESP32-01`. O galão vazio
que entra na troca é o `G-002`, com a mesma calibração (na prática, a mesma bombona
esvaziada).

Cuidados com o formato:

- A bombona estreita no **ombro**, perto da boca. A marca de **cheio** deve ficar abaixo do
  ombro: acima dele, poucos mililitros mudam muito a altura e a parede inclinada pode
  devolver eco falso.
- O HC-SR04 tem dois transdutores de 16 mm com 26 mm entre centros. Se a boca for estreita
  demais e as leituras oscilarem, fure a tampa com dois furos alinhados aos transdutores ou
  monte o sensor numa tampa larga improvisada. O sensor não deve encostar no líquido.
- O HC-SR04 mede a partir de ~2 cm; mantenha pelo menos 5 cm entre o sensor e o “cheio”.
- Para a demonstração, **água** funciona igual ao óleo para o ultrassom e não suja.

## Montagem

| HC-SR04 | ESP32 |
|---|---|
| VCC | 3V3 (funcionou estável no protótipo, sem divisor) |
| GND | GND |
| TRIG | GPIO 5 |
| ECHO | GPIO 18 |
| LED (+ resistor) | GPIO 23 |

Alimentação na apresentação: carregador de celular pela USB. O notebook só é necessário
para gravar o firmware e ler o terminal serial.

## Gravar o firmware

```bash
cd firmware
cp config.example.py config.py        # preencha Wi-Fi, chave pública e chave do dispositivo
M=~/.local/share/esp-venv/bin/mpremote
$M connect /dev/ttyUSB0 cp hcsr04.py config.py main.py :
$M connect /dev/ttyUSB0 reset
$M connect /dev/ttyUSB0 repl          # mostra as mensagens (Ctrl+] para sair)
```

O `main.py` roda sozinho a cada ligação. Mensagens esperadas no terminal:

```
Wi-Fi: conectado 192.168.0.23
18.5 cm: G-001 em 50.0% (2.5 L)
```

## Chave do dispositivo

A chave do `ESP32-01` é exibida ao recriar o cenário (`node tools/seed/apresentacao.mjs`)
e pode ser trocada no app: **Sensores > ESP32-01 > Gerar chave** (aparece uma única vez).
Depois de gerar, grave no `config.py` e regrave o ESP32; a chave anterior deixa de valer.

## Calibrar a bombona

1. Instale o sensor na tampa da bombona **vazia** e deixe enviando.
2. No app, entre como empresa: **Galões > G-001 > Calibrar**. A folha mostra a medição
   atual do sensor. Toque em **Usar como vazio**.
3. Encha até a marca de cheio (abaixo do ombro), espere a próxima leitura e toque em
   **Usar como cheio**. Confira a capacidade (5 L) e salve.
4. Repita os mesmos valores no `G-002` (o galão que entra na troca).
5. Para recriar o cenário já com os valores medidos:
   `DEMO_VAZIO_CM=28 DEMO_CHEIO_CM=9 node tools/seed/apresentacao.mjs`

## Testar com o monitor

Em um terminal, acompanhe as leituras que chegam na nuvem:

```bash
node tools/monitor.mjs ESP32-01
```

```
20:31:57  ESP32-01    10.5 cm →  92.1%  4.6 L  (G-001)
20:32:03  ESP32-01    10.0 cm →  94.7%  4.7 L  (G-001)
20:32:03  ALERTA de atenção no G-001 (94.7%)
20:32:03  ALERTA de troca no G-001 (94.7%)
20:32:03  PEDIDO automático de troca do G-001
```

Roteiro de teste:

| # | Ação | Esperado |
|---|---|---|
| 1 | Ligar o ESP32 com a bombona vazia | Monitor mostra leituras a cada ~5 s, nível ~0% |
| 2 | Abrir o app como síndico (`sindico@coillect.test`) | Galão G-001 com o nível atual, “Atualizado agora” |
| 3 | Despejar até passar de 70% | Na 2ª leitura acima de 70%: aviso âmbar no app |
| 4 | Despejar até passar de 90% | Na 2ª leitura acima de 90%: troca pedida, LED do ESP32 aceso fixo |
| 5 | Entrar como empresa, Pedidos | Pedido automático do G-001; agendar e concluir com o G-002 |
| 6 | Esvaziar a bombona | Leituras seguintes vão para o G-002, nível perto de 0%, LED volta a piscar |

## Plano B (sem o ESP32 ou sem Wi-Fi)

O simulador usa o mesmo endereço e a mesma chave do ESP32:

```bash
node tools/simulador/simulador.mjs --chave <CHAVE_ESP32-01> --encher --de 27 --ate 9 --passo 1 --intervalo 5
```

Rede: use o roteador do celular. Se nem isso funcionar, o vídeo gravado da demonstração
é o último recurso.

## Problemas comuns

| Sintoma | Causa provável | O que fazer |
|---|---|---|
| `Sensor: sem eco estável` | Sensor torto, boca estreita, fio solto | Alinhar com a boca; conferir TRIG/ECHO com multímetro |
| Nível pula muito | Eco na parede do ombro | Baixar a marca de cheio; furar a tampa alinhada aos transdutores |
| `Chave do dispositivo inválida` | Chave regenerada ou cenário recriado | Copiar a chave atual para o `config.py` e regravar |
| `ignorada (intervalo mínimo)` | `INTERVALO_S` abaixo do `intervalo_minimo_s` do servidor (1 s) | Usar 3 s ou mais |
| `Wi-Fi: sem conexão` | Rede 5 GHz ou senha errada | O ESP32 só conecta em 2,4 GHz |
| App mostra “sem sinal” | Mais de 10 min sem leitura | Conferir energia e Wi-Fi do ESP32 |
| Nada muda no app | Sensor vinculado a outro galão | App: Sensores > ESP32-01 > Mudar de galão |
