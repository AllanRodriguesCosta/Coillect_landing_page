# Recursos do cOillect no Azure (capítulo de Computação em Nuvem II / Atividade A02).
# O app continua em Vercel + Supabase; o Azure guarda backups, o histórico de
# telemetria, um espelho do PWA e o monitoramento.

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}

resource "azurerm_resource_group" "rg" {
  name     = "coillect-rg"
  location = var.regiao
}

# ---------- Armazenamento (Blob, Table e site estático) ----------

resource "azurerm_storage_account" "st" {
  name                     = var.nome_storage
  resource_group_name      = azurerm_resource_group.rg.name
  location                 = azurerm_resource_group.rg.location
  account_tier             = "Standard"
  account_replication_type = "RAGRS" # cópia em outra região, com leitura no secundário
  min_tls_version          = "TLS1_2"

  blob_properties {
    versioning_enabled = true
    delete_retention_policy {
      days = 7
    }
    container_delete_retention_policy {
      days = 7
    }
  }
}

# Espelho do PWA: o build do app (app/dist) é publicado no contêiner $web.
resource "azurerm_storage_account_static_website" "site" {
  storage_account_id = azurerm_storage_account.st.id
  index_document     = "index.html"
  error_404_document = "index.html" # rotas do SPA caem no app
}

resource "azurerm_storage_container" "backups" {
  name                  = "backups"
  storage_account_id    = azurerm_storage_account.st.id
  container_access_type = "private"
}

resource "azurerm_storage_table" "leituras" {
  name                 = "leituras"
  storage_account_name = azurerm_storage_account.st.name
}

# Backups: esfriam após 30 dias e são apagados após 90.
resource "azurerm_storage_management_policy" "ciclo" {
  storage_account_id = azurerm_storage_account.st.id

  rule {
    name    = "ciclo-backups"
    enabled = true
    filters {
      prefix_match = ["backups/"]
      blob_types   = ["blockBlob"]
    }
    actions {
      base_blob {
        tier_to_cool_after_days_since_modification_greater_than = 30
        delete_after_days_since_modification_greater_than       = 90
      }
      version {
        delete_after_days_since_creation = 30
      }
    }
  }
}

# SAS usado pela GitHub Action de backup: só escrita em Blob e Table, válido por 1 ano.
data "azurerm_storage_account_sas" "backup" {
  connection_string = azurerm_storage_account.st.primary_connection_string
  https_only        = true
  start             = "2026-11-01T00:00:00Z"
  expiry            = "2027-11-01T00:00:00Z"

  resource_types {
    service   = false
    container = false
    object    = true
  }
  services {
    blob  = true
    table = true
    queue = false
    file  = false
  }
  permissions {
    read    = false
    write   = true
    delete  = false
    list    = false
    add     = true
    create  = true
    update  = true
    process = false
    tag     = false
    filter  = false
  }
}

# ---------- Monitoramento ----------

resource "azurerm_log_analytics_workspace" "log" {
  name                = "coillect-log"
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  sku                 = "PerGB2018"
  retention_in_days   = 30
}

resource "azurerm_application_insights" "ai" {
  name                = "coillect-ai"
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  workspace_id        = azurerm_log_analytics_workspace.log.id
  application_type    = "web"
}

# Logs de leitura/escrita do Blob e da Table vão para o Log Analytics.
resource "azurerm_monitor_diagnostic_setting" "servicos" {
  for_each                   = toset(["blobServices", "tableServices"])
  name                       = "${each.key}-para-log"
  target_resource_id         = "${azurerm_storage_account.st.id}/${each.key}/default"
  log_analytics_workspace_id = azurerm_log_analytics_workspace.log.id

  enabled_log {
    category_group = "allLogs"
  }
  enabled_metric {
    category = "Transaction"
  }
}

# Testes de disponibilidade a cada 5 minutos, de 3 locais, nos dois endereços do app.
locals {
  enderecos = {
    vercel = var.url_vercel
    azure  = azurerm_storage_account.st.primary_web_endpoint
  }
}

resource "azurerm_application_insights_standard_web_test" "app" {
  for_each                = local.enderecos
  name                    = "disponibilidade-${each.key}"
  location                = azurerm_resource_group.rg.location
  resource_group_name     = azurerm_resource_group.rg.name
  application_insights_id = azurerm_application_insights.ai.id
  frequency               = 300
  enabled                 = true
  geo_locations           = ["latam-br-gru-edge", "us-va-ash-azr", "emea-nl-ams-azr"]

  request {
    url = each.value
  }
  validation_rules {
    expected_status_code = 200
  }
}

resource "azurerm_monitor_action_group" "email" {
  name                = "coillect-alertas"
  resource_group_name = azurerm_resource_group.rg.name
  short_name          = "coillect"

  email_receiver {
    name          = "responsavel"
    email_address = var.email_alertas
  }
}

resource "azurerm_monitor_metric_alert" "app_fora" {
  for_each            = azurerm_application_insights_standard_web_test.app
  name                = "app-fora-do-ar-${each.key}"
  resource_group_name = azurerm_resource_group.rg.name
  scopes              = [each.value.id, azurerm_application_insights.ai.id]
  description         = "O endereço ${each.key} do app falhou em 2 ou mais locais."
  severity            = 1

  application_insights_web_test_location_availability_criteria {
    web_test_id           = each.value.id
    component_id          = azurerm_application_insights.ai.id
    failed_location_count = 2
  }
  action {
    action_group_id = azurerm_monitor_action_group.email.id
  }
}

resource "azurerm_monitor_metric_alert" "storage_disponibilidade" {
  name                = "storage-disponibilidade-baixa"
  resource_group_name = azurerm_resource_group.rg.name
  scopes              = [azurerm_storage_account.st.id]
  description         = "Disponibilidade do Storage abaixo de 99%."
  severity            = 2

  criteria {
    metric_namespace = "Microsoft.Storage/storageAccounts"
    metric_name      = "Availability"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 99
  }
  action {
    action_group_id = azurerm_monitor_action_group.email.id
  }
}

resource "azurerm_portal_dashboard" "painel" {
  name                = "coillect-painel"
  resource_group_name = azurerm_resource_group.rg.name
  location            = azurerm_resource_group.rg.location
  tags                = { "hidden-title" = "cOillect - Monitoramento" }
  dashboard_properties = templatefile("${path.module}/dashboard.json.tftpl", {
    storage_id = azurerm_storage_account.st.id
    ai_id      = azurerm_application_insights.ai.id
  })
}
