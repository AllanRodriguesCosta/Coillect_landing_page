variable "subscription_id" {
  description = "Assinatura Azure for Students (az account show --query id -o tsv)"
  type        = string
}

variable "regiao" {
  description = "Região permitida pela política da assinatura de estudante"
  type        = string
  default     = "brazilsouth"
}

variable "nome_storage" {
  description = "Nome global e único da conta de armazenamento (3-24, minúsculas e números)"
  type        = string
  default     = "coillectst"
}

variable "url_vercel" {
  type    = string
  default = "https://coillect.vercel.app/"
}

variable "email_alertas" {
  description = "Quem recebe os alertas de indisponibilidade"
  type        = string
}
