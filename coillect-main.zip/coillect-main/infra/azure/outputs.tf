output "url_azure" {
  description = "Espelho do PWA servido pelo Blob Storage"
  value       = azurerm_storage_account.st.primary_web_endpoint
}

output "url_azure_secundaria" {
  description = "Leitura na região secundária (RA-GRS)"
  value       = azurerm_storage_account.st.secondary_web_endpoint
}

output "storage" {
  value = azurerm_storage_account.st.name
}

output "sas_backup" {
  description = "Vai para o secret AZURE_STORAGE_SAS da GitHub Action"
  value       = data.azurerm_storage_account_sas.backup.sas
  sensitive   = true
}
