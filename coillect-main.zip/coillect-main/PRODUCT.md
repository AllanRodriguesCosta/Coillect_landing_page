# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

Aplicativo web mobile-first instalável (PWA) em React + Vite, hospedado na Vercel.
Backend no Supabase (PostgreSQL com regras de negócio em funções, Auth, Realtime).
Sensor: ESP32 + HC-SR04 em MicroPython, enviando leituras por HTTPS.
Decisões registradas em `docs/01-decisoes.md`.

## Users

- **Cliente:** síndico de condomínio ou responsável por um estabelecimento que gera óleo
  de cozinha usado (restaurante, lanchonete). Abre o app para saber quanto o galão já
  encheu, pedir um galão e acompanhar quando a troca vai acontecer. Usa o celular.
- **Empresa (equipe cOillect):** duas situações reais.
  - Coletor/motorista em rota, no celular: vê o que precisa ser entregue ou trocado,
    conclui a entrega ou a troca no local.
  - Pessoa no escritório, no computador: acompanha níveis de todos os clientes, agenda
    pedidos, cadastra e calibra galões e sensores, acompanha o volume reciclado.

## Product Purpose

Evitar que o óleo de cozinha usado seja descartado na pia, o que polui a água e entope a
tubulação. A cOillect instala um galão com sensor no condomínio ou estabelecimento; o
sensor mede o volume e o sistema avisa e agenda a troca sozinho. O galão cheio vai para
a reciclagem, que gera a receita da empresa.

Sucesso: o cliente nunca precisa ligar pedindo coleta, nenhum galão transborda, e a
empresa troca os galões no momento certo, sem viagens perdidas.

## Positioning

A coleta é guiada pelo nível medido no próprio galão, não por agendamento manual por
telefone ou e-mail. Alertas em 70% (atenção) e 90% (troca pedida automaticamente) fazem a
troca acontecer antes de encher, e o sensor é reaproveitado no galão vazio a cada troca.

## Operating Context

- Galão instalado em área comum do condomínio (ex.: perto das lixeiras) ou na área de
  serviço/cozinha do estabelecimento; moradores ou funcionários despejam o óleo frio e
  coado pelo funil.
- O sensor depende do Wi-Fi do local; sensores sem comunicação precisam ser notados pela
  empresa.
- Ciclo do galão: estoque → instalado → reciclagem → (higienizado) → estoque.
- Ciclo do pedido: pendente → agendado → concluído ou cancelado. Pedidos de troca nascem
  automaticamente em 90% ou manualmente pelo cliente.
- Projeto Integrador acadêmico (Fatec Cotia, DSM): entrega escrita em ABNT em 14/11/2026 e
  apresentação com demonstração ao vivo do sensor em 28/11/2026.

## Capabilities and Constraints

- Dois perfis com login. O cadastro público cria sempre Cliente; contas da Empresa são
  criadas internamente.
- Cliente: cadastrar conta e local (tipo, nome, endereço), pedir galão, ver nível em tempo
  real, avisos de 70% e 90%, pedir troca antecipada, histórico de níveis e volume
  reciclado.
- Empresa: painel de indicadores, pedidos (agendar, concluir entrega, concluir troca,
  cancelar), galões (status, calibração, devolver ao estoque), sensores (vínculo, chave,
  conexão), ajustes (limites de alerta, valor por litro) e lista de clientes.
- Regras de negócio no banco (`supabase/migrations`); o app e o sensor seguem as mesmas
  regras. Contrato do sensor em `docs/06-contrato-iot.md`.
- Termos do produto: galão, sensor, nível (%), litros, troca, entrega, pedido, reciclagem,
  calibração (distância vazio / distância cheio).
- **Em aberto:** modelo comercial com o cliente (gratuito, gratuito com benefício ou pago).
  A interface não deve prometer preço, gratuidade, pagamento ou benefício ao cliente.
- **Fora do escopo atual:** gamificação/recompensas, rotas com geolocalização,
  notificações push/e-mail, múltiplas empresas coletoras.

## Brand Commitments

- Nome: **cOillect** (o "Oil" destacado no meio da palavra).
- Logo e ícone existentes em `assets/logo.png` e `assets/icone.png` (folha verde).
- Voz: próxima e direta. Trata o usuário por "você", frases curtas, linguagem do dia a dia.

## Evidence on Hand

- Ainda não há clientes, depoimentos, parceiros ou números reais. Os dados do protótipo
  (Residencial Aurora, Restaurante Sabor da Granja etc.) são fictícios e não devem ser
  apresentados como reais.
- Dado de impacto usado no material original: 1 litro de óleo pode contaminar até 25 mil
  litros de água (slides de jun/2025 em `~/Projects/FATEC/cOillect`); citar a fonte no documento
  acadêmico antes de usar como afirmação.
- Protótipo navegável validado em `docs/prototipo/index.html`.

## Product Principles

1. **O nível do galão é a resposta.** Toda tela do cliente parte de "quanto já encheu e o
   que acontece agora".
2. **O sistema age; a pessoa confirma.** Alertas e pedidos de troca nascem sozinhos; o
   usuário só intervém quando quer antecipar ou ajustar.
3. **Uma verdade para os dois lados.** Cliente e empresa veem o mesmo estado do galão e do
   pedido, com a mesma linguagem.
4. **Feito para campo e escritório.** O cliente e o coletor usam no celular; o escritório
   precisa da visão de todos os clientes em tela grande.
5. **Não prometer o que não existe.** Nada de preços, benefícios ou números de impacto
   sem fonte enquanto o modelo comercial e os dados reais não existirem.
