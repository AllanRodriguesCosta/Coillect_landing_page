-- Robustez do backend: leitura confiável, autoria das ações e retenção de leituras.

-- =====================================================================
-- 1) Parâmetro de intervalo mínimo entre leituras de um mesmo sensor
-- =====================================================================
alter table configuracoes add column intervalo_minimo_s numeric(4,1) not null default 4
  check (intervalo_minimo_s between 0 and 60);

-- =====================================================================
-- 2) Leitura confiável
--    - distância fora da faixa do HC-SR04 (0 a 400 cm) é recusada;
--    - leituras mais próximas que o intervalo mínimo são ignoradas (protege contra excesso);
--    - alertas e troca automática exigem 2 leituras seguidas acima do limite
--      (uma leitura falsa isolada não dispara troca).
-- =====================================================================
create or replace function registrar_leitura(chave text, distancia_cm numeric)
returns json
language plpgsql security definer set search_path = public as $$
declare
  d dispositivos;
  g galoes;
  cfg configuracoes;
  nivel numeric;
  qtd numeric;
  anterior numeric;
begin
  if distancia_cm is null or distancia_cm < 0 or distancia_cm > 400 then
    raise exception 'Distância fora da faixa do sensor (0 a 400 cm).' using errcode = '22003';
  end if;

  select * into d from dispositivos
   where chave_hash = encode(sha256(convert_to(chave, 'UTF8')), 'hex');
  if not found then
    raise exception 'Chave de dispositivo inválida.' using errcode = '28000';
  end if;

  select * into cfg from configuracoes;
  if d.ultimo_contato_em is not null
     and d.ultimo_contato_em > now() - make_interval(secs => cfg.intervalo_minimo_s) then
    return json_build_object('ok', true, 'ignorada', true, 'motivo', 'intervalo_minimo',
                             'intervalo_minimo_s', cfg.intervalo_minimo_s);
  end if;

  update dispositivos set ultimo_contato_em = now() where id = d.id;

  if d.galao_id is null then
    return json_build_object('ok', true, 'vinculado', false);
  end if;

  select * into g from galoes where id = d.galao_id for update;

  nivel := round((g.distancia_vazio_cm - distancia_cm)
                 / (g.distancia_vazio_cm - g.distancia_cheio_cm) * 100, 1);
  nivel := least(100, greatest(0, nivel));
  qtd   := round(g.capacidade_litros * nivel / 100, 1);

  select l.nivel_pct into anterior from leituras l
   where l.galao_id = g.id order by l.criado_em desc limit 1;

  insert into leituras (dispositivo_id, galao_id, local_id, distancia_cm, nivel_pct, litros)
  values (d.id, g.id, g.local_id, distancia_cm, nivel, qtd);

  update galoes set nivel_pct = nivel, ultima_leitura_em = now() where id = g.id;

  if g.status = 'instalado' then
    if nivel >= cfg.limite_atencao and coalesce(anterior, -1) >= cfg.limite_atencao then
      insert into alertas (galao_id, local_id, tipo, nivel_pct)
      values (g.id, g.local_id, 'atencao', nivel)
      on conflict (galao_id, tipo) where resolvido_em is null do nothing;
    end if;

    if nivel >= cfg.limite_coleta and coalesce(anterior, -1) >= cfg.limite_coleta then
      insert into alertas (galao_id, local_id, tipo, nivel_pct)
      values (g.id, g.local_id, 'coleta', nivel)
      on conflict (galao_id, tipo) where resolvido_em is null do nothing;

      insert into solicitacoes (local_id, galao_id, tipo, origem)
      values (g.local_id, g.id, 'coleta', 'automatica')
      on conflict (galao_id) where tipo = 'coleta' and status in ('pendente', 'agendada') do nothing;
    end if;
  end if;

  return json_build_object('ok', true, 'vinculado', true, 'galao', g.codigo,
                           'nivel_pct', nivel, 'litros', qtd,
                           'aguardando_confirmacao', g.status = 'instalado' and nivel >= cfg.limite_atencao
                                                     and coalesce(anterior, -1) < cfg.limite_atencao);
end;
$$;

-- =====================================================================
-- 3) Autoria: quem agendou, concluiu e cancelou cada pedido
-- =====================================================================
alter table solicitacoes
  add column agendado_por   uuid references perfis on delete set null,
  add column concluido_por  uuid references perfis on delete set null,
  add column cancelado_por_usuario uuid references perfis on delete set null;

create or replace function agendar_solicitacao(solicitacao uuid, data timestamptz)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
begin
  perform exigir_empresa();
  update solicitacoes set status = 'agendada', agendada_para = data, agendado_por = auth.uid()
   where id = solicitacao and status in ('pendente', 'agendada')
  returning * into s;
  if not found then
    raise exception 'Solicitação não pode ser agendada.';
  end if;
  return s;
end;
$$;

create or replace function cancelar_solicitacao(solicitacao uuid)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
begin
  update solicitacoes so
     set status = 'cancelada', cancelada_em = now(),
         cancelado_por = (select papel from perfis where id = auth.uid()),
         cancelado_por_usuario = auth.uid()
   where so.id = solicitacao and so.status in ('pendente', 'agendada')
     and (eh_empresa() or exists (select 1 from locais l where l.id = so.local_id and l.cliente_id = auth.uid()))
  returning * into s;
  if not found then
    raise exception 'Solicitação não pode ser cancelada.';
  end if;
  return s;
end;
$$;

create or replace function concluir_entrega(solicitacao uuid, galao uuid)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
begin
  perform exigir_empresa();
  select * into s from solicitacoes
   where id = solicitacao and tipo = 'entrega' and status in ('pendente', 'agendada') for update;
  if not found then
    raise exception 'Solicitação de entrega não encontrada ou já encerrada.';
  end if;

  update galoes set status = 'instalado', local_id = s.local_id, nivel_pct = 0, instalado_em = now()
   where id = galao and status = 'estoque';
  if not found then
    raise exception 'Galão indisponível no estoque.';
  end if;

  update solicitacoes set status = 'concluida', concluida_em = now(), galao_entregue_id = galao,
         concluido_por = auth.uid()
   where id = s.id returning * into s;
  return s;
end;
$$;

create or replace function concluir_coleta(solicitacao uuid, galao_novo uuid, litros numeric default null)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
  antigo galoes;
  qtd numeric;
begin
  perform exigir_empresa();
  select * into s from solicitacoes
   where id = solicitacao and tipo = 'coleta' and status in ('pendente', 'agendada') for update;
  if not found then
    raise exception 'Solicitação de coleta não encontrada ou já encerrada.';
  end if;

  select * into antigo from galoes where id = s.galao_id for update;
  qtd := coalesce(round(litros, 1), round(antigo.capacidade_litros * antigo.nivel_pct / 100, 1));
  if qtd <= 0 or qtd > antigo.capacidade_litros then
    raise exception 'Informe um volume entre 0,1 e % L.', antigo.capacidade_litros;
  end if;

  update galoes set status = 'reciclagem', local_id = null, instalado_em = null where id = antigo.id;

  update galoes set status = 'instalado', local_id = s.local_id, nivel_pct = 0, instalado_em = now()
   where id = galao_novo and status = 'estoque';
  if not found then
    raise exception 'Galão novo indisponível no estoque.';
  end if;

  update dispositivos set galao_id = galao_novo where galao_id = antigo.id;

  update alertas set resolvido_em = now() where galao_id = antigo.id and resolvido_em is null;

  insert into reciclagens (solicitacao_id, galao_id, local_id, litros, valor_litro)
  select s.id, antigo.id, s.local_id, qtd, valor_litro from configuracoes;

  update solicitacoes set status = 'concluida', concluida_em = now(),
         galao_entregue_id = galao_novo, litros_coletados = qtd, concluido_por = auth.uid()
   where id = s.id returning * into s;
  return s;
end;
$$;

create or replace function desfazer_coleta(solicitacao uuid)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
begin
  perform exigir_empresa();
  select * into s from solicitacoes
   where id = solicitacao and tipo = 'coleta' and status = 'concluida' for update;
  if not found then
    raise exception 'Troca não encontrada.';
  end if;
  if s.concluida_em < now() - interval '30 minutes' then
    raise exception 'Só é possível desfazer uma troca nos primeiros 30 minutos.';
  end if;

  update galoes set status = 'estoque', local_id = null, nivel_pct = 0, instalado_em = null
   where id = s.galao_entregue_id;
  update galoes set status = 'instalado', local_id = s.local_id, instalado_em = coalesce(instalado_em, now())
   where id = s.galao_id;
  update dispositivos set galao_id = s.galao_id where galao_id = s.galao_entregue_id;
  update alertas set resolvido_em = null where galao_id = s.galao_id and resolvido_em >= s.concluida_em;
  delete from reciclagens where solicitacao_id = s.id;

  update solicitacoes
     set status = case when agendada_para is not null then 'agendada'::status_solicitacao else 'pendente'::status_solicitacao end,
         concluida_em = null, galao_entregue_id = null, litros_coletados = null, concluido_por = null
   where id = s.id returning * into s;
  return s;
end;
$$;

-- =====================================================================
-- 4) Retenção: leituras com mais de 90 dias viram resumo por hora
-- =====================================================================
create table leituras_hora (
  galao_id    uuid not null references galoes on delete cascade,
  hora        timestamptz not null,
  local_id    uuid references locais on delete set null,
  nivel_medio numeric(5,1) not null,
  nivel_max   numeric(5,1) not null,
  leituras    integer not null,
  primary key (galao_id, hora)
);
create index on leituras_hora (local_id, hora desc);

alter table leituras_hora enable row level security;
create policy "leitura por hora: cliente lê as do seu local, empresa lê todas" on leituras_hora for select to authenticated
  using ((select eh_empresa()) or local_id in (select id from locais where cliente_id = (select auth.uid())));

create function compactar_leituras(dias integer default 90)
returns integer
language plpgsql security definer set search_path = public as $$
declare
  limite timestamptz := now() - make_interval(days => dias);
  apagadas integer;
begin
  insert into leituras_hora (galao_id, hora, local_id, nivel_medio, nivel_max, leituras)
  select galao_id, date_trunc('hour', criado_em), (array_agg(local_id order by criado_em desc))[1],
         round(avg(nivel_pct), 1), max(nivel_pct), count(*)
    from leituras where criado_em < limite
   group by galao_id, date_trunc('hour', criado_em)
  on conflict (galao_id, hora) do update
     set nivel_medio = round((leituras_hora.nivel_medio * leituras_hora.leituras + excluded.nivel_medio * excluded.leituras)
                             / (leituras_hora.leituras + excluded.leituras), 1),
         nivel_max = greatest(leituras_hora.nivel_max, excluded.nivel_max),
         leituras = leituras_hora.leituras + excluded.leituras;
  delete from leituras where criado_em < limite;
  get diagnostics apagadas = row_count;
  return apagadas;
end;
$$;
revoke execute on function compactar_leituras(integer) from public, anon, authenticated;

create extension if not exists pg_cron;
select cron.schedule('coillect-compactar-leituras', '30 6 * * *', $$select public.compactar_leituras(90)$$);
