-- Ajustes apontados pelo Supabase Advisors:
-- funções internas fora da API e auth.uid()/eh_empresa() avaliados uma vez por consulta.

revoke execute on function criar_perfil(), exigir_empresa() from authenticated, anon, public;

drop policy "perfil: ler o próprio ou empresa" on perfis;
create policy "perfil: ler o próprio ou empresa" on perfis for select to authenticated
  using (id = (select auth.uid()) or (select eh_empresa()));

drop policy "perfil: editar o próprio" on perfis;
create policy "perfil: editar o próprio" on perfis for update to authenticated
  using (id = (select auth.uid()));

drop policy "local: cliente lê os seus, empresa lê todos" on locais;
create policy "local: cliente lê os seus, empresa lê todos" on locais for select to authenticated
  using (cliente_id = (select auth.uid()) or (select eh_empresa()));

drop policy "local: cliente cadastra" on locais;
create policy "local: cliente cadastra" on locais for insert to authenticated
  with check (cliente_id = (select auth.uid()));

drop policy "local: cliente ou empresa edita" on locais;
create policy "local: cliente ou empresa edita" on locais for update to authenticated
  using (cliente_id = (select auth.uid()) or (select eh_empresa()));

drop policy "galão: cliente lê os do seu local, empresa lê todos" on galoes;
create policy "galão: cliente lê os do seu local, empresa lê todos" on galoes for select to authenticated
  using ((select eh_empresa()) or local_id in (select id from locais where cliente_id = (select auth.uid())));

drop policy "galão: empresa cadastra" on galoes;
create policy "galão: empresa cadastra" on galoes for insert to authenticated with check ((select eh_empresa()));

drop policy "galão: empresa edita" on galoes;
create policy "galão: empresa edita" on galoes for update to authenticated using ((select eh_empresa()));

drop policy "dispositivo: empresa lê" on dispositivos;
create policy "dispositivo: empresa lê" on dispositivos for select to authenticated using ((select eh_empresa()));

drop policy "dispositivo: empresa cadastra" on dispositivos;
create policy "dispositivo: empresa cadastra" on dispositivos for insert to authenticated with check ((select eh_empresa()));

drop policy "dispositivo: empresa edita" on dispositivos;
create policy "dispositivo: empresa edita" on dispositivos for update to authenticated using ((select eh_empresa()));

drop policy "leitura: cliente lê as do seu local, empresa lê todas" on leituras;
create policy "leitura: cliente lê as do seu local, empresa lê todas" on leituras for select to authenticated
  using ((select eh_empresa()) or galao_id in (
    select g.id from galoes g join locais l on l.id = g.local_id where l.cliente_id = (select auth.uid())));

drop policy "alerta: cliente lê os seus, empresa lê todos" on alertas;
create policy "alerta: cliente lê os seus, empresa lê todos" on alertas for select to authenticated
  using ((select eh_empresa()) or local_id in (select id from locais where cliente_id = (select auth.uid())));

drop policy "alerta: marcar como lido" on alertas;
create policy "alerta: marcar como lido" on alertas for update to authenticated
  using ((select eh_empresa()) or local_id in (select id from locais where cliente_id = (select auth.uid())));

drop policy "solicitação: cliente lê as suas, empresa lê todas" on solicitacoes;
create policy "solicitação: cliente lê as suas, empresa lê todas" on solicitacoes for select to authenticated
  using ((select eh_empresa()) or local_id in (select id from locais where cliente_id = (select auth.uid())));

drop policy "reciclagem: cliente lê as suas, empresa lê todas" on reciclagens;
create policy "reciclagem: cliente lê as suas, empresa lê todas" on reciclagens for select to authenticated
  using ((select eh_empresa()) or local_id in (select id from locais where cliente_id = (select auth.uid())));

drop policy "configuração: todos leem" on configuracoes;
create policy "configuração: todos leem" on configuracoes for select to authenticated using (true);

drop policy "configuração: empresa edita" on configuracoes;
create policy "configuração: empresa edita" on configuracoes for update to authenticated using ((select eh_empresa()));
