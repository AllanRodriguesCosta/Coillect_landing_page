-- O cliente vê o sensor dos seus galões (código e último contato), nunca a chave.

-- Ninguém lê o hash da chave pela API; a validação acontece só dentro de registrar_leitura.
revoke select on dispositivos from authenticated, anon;
grant select (id, codigo, galao_id, ultimo_contato_em, criado_em) on dispositivos to authenticated;

create policy "dispositivo: cliente lê os dos seus galões" on dispositivos for select to authenticated
  using (galao_id in (
    select g.id from galoes g join locais l on l.id = g.local_id where l.cliente_id = (select auth.uid())));
