-- Consulta mínima ao banco para a verificação diária (evita a pausa por inatividade
-- do plano gratuito). Não lê nem altera dados.
create function ping() returns timestamptz
language sql stable as $$ select now() $$;

revoke execute on function ping() from public;
grant execute on function ping() to anon, authenticated;
