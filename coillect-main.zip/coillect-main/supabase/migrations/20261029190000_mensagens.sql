-- Mensagens do cliente para a equipe ("Falar com a cOillect").

create table mensagens (
  id        uuid primary key default gen_random_uuid(),
  local_id  uuid not null references locais on delete cascade,
  autor_id  uuid not null default auth.uid() references perfis on delete cascade,
  texto     text not null check (length(btrim(texto)) between 1 and 2000),
  criado_em timestamptz not null default now(),
  lida_em   timestamptz
);
create index on mensagens (criado_em desc);

alter table mensagens enable row level security;

create policy "mensagem: cliente lê as do seu local, empresa lê todas" on mensagens for select to authenticated
  using ((select eh_empresa()) or local_id in (select id from locais where cliente_id = (select auth.uid())));
create policy "mensagem: cliente envia pelo seu local" on mensagens for insert to authenticated
  with check (autor_id = (select auth.uid()) and local_id in (select id from locais where cliente_id = (select auth.uid())));
create policy "mensagem: empresa marca como lida" on mensagens for update to authenticated
  using ((select eh_empresa()));

revoke update on mensagens from authenticated;
grant update (lida_em) on mensagens to authenticated;

alter publication supabase_realtime add table mensagens;
