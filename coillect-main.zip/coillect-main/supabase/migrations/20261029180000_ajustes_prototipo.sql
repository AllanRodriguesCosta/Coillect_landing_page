-- Ajustes vindos do protótipo validado (docs/prototipo):
-- histórico por local, quem cancelou, litros informados na troca e desfazer troca.

-- ---------------------------------------------------------------------
-- 1) Leituras guardam o local: o histórico do cliente atravessa as trocas de galão.
-- ---------------------------------------------------------------------
alter table leituras add column local_id uuid references locais on delete set null;
create index on leituras (local_id, criado_em desc);
update leituras l set local_id = g.local_id from galoes g where g.id = l.galao_id and l.local_id is null;

drop policy "leitura: cliente lê as do seu local, empresa lê todas" on leituras;
create policy "leitura: cliente lê as do seu local, empresa lê todas" on leituras for select to authenticated
  using ((select eh_empresa()) or local_id in (select id from locais where cliente_id = (select auth.uid())));

create or replace function registrar_leitura(chave text, distancia_cm numeric)
returns json
language plpgsql security definer set search_path = public as $$
declare
  d dispositivos;
  g galoes;
  cfg configuracoes;
  nivel numeric;
  qtd numeric;
begin
  select * into d from dispositivos
   where chave_hash = encode(sha256(convert_to(chave, 'UTF8')), 'hex');
  if not found then
    raise exception 'Chave de dispositivo inválida.' using errcode = '28000';
  end if;

  update dispositivos set ultimo_contato_em = now() where id = d.id;

  if d.galao_id is null then
    return json_build_object('ok', true, 'vinculado', false);
  end if;

  select * into g from galoes where id = d.galao_id for update;

  nivel := round((g.distancia_vazio_cm - distancia_cm)
                 / (g.distancia_vazio_cm - g.distancia_cheio_cm) * 100, 1);
  nivel := least(100, greatest(0, nivel));
  qtd   := round(g.capacidade_litros * nivel / 100, 1);

  insert into leituras (dispositivo_id, galao_id, local_id, distancia_cm, nivel_pct, litros)
  values (d.id, g.id, g.local_id, distancia_cm, nivel, qtd);

  update galoes set nivel_pct = nivel, ultima_leitura_em = now() where id = g.id;

  if g.status = 'instalado' then
    select * into cfg from configuracoes;

    if nivel >= cfg.limite_atencao then
      insert into alertas (galao_id, local_id, tipo, nivel_pct)
      values (g.id, g.local_id, 'atencao', nivel)
      on conflict (galao_id, tipo) where resolvido_em is null do nothing;
    end if;

    if nivel >= cfg.limite_coleta then
      insert into alertas (galao_id, local_id, tipo, nivel_pct)
      values (g.id, g.local_id, 'coleta', nivel)
      on conflict (galao_id, tipo) where resolvido_em is null do nothing;

      insert into solicitacoes (local_id, galao_id, tipo, origem)
      values (g.local_id, g.id, 'coleta', 'automatica')
      on conflict (galao_id) where tipo = 'coleta' and status in ('pendente', 'agendada') do nothing;
    end if;
  end if;

  return json_build_object('ok', true, 'vinculado', true, 'galao', g.codigo,
                           'nivel_pct', nivel, 'litros', qtd);
end;
$$;

-- ---------------------------------------------------------------------
-- 2) Quem cancelou: o cliente vê um aviso quando a equipe cancela.
-- ---------------------------------------------------------------------
alter table solicitacoes add column cancelado_por papel_usuario;
alter table solicitacoes add column cancelada_em timestamptz;

create or replace function cancelar_solicitacao(solicitacao uuid)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
begin
  update solicitacoes so
     set status = 'cancelada', cancelada_em = now(),
         cancelado_por = (select papel from perfis where id = auth.uid())
   where so.id = solicitacao and so.status in ('pendente', 'agendada')
     and (eh_empresa() or exists (select 1 from locais l where l.id = so.local_id and l.cliente_id = auth.uid()))
  returning * into s;
  if not found then
    raise exception 'Solicitação não pode ser cancelada.';
  end if;
  return s;
end;
$$;

-- ---------------------------------------------------------------------
-- 3) Troca com litros informados pela equipe (o sensor só estima).
-- ---------------------------------------------------------------------
drop function concluir_coleta(uuid, uuid);

create function concluir_coleta(solicitacao uuid, galao_novo uuid, litros numeric default null)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
  antigo galoes;
  qtd numeric;
begin
  perform exigir_empresa();
  select * into s from solicitacoes
   where id = solicitacao and tipo = 'coleta' and status in ('pendente', 'agendada') for update;
  if not found then
    raise exception 'Solicitação de coleta não encontrada ou já encerrada.';
  end if;

  select * into antigo from galoes where id = s.galao_id for update;
  qtd := coalesce(round(litros, 1), round(antigo.capacidade_litros * antigo.nivel_pct / 100, 1));
  if qtd <= 0 or qtd > antigo.capacidade_litros then
    raise exception 'Informe um volume entre 0,1 e % L.', antigo.capacidade_litros;
  end if;

  update galoes set status = 'reciclagem', local_id = null, instalado_em = null where id = antigo.id;

  update galoes set status = 'instalado', local_id = s.local_id, nivel_pct = 0, instalado_em = now()
   where id = galao_novo and status = 'estoque';
  if not found then
    raise exception 'Galão novo indisponível no estoque.';
  end if;

  update dispositivos set galao_id = galao_novo where galao_id = antigo.id;

  update alertas set resolvido_em = now() where galao_id = antigo.id and resolvido_em is null;

  insert into reciclagens (solicitacao_id, galao_id, local_id, litros, valor_litro)
  select s.id, antigo.id, s.local_id, qtd, valor_litro from configuracoes;

  update solicitacoes set status = 'concluida', concluida_em = now(),
         galao_entregue_id = galao_novo, litros_coletados = qtd
   where id = s.id returning * into s;
  return s;
end;
$$;

-- ---------------------------------------------------------------------
-- 4) Desfazer troca (até 30 minutos depois): volta galões, sensor, alertas e pedido.
-- ---------------------------------------------------------------------
create function desfazer_coleta(solicitacao uuid)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
begin
  perform exigir_empresa();
  select * into s from solicitacoes
   where id = solicitacao and tipo = 'coleta' and status = 'concluida' for update;
  if not found then
    raise exception 'Troca não encontrada.';
  end if;
  if s.concluida_em < now() - interval '30 minutes' then
    raise exception 'Só é possível desfazer uma troca nos primeiros 30 minutos.';
  end if;

  update galoes set status = 'estoque', local_id = null, nivel_pct = 0, instalado_em = null
   where id = s.galao_entregue_id;
  update galoes set status = 'instalado', local_id = s.local_id, instalado_em = coalesce(instalado_em, now())
   where id = s.galao_id;
  update dispositivos set galao_id = s.galao_id where galao_id = s.galao_entregue_id;
  update alertas set resolvido_em = null where galao_id = s.galao_id and resolvido_em >= s.concluida_em;
  delete from reciclagens where solicitacao_id = s.id;

  update solicitacoes
     set status = case when agendada_para is not null then 'agendada'::status_solicitacao else 'pendente'::status_solicitacao end,
         concluida_em = null, galao_entregue_id = null, litros_coletados = null
   where id = s.id returning * into s;
  return s;
end;
$$;

revoke execute on function concluir_coleta(uuid, uuid, numeric), desfazer_coleta(uuid) from public, anon;
grant execute on function concluir_coleta(uuid, uuid, numeric), desfazer_coleta(uuid) to authenticated;
