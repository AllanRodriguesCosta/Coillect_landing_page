-- cOillect — esquema inicial
-- Perfis, locais, galões, dispositivos IoT, leituras, alertas, solicitações e reciclagens.

-- =====================================================================
-- Tipos
-- =====================================================================
create type papel_usuario      as enum ('cliente', 'empresa');
create type tipo_local         as enum ('condominio', 'restaurante', 'lanchonete', 'outro');
create type status_galao       as enum ('estoque', 'instalado', 'reciclagem');
create type tipo_alerta        as enum ('atencao', 'coleta');
create type tipo_solicitacao   as enum ('entrega', 'coleta');
create type origem_solicitacao as enum ('cliente', 'automatica');
create type status_solicitacao as enum ('pendente', 'agendada', 'concluida', 'cancelada');

-- =====================================================================
-- Tabelas
-- =====================================================================

-- Um registro por usuário do Supabase Auth.
create table perfis (
  id        uuid primary key references auth.users on delete cascade,
  papel     papel_usuario not null default 'cliente',
  nome      text not null,
  telefone  text,
  criado_em timestamptz not null default now()
);

-- Condomínio ou estabelecimento atendido.
create table locais (
  id          uuid primary key default gen_random_uuid(),
  cliente_id  uuid not null references perfis on delete cascade,
  tipo        tipo_local not null,
  nome        text not null,
  cep         text,
  logradouro  text not null,
  numero      text,
  complemento text,
  bairro      text,
  cidade      text not null,
  uf          char(2) not null,
  observacoes text,
  criado_em   timestamptz not null default now()
);
create index on locais (cliente_id);

-- Galão físico. A calibração converte a distância medida pelo sensor em nível.
create table galoes (
  id                 uuid primary key default gen_random_uuid(),
  codigo             text not null unique,
  capacidade_litros  numeric(6,1) not null default 50 check (capacidade_litros > 0),
  distancia_vazio_cm numeric(6,1) not null default 40,  -- sensor → fundo
  distancia_cheio_cm numeric(6,1) not null default 5,   -- sensor → óleo no limite
  status             status_galao not null default 'estoque',
  local_id           uuid references locais on delete set null,
  nivel_pct          numeric(5,1) not null default 0,
  ultima_leitura_em  timestamptz,
  instalado_em       timestamptz,
  criado_em          timestamptz not null default now(),
  check (distancia_vazio_cm > distancia_cheio_cm),
  check ((status = 'instalado') = (local_id is not null))
);
create index on galoes (local_id);

-- Sensor IoT (ESP32 + HC-SR04). Reaproveitado: na troca, passa para o galão vazio.
create table dispositivos (
  id                uuid primary key default gen_random_uuid(),
  codigo            text not null unique,
  chave_hash        text unique,          -- SHA-256 da chave; a chave só é exibida ao ser gerada
  galao_id          uuid unique references galoes on delete set null,
  ultimo_contato_em timestamptz,
  criado_em         timestamptz not null default now()
);

create table leituras (
  id             bigint generated always as identity primary key,
  dispositivo_id uuid not null references dispositivos on delete cascade,
  galao_id       uuid not null references galoes on delete cascade,
  distancia_cm   numeric(6,1) not null,
  nivel_pct      numeric(5,1) not null,
  litros         numeric(6,1) not null,
  criado_em      timestamptz not null default now()
);
create index on leituras (galao_id, criado_em desc);

create table alertas (
  id           uuid primary key default gen_random_uuid(),
  galao_id     uuid not null references galoes on delete cascade,
  local_id     uuid not null references locais on delete cascade,
  tipo         tipo_alerta not null,
  nivel_pct    numeric(5,1) not null,
  criado_em    timestamptz not null default now(),
  lido_em      timestamptz,
  resolvido_em timestamptz
);
-- No máximo um alerta aberto de cada tipo por galão.
create unique index alertas_aberto_unico on alertas (galao_id, tipo) where resolvido_em is null;
create index on alertas (local_id, criado_em desc);

create table solicitacoes (
  id                uuid primary key default gen_random_uuid(),
  local_id          uuid not null references locais on delete cascade,
  galao_id          uuid references galoes on delete set null,  -- galão a coletar (tipo coleta)
  tipo              tipo_solicitacao not null,
  origem            origem_solicitacao not null default 'cliente',
  status            status_solicitacao not null default 'pendente',
  agendada_para     timestamptz,
  observacoes       text,
  galao_entregue_id uuid references galoes on delete set null,
  litros_coletados  numeric(6,1),
  criado_por        uuid references perfis on delete set null,
  criado_em         timestamptz not null default now(),
  concluida_em      timestamptz,
  check (tipo = 'entrega' or galao_id is not null)
);
-- Evita solicitações duplicadas em aberto.
create unique index solicitacao_entrega_aberta on solicitacoes (local_id)
  where tipo = 'entrega' and status in ('pendente', 'agendada');
create unique index solicitacao_coleta_aberta on solicitacoes (galao_id)
  where tipo = 'coleta' and status in ('pendente', 'agendada');
create index on solicitacoes (status, criado_em desc);

-- Destinação do óleo coletado e receita estimada.
create table reciclagens (
  id             uuid primary key default gen_random_uuid(),
  solicitacao_id uuid not null unique references solicitacoes on delete cascade,
  galao_id       uuid references galoes on delete set null,
  local_id       uuid references locais on delete set null,
  litros         numeric(6,1) not null,
  valor_litro    numeric(6,2) not null,
  valor_total    numeric(10,2) generated always as (round(litros * valor_litro, 2)) stored,
  criado_em      timestamptz not null default now()
);

-- Parâmetros do sistema (linha única).
create table configuracoes (
  id             boolean primary key default true check (id),
  limite_atencao numeric(5,1) not null default 70,
  limite_coleta  numeric(5,1) not null default 90,
  valor_litro    numeric(6,2) not null default 2.00,
  check (limite_atencao < limite_coleta)
);
insert into configuracoes default values;

-- =====================================================================
-- Funções auxiliares
-- =====================================================================

create function eh_empresa() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from perfis where id = auth.uid() and papel = 'empresa');
$$;

create function exigir_empresa() returns void
language plpgsql stable security definer set search_path = public as $$
begin
  if not eh_empresa() then
    raise exception 'Apenas a empresa pode executar esta ação.' using errcode = '42501';
  end if;
end;
$$;

-- Cadastro público sempre cria perfil de cliente; contas da empresa são promovidas manualmente.
create function criar_perfil() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into perfis (id, nome, telefone)
  values (new.id,
          coalesce(nullif(new.raw_user_meta_data->>'nome', ''), split_part(new.email, '@', 1)),
          new.raw_user_meta_data->>'telefone');
  return new;
end;
$$;

create trigger ao_criar_usuario
  after insert on auth.users
  for each row execute function criar_perfil();

-- =====================================================================
-- Sensor IoT
-- =====================================================================

-- Chamada pelo ESP32: POST /rest/v1/rpc/registrar_leitura {"chave": "...", "distancia_cm": 23.4}
create function registrar_leitura(chave text, distancia_cm numeric)
returns json
language plpgsql security definer set search_path = public as $$
declare
  d dispositivos;
  g galoes;
  cfg configuracoes;
  nivel numeric;
  qtd numeric;
begin
  select * into d from dispositivos
   where chave_hash = encode(sha256(convert_to(chave, 'UTF8')), 'hex');
  if not found then
    raise exception 'Chave de dispositivo inválida.' using errcode = '28000';
  end if;

  update dispositivos set ultimo_contato_em = now() where id = d.id;

  if d.galao_id is null then
    return json_build_object('ok', true, 'vinculado', false);
  end if;

  select * into g from galoes where id = d.galao_id for update;

  nivel := round((g.distancia_vazio_cm - distancia_cm)
                 / (g.distancia_vazio_cm - g.distancia_cheio_cm) * 100, 1);
  nivel := least(100, greatest(0, nivel));
  qtd   := round(g.capacidade_litros * nivel / 100, 1);

  insert into leituras (dispositivo_id, galao_id, distancia_cm, nivel_pct, litros)
  values (d.id, g.id, distancia_cm, nivel, qtd);

  update galoes set nivel_pct = nivel, ultima_leitura_em = now() where id = g.id;

  if g.status = 'instalado' then
    select * into cfg from configuracoes;

    if nivel >= cfg.limite_atencao then
      insert into alertas (galao_id, local_id, tipo, nivel_pct)
      values (g.id, g.local_id, 'atencao', nivel)
      on conflict (galao_id, tipo) where resolvido_em is null do nothing;
    end if;

    if nivel >= cfg.limite_coleta then
      insert into alertas (galao_id, local_id, tipo, nivel_pct)
      values (g.id, g.local_id, 'coleta', nivel)
      on conflict (galao_id, tipo) where resolvido_em is null do nothing;

      insert into solicitacoes (local_id, galao_id, tipo, origem)
      values (g.local_id, g.id, 'coleta', 'automatica')
      on conflict (galao_id) where tipo = 'coleta' and status in ('pendente', 'agendada') do nothing;
    end if;
  end if;

  return json_build_object('ok', true, 'vinculado', true, 'galao', g.codigo,
                           'nivel_pct', nivel, 'litros', qtd);
end;
$$;

-- Gera uma nova chave para o dispositivo e devolve o valor em texto (exibido uma única vez).
create function gerar_chave_dispositivo(dispositivo uuid)
returns text
language plpgsql security definer set search_path = public, extensions as $$
declare
  chave text := encode(gen_random_bytes(24), 'hex');
begin
  perform exigir_empresa();
  update dispositivos set chave_hash = encode(sha256(convert_to(chave, 'UTF8')), 'hex')
   where id = dispositivo;
  if not found then
    raise exception 'Dispositivo não encontrado.';
  end if;
  return chave;
end;
$$;

-- =====================================================================
-- Fluxo de solicitações
-- =====================================================================

-- Cliente solicita galão (entrega) ou coleta antecipada de um galão do seu local.
create function solicitar(local uuid, tipo tipo_solicitacao, galao uuid default null, observacoes text default null)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
begin
  if not exists (select 1 from locais l where l.id = local and l.cliente_id = auth.uid()) then
    raise exception 'Local não pertence ao usuário.' using errcode = '42501';
  end if;
  if tipo = 'coleta' and not exists (
       select 1 from galoes g where g.id = galao and g.local_id = local and g.status = 'instalado') then
    raise exception 'Galão não está instalado neste local.';
  end if;

  insert into solicitacoes (local_id, galao_id, tipo, origem, observacoes, criado_por)
  values (local, case when tipo = 'coleta' then galao end, tipo, 'cliente', observacoes, auth.uid())
  returning * into s;
  return s;
exception when unique_violation then
  raise exception 'Já existe uma solicitação em aberto para este pedido.';
end;
$$;

create function agendar_solicitacao(solicitacao uuid, data timestamptz)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
begin
  perform exigir_empresa();
  update solicitacoes set status = 'agendada', agendada_para = data
   where id = solicitacao and status in ('pendente', 'agendada')
  returning * into s;
  if not found then
    raise exception 'Solicitação não pode ser agendada.';
  end if;
  return s;
end;
$$;

create function cancelar_solicitacao(solicitacao uuid)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
begin
  update solicitacoes so set status = 'cancelada'
   where so.id = solicitacao and so.status in ('pendente', 'agendada')
     and (eh_empresa() or exists (select 1 from locais l where l.id = so.local_id and l.cliente_id = auth.uid()))
  returning * into s;
  if not found then
    raise exception 'Solicitação não pode ser cancelada.';
  end if;
  return s;
end;
$$;

-- Entrega de galão vazio: instala o galão no local do cliente.
create function concluir_entrega(solicitacao uuid, galao uuid)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
begin
  perform exigir_empresa();
  select * into s from solicitacoes
   where id = solicitacao and tipo = 'entrega' and status in ('pendente', 'agendada') for update;
  if not found then
    raise exception 'Solicitação de entrega não encontrada ou já encerrada.';
  end if;

  update galoes set status = 'instalado', local_id = s.local_id, nivel_pct = 0, instalado_em = now()
   where id = galao and status = 'estoque';
  if not found then
    raise exception 'Galão indisponível no estoque.';
  end if;

  update solicitacoes set status = 'concluida', concluida_em = now(), galao_entregue_id = galao
   where id = s.id returning * into s;
  return s;
end;
$$;

-- Troca: retira o galão cheio (vai para reciclagem), instala um vazio e transfere o sensor.
create function concluir_coleta(solicitacao uuid, galao_novo uuid)
returns solicitacoes
language plpgsql security definer set search_path = public as $$
declare
  s solicitacoes;
  antigo galoes;
  qtd numeric;
begin
  perform exigir_empresa();
  select * into s from solicitacoes
   where id = solicitacao and tipo = 'coleta' and status in ('pendente', 'agendada') for update;
  if not found then
    raise exception 'Solicitação de coleta não encontrada ou já encerrada.';
  end if;

  select * into antigo from galoes where id = s.galao_id for update;
  qtd := round(antigo.capacidade_litros * antigo.nivel_pct / 100, 1);

  update galoes set status = 'reciclagem', local_id = null, instalado_em = null where id = antigo.id;

  update galoes set status = 'instalado', local_id = s.local_id, nivel_pct = 0, instalado_em = now()
   where id = galao_novo and status = 'estoque';
  if not found then
    raise exception 'Galão novo indisponível no estoque.';
  end if;

  update dispositivos set galao_id = galao_novo where galao_id = antigo.id;

  update alertas set resolvido_em = now() where galao_id = antigo.id and resolvido_em is null;

  insert into reciclagens (solicitacao_id, galao_id, local_id, litros, valor_litro)
  select s.id, antigo.id, s.local_id, qtd, valor_litro from configuracoes;

  update solicitacoes set status = 'concluida', concluida_em = now(),
         galao_entregue_id = galao_novo, litros_coletados = qtd
   where id = s.id returning * into s;
  return s;
end;
$$;

-- Galão higienizado após a reciclagem volta ao estoque.
create function liberar_galao(galao uuid)
returns galoes
language plpgsql security definer set search_path = public as $$
declare
  g galoes;
begin
  perform exigir_empresa();
  update galoes set status = 'estoque', nivel_pct = 0
   where id = galao and status = 'reciclagem' returning * into g;
  if not found then
    raise exception 'Galão não está em reciclagem.';
  end if;
  return g;
end;
$$;

-- =====================================================================
-- Permissões e segurança em nível de linha (RLS)
-- =====================================================================

alter table perfis        enable row level security;
alter table locais        enable row level security;
alter table galoes        enable row level security;
alter table dispositivos  enable row level security;
alter table leituras      enable row level security;
alter table alertas       enable row level security;
alter table solicitacoes  enable row level security;
alter table reciclagens   enable row level security;
alter table configuracoes enable row level security;

-- Funções: execução apenas por quem precisa.
revoke execute on all functions in schema public from public, anon;
grant execute on function registrar_leitura(text, numeric) to anon, authenticated;
grant execute on function eh_empresa(), solicitar(uuid, tipo_solicitacao, uuid, text),
  agendar_solicitacao(uuid, timestamptz), cancelar_solicitacao(uuid),
  concluir_entrega(uuid, uuid), concluir_coleta(uuid, uuid), liberar_galao(uuid),
  gerar_chave_dispositivo(uuid) to authenticated;

-- perfis
create policy "perfil: ler o próprio ou empresa" on perfis for select to authenticated
  using (id = auth.uid() or eh_empresa());
create policy "perfil: editar o próprio" on perfis for update to authenticated
  using (id = auth.uid());
-- O papel não pode ser alterado pelo próprio usuário.
revoke update on perfis from authenticated;
grant update (nome, telefone) on perfis to authenticated;

-- locais
create policy "local: cliente lê os seus, empresa lê todos" on locais for select to authenticated
  using (cliente_id = auth.uid() or eh_empresa());
create policy "local: cliente cadastra" on locais for insert to authenticated
  with check (cliente_id = auth.uid());
create policy "local: cliente ou empresa edita" on locais for update to authenticated
  using (cliente_id = auth.uid() or eh_empresa());

-- galoes
create policy "galão: cliente lê os do seu local, empresa lê todos" on galoes for select to authenticated
  using (eh_empresa() or local_id in (select id from locais where cliente_id = auth.uid()));
create policy "galão: empresa cadastra" on galoes for insert to authenticated with check (eh_empresa());
create policy "galão: empresa edita" on galoes for update to authenticated using (eh_empresa());

-- dispositivos (apenas empresa)
create policy "dispositivo: empresa lê" on dispositivos for select to authenticated using (eh_empresa());
create policy "dispositivo: empresa cadastra" on dispositivos for insert to authenticated with check (eh_empresa());
create policy "dispositivo: empresa edita" on dispositivos for update to authenticated using (eh_empresa());

-- leituras
create policy "leitura: cliente lê as do seu local, empresa lê todas" on leituras for select to authenticated
  using (eh_empresa() or galao_id in (
    select g.id from galoes g join locais l on l.id = g.local_id where l.cliente_id = auth.uid()));

-- alertas
create policy "alerta: cliente lê os seus, empresa lê todos" on alertas for select to authenticated
  using (eh_empresa() or local_id in (select id from locais where cliente_id = auth.uid()));
create policy "alerta: marcar como lido" on alertas for update to authenticated
  using (eh_empresa() or local_id in (select id from locais where cliente_id = auth.uid()));
-- Pelo app, só o campo lido_em pode ser alterado.
revoke update on alertas from authenticated;
grant update (lido_em) on alertas to authenticated;

-- solicitacoes (escrita via funções)
create policy "solicitação: cliente lê as suas, empresa lê todas" on solicitacoes for select to authenticated
  using (eh_empresa() or local_id in (select id from locais where cliente_id = auth.uid()));

-- reciclagens
create policy "reciclagem: cliente lê as suas, empresa lê todas" on reciclagens for select to authenticated
  using (eh_empresa() or local_id in (select id from locais where cliente_id = auth.uid()));

-- configuracoes
create policy "configuração: todos leem" on configuracoes for select to authenticated using (true);
create policy "configuração: empresa edita" on configuracoes for update to authenticated using (eh_empresa());

-- =====================================================================
-- Tempo real
-- =====================================================================
alter publication supabase_realtime add table galoes, alertas, solicitacoes, leituras;
