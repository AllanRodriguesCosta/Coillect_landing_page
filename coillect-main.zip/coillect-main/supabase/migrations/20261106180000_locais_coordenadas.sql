-- Coordenadas do local para o mapa (OpenStreetMap). Preenchidas no cadastro a partir do
-- endereço; podem ficar vazias, e o local só não aparece no mapa.
alter table locais
  add column latitude  numeric(9,6) check (latitude between -90 and 90),
  add column longitude numeric(9,6) check (longitude between -180 and 180),
  add constraint locais_coordenadas_juntas check ((latitude is null) = (longitude is null));
