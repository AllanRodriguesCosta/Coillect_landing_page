<p align="center"><img src="assets/icone.png" width="120" alt="cOillect"></p>

# cOillect

Plataforma de coleta de óleo de cozinha usado com monitoramento por sensor IoT.

Condomínios e estabelecimentos (restaurantes, lanchonetes) recebem um galão com sensor
instalado. O sensor mede o volume de óleo e envia as leituras para a nuvem; o aplicativo
mostra o nível em tempo real e emite alertas em **70%** e **90%**. No segundo alerta, a
empresa coletora troca o galão cheio por um vazio e destina o óleo à reciclagem.

> Projeto Integrador — Fatec Cotia, Desenvolvimento de Software Multiplataforma.

## Perfis

| Perfil | Quem | O que faz |
|---|---|---|
| **Cliente** | Síndico de condomínio ou responsável por estabelecimento | Solicita galão, acompanha o nível, recebe alertas, solicita coleta |
| **Empresa** | Equipe cOillect (coletora) | Atende solicitações, instala galões e sensores, agenda trocas, registra reciclagem |

## Arquitetura

```
ESP32 + HC-SR04 ──HTTPS──▶ Supabase API (rpc/registrar_leitura)
                                  │
                                  ▼
                       Supabase Postgres + Auth + Realtime
                                  │
                ┌─────────────────┴─────────────────┐
          App Cliente (PWA)                  App Empresa (PWA)
                └──────── hospedado na Vercel ───────┘
```

## Estrutura do repositório

| Pasta | Conteúdo |
|---|---|
| `app/` | Aplicativo web mobile-first (React + Vite, PWA) |
| `supabase/` | Migrations SQL: tabelas, regras de negócio e de acesso |
| `firmware/` | Código MicroPython do ESP32 com sensor HC-SR04 |
| `tools/` | Dados de demonstração, teste de ponta a ponta e simulador do sensor |
| `docs/` | Documentação técnica, diagramas e planejamento |
| `assets/` | Identidade visual |

## Documentação

- [Plano e cronograma](docs/00-plano-e-cronograma.md)
- [Registro de decisões](docs/01-decisoes.md)
- [Requisitos](docs/02-requisitos.md)
- [Casos de uso e fluxos](docs/03-casos-de-uso.md)
- [Modelo de dados](docs/04-modelo-de-dados.md)
- [Arquitetura](docs/05-arquitetura.md)
- [Contrato do sensor IoT](docs/06-contrato-iot.md)
- [Ambiente e testes](docs/07-ambiente-e-testes.md)
- [Integração do sensor (montagem, calibração, testes)](docs/08-integracao-iot.md)
- [App Android (APK)](docs/09-app-android.md)
- [Trabalho escrito ABNT (PDF)](docs/trabalho-escrito/cOillect_Trabalho_Escrito_ABNT.pdf) — fontes e gerador em [`docs/trabalho-escrito`](docs/trabalho-escrito)
- [Protótipo navegável](docs/prototipo/index.html) — abra o arquivo no navegador

## Acesse

- **App publicado:** https://coillect.vercel.app (instalável no celular: "Adicionar à tela inicial" ou pelo [APK Android](docs/09-app-android.md))
- **Protótipo navegável:** [`docs/prototipo/index.html`](docs/prototipo/index.html)

## Status

App, banco, ESP32 e trabalho escrito concluídos. Próximo passo: apresentação em 28/11
(slides e demonstração). Acompanhe no [plano](docs/00-plano-e-cronograma.md).
