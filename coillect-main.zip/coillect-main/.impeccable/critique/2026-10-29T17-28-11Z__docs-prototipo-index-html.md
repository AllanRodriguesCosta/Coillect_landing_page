---
target: protótipo cOillect
total_score: 32
max_score: 40
na_heuristics: 
p0_count: 0
p1_count: 2
target_identity: "file:/home/darch/Projects/cOillect/coillect/.claude/worktrees/etapa-1-2-banco/docs/prototipo/index.html"
target_fingerprint: "sha256:5abe17004cc75376090563534557af420be49a59e779086dbac9bba39c674891"
target_path: /home/darch/Projects/cOillect/coillect/.claude/worktrees/etapa-1-2-banco/docs/prototipo/index.html
timestamp: 2026-10-29T17-28-11Z
slug: docs-prototipo-index-html
---
Method: dual-agent (A: design review subagent · B: detector subagent). A ran in Chrome on the user's laptop (deviceId 41080a84…) at 581px plus local headless Chromium renders for wide/dark layouts; B ran the CLI only (overlay impossible: cross-origin claude.ai iframe).

## Design Health Score: 32/40 (Good) — previous 25/40
| # | Heuristic | Score | Key Issue |
|---|---|---|---|
| 1 | Visibility of System Status | 4 | Live "Atualizado há", order tracker, offline banner |
| 2 | Match System / Real World | 4 | Product vocabulary (troca, galão, litros) |
| 3 | User Control and Freedom | 4 | Undo swap, "Manter pedido", Esc/× on sheets |
| 4 | Consistency and Standards | 3 | Amber means both "Atenção" and "Agendado"; litres input shows "46.5" |
| 5 | Error Prevention | 3 | Duplicate-order guard, calibration validation, prefilled litres |
| 6 | Recognition Rather Than Recall | 3 | Phone Painel cards don't show next action |
| 7 | Flexibility and Efficiency | 3 | Sortable table/queue on desktop; no route/day filter on phone |
| 8 | Aesthetic and Minimalist | 3 | Phone order card shows 5 actions |
| 9 | Error Recovery | 3 | Specific errors; offline banner not actionable |
| 10 | Help and Documentation | 2 | No guidance for client near overflow |

## Design Specificity
Authored: jug signature (sensor on cap, wave, 70/90 ticks) reused in bars, details sheet and swap result; swap moment (full jug out, empty in, sensor lands) is product-specific. Generic: office KPI row + sidebar + table, card styling.
Detector: 0 anti-patterns; 1 advisory shape-assembled-illustration on jug SVG = false positive (live data graphic). Real issue missed by detector: --ferrugem #B3441A on --ferrugem-suave #F8E1D7 (light) = 4.45:1 (<4.5 for normal text, e.g. chip "Troca necessária", aviso coleta). Earlier contrast alerts only occurred on a doctype-less test copy.

## Priority Issues
- [P1] No reassurance for the client near overflow (≥90%): add remaining litres, "pare de despejar e fale com a gente" + contact, expected window when scheduled. /impeccable clarify
- [P1] Conflicting status on client Início: chip "Troca necessária" next to tracker "Troca pedida" → map chip to order state for the client. /impeccable clarify
- [P2] Phone order card has 5 actions for one-handed use → keep Concluir primary, Agendar into Mais opções, map/phone as icon buttons; consider undo via toast. /impeccable distill, adapt
- [P2] Offline-sensor alert is a dead end → tap opens site sheet with call + view jug. /impeccable harden
- [P3] Color/locale: amber for "Agendado"; litres input dot decimal; ferrugem chip contrast 4.45:1. /impeccable polish

## Persona Red Flags
- Casey: "Detalhes do sensor" small summary target; bell is only entry to Avisos.
- Jordan: "Troca necessária" vs "Troca pedida"; no hint when to request an early swap.
- Sam: body text 12–13.5px in meta lines; focus ring seen on "Desfazer troca" in a headless render built before the focus fix (verify).
- Field collector: Concluir at top of a long card; Agendar adjacent; litres keyboard dot decimal; Desfazer equal size beside Pronto.

## Minor Observations
Phone Painel cards' tappability unclear; KPI "acima de 70%" duplicates table; recycling bin hidden behind filter; simulator slider in cm runs reverse (may confuse live audience).

## Questions to Consider
1. Should client Início answer "preciso fazer algo?" in one sentence before the percentage?
2. Should the collector's phone be a "Rota de hoje" list instead of a slim office Painel?
3. If the model becomes paid, does "Receita estimada" belong in the collector's swap moment?
