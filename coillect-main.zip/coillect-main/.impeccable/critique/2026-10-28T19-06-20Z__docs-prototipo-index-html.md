---
target: protótipo cOillect
total_score: 25
max_score: 40
na_heuristics: 
p0_count: 0
p1_count: 3
target_identity: "file:/home/darch/Projects/cOillect/coillect/.claude/worktrees/etapa-1-2-banco/docs/prototipo/index.html"
target_fingerprint: "sha256:6adc90e60872cf0f4ebcdbbfee4eda36a2a8de646951aff1dbca8b97b0e1533d"
target_path: /home/darch/Projects/cOillect/coillect/.claude/worktrees/etapa-1-2-banco/docs/prototipo/index.html
timestamp: 2026-10-28T19-06-20Z
slug: docs-prototipo-index-html
---
Method: dual-agent (A: design review subagent · B: detector subagent). Note: a first Assessment A attempt ran on a browser on another machine and was discarded; the valid A ran on the user's browser (Felippi Notebook). B's browser preflight ran on another machine's browser (title change + script tag on a temporary tab, closed).

## Design Health Score: 25/40 (Acceptable)
| # | Heuristic | Score | Key Issue |
|---|---|---|---|
| 1 | Visibility of System Status | 3 | Live level/offline banner good; toast covers header; no order timeline |
| 2 | Match System / Real World | 3 | "Medição: X cm" and sensor code on síndico home |
| 3 | User Control and Freedom | 2 | No undo on Concluir troca; Gerar chave one-tap; no Esc in sheets; cadastro step 2 no back |
| 4 | Consistency and Standards | 2 | Painel 4 abertos vs badge 3; "2.00" dot decimal; bars mark only 70 |
| 5 | Error Prevention | 2 | Agendar/Concluir/Cancelar adjacent 38px; liters not correctable |
| 6 | Recognition Rather Than Recall | 3 | Good sheet summaries; empresa Pedidos sorted by age not urgency |
| 7 | Flexibility and Efficiency | 2 | Phone-only for office; no search/bulk; phone not tappable |
| 8 | Aesthetic and Minimalist | 3 | Calibration line repeated; inverted cream cards loud in dark |
| 9 | Error Recovery | 3 | Inline errors in calibração/ajustes; guided empty-stock toast |
| 10 | Help and Documentation | 2 | Good inline tips; no help/contact anywhere |

## Design Specificity
Authored, not template: semantic palette (folha/âmbar/ferrugem), domain copy. Jug SVG (ESP32 on cap, beam, 70/90 ticks, LED) is a functional signature. It appears only on cliente Início and Painel sheet; empresa side falls back to generic KPI tiles/bars/repeated cards; the swap moment is never visualized.
Detector: 0 anti-patterns; 1 advisory shape-assembled-illustration on the jug SVG (svgGalao, viewBox 0 0 212 236) = false positive (live data graphic). Detector missed light-mode contrast issues found in review. Overlay not possible (cross-origin claude.ai iframe).

## Priority Issues
- [P1] No desktop layout for office (Empresa) → table of all jugs + order queue. /impeccable adapt, layout
- [P1] innerHTML re-render every 2s kills focus; sheets lack Esc/focus trap/return → patch values, aria-live. /impeccable harden
- [P1] Destructive actions unguarded: Gerar chave one-tap on live sensor; Cancelar next to Concluir at 38px; no undo; liters not editable. /impeccable harden
- [P2] Unsourced "25 mil litros" impact claim (PRODUCT.md principle 5); R$ framing staff-only. /impeccable clarify
- [P2] Client can't see order progress after 90%; stale 70% alert copy; disabled "Pedir troca". 3-step tracker. /impeccable clarify, delight

## Persona Red Flags
- Casey: bell + toast at top, toast covers bell 3.6s; 38px buttons; "Pedir galão" as main button on Pedidos.
- Jordan: "Medição: 7,0 cm" and ESP32-01 on home; login role toggle; no "Esqueci a senha"; no help in Conta.
- Sam: focus reset every 2s; no Esc; light contrast amber 3.17:1, green chip 3.77:1, logo "Oil" 2.74:1; dark badge 2.93:1.
- Field collector: list sorted by age; address not map link; phone not tappable; jug chosen in <select>; liters not editable; Concluir next to Cancelar.

## Minor Observations
"há 34 s"/measurement wrap; Pedidos titles wrap due to chip; chart caption mentions drops not visible in 10-day window; "galão(ões)"; datetime input in browser locale; Ajustes no preview of threshold effect; Galões bars only 70%.

## Questions to Consider
1. Could the office Painel be a wall of mini-jugs instead of KPI tiles?
2. At 90%+, should cliente Início become a full "troca a caminho" state instead of a disabled button?
3. Does the collector need a "Rota de hoje" with one big action per stop instead of the office list?
