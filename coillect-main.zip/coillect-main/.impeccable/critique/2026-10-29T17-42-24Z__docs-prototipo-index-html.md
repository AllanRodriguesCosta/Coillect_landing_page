---
target: protótipo cOillect
total_score: 27
max_score: 40
na_heuristics: 
p0_count: 0
p1_count: 1
target_identity: "file:/home/darch/Projects/cOillect/coillect/.claude/worktrees/etapa-1-2-banco/docs/prototipo/index.html"
target_fingerprint: "sha256:5246baffa381bf619e7ad791905f9481e368212bd06b8b71e857fb1fa6cf0fed"
target_path: /home/darch/Projects/cOillect/coillect/.claude/worktrees/etapa-1-2-banco/docs/prototipo/index.html
timestamp: 2026-10-29T17-42-24Z
slug: docs-prototipo-index-html
---
Method: dual-agent (A: design review subagent in Chrome on the user's laptop, deviceId 41080a84…, plus local headless renders · B: detector CLI). Reviewer differed from previous run; scores vary between independent reviewers.

## Design Health Score: 27/40 (Acceptable, top of band) — assessed version 7
| # | Heuristic | Score | Key Issue |
|---|---|---|---|
| 1 | Visibility of System Status | 3 | Timeline marked "Troca agendada" current without a date; stale 74% looked current |
| 2 | Match System / Real World | 3 | ESP32 jargon in copy relayed to clients |
| 3 | User Control and Freedom | 3 | Undo, Esc, focus return, "Manter pedido" |
| 4 | Consistency and Standards | 2 | Primary action changed by screen; "Trocar galão" vs "Concluir troca"; request vs swap dates |
| 5 | Error Prevention | 3 | Prefilled litres, confirmations, empty-stock guard |
| 6 | Recognition Rather Than Recall | 3 | Client alerts only behind the bell |
| 7 | Flexibility and Efficiency | 2 | No client search, batch scheduling or route view |
| 8 | Aesthetic and Minimalist | 3 | Histórico repeats Pedidos; desktop queue duplicates table actions |
| 9 | Error Recovery | 3 | Offline sensor leads to call |
| 10 | Help and Documentation | 2 | No help on calibration or statuses |

Detector (B): 0 anti-patterns; 1 advisory (jug SVG, false positive). All listed contrast pairs ≥4.5:1; unlisted --folha on --salvia ≈4.1:1 (links).

## Priority Issues (and outcome in version 8)
- [P1] Primary action did not follow urgency/role (regression from distill) → fixed: A agendar → Agendar primary, Agendado → Concluir; desktop table and queue aligned.
- [P2] Stale readings looked current → fixed: muted number/bar + "sem sinal".
- [P2] Open "Mais opções" broke the action row (regression) → fixed: floating menu, Cancelar last and separated.
- [P2] Timeline step "Troca agendada" without date → fixed: "Aguardando agendamento" until a date exists.
- [P3] Impact claim on fictitious data → kept with Sabesp attribution; confirm source in ABNT doc.
Also fixed: link contrast (--folha-texto), "Mudar de galão", secondary "Marcar todos como lidos", separators in offline button.

## Remaining (not addressed)
No client search, batch scheduling or route view; no help for calibration/statuses; request vs swap dates unlabelled; office side still generic (KPI + table); simulator slider direction.

## Questions to Consider
1. Should the collector's Pedidos be a day plan (route, stops, litres)?
2. Should the office desktop be one queue instead of KPIs + table + side column?
3. Could the office table use small jug glyphs instead of generic bars?
