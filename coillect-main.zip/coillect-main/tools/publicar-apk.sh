#!/usr/bin/env bash
# Gera, assina e publica uma versão nova do APK Android como release do GitHub.
#   tools/publicar-apk.sh 1.0.1               # gera e publica a release v1.0.1
#   tools/publicar-apk.sh 1.0.1 --so-gerar    # só gera o APK, sem publicar
# O projeto Android e a chave de assinatura ficam fora do Git, em $ANDROID_DIR.
# Passo a passo e ambiente: docs/09-app-android.md.
set -euo pipefail
VERSAO=${1:-}
SO_GERAR=${2:-}
ANDROID_DIR=${ANDROID_DIR:-$HOME/Projects/FATEC/cOillect/coillect-android}
BW=$HOME/.local/share/bubblewrap/node_modules/.bin/bubblewrap
JAVA_BIN=$(mise where java@temurin-17.0.21+9)/bin
APKSIGNER=$HOME/.local/share/android-sdk/build-tools/36.1.0/apksigner
RAIZ=$(cd "$(dirname "$0")/.." && pwd)

[[ $VERSAO =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "uso: $0 <x.y.z> [--so-gerar]"; exit 1; }
[ -f "$ANDROID_DIR/assinatura/coillect.keystore" ] || { echo "Chave de assinatura não encontrada em $ANDROID_DIR/assinatura"; exit 1; }
if [ "$SO_GERAR" != "--so-gerar" ] && gh release view "v$VERSAO" -R DarchLord/coillect >/dev/null 2>&1; then
  echo "A release v$VERSAO já existe no GitHub. Use uma versão nova."; exit 1
fi

# Código da versão: um a mais que o do último APK gerado (o Android exige que só cresça).
ANTERIOR=$(node -e "try{console.log(require('$ANDROID_DIR/twa-manifest.json').appVersionCode)}catch{console.log(0)}")
CODIGO=$((ANTERIOR + 1))
echo "Gerando cOillect $VERSAO (código $CODIGO)..."

node "$RAIZ/tools/android/twa-manifest.cjs" "$ANDROID_DIR" "$VERSAO" "$CODIGO"
cd "$ANDROID_DIR"
"$BW" update --skipVersionUpgrade </dev/null >/dev/null
SENHA=$(sed -n 's/^Senha (keystore e chave): //p' assinatura/SENHA.txt)
BUBBLEWRAP_KEYSTORE_PASSWORD="$SENHA" BUBBLEWRAP_KEY_PASSWORD="$SENHA" \
  "$BW" build --skipPwaValidation </dev/null >build.log 2>&1 || { echo "Build falhou; veja $ANDROID_DIR/build.log"; exit 1; }

APK="$ANDROID_DIR/cOillect-$VERSAO.apk"
cp app-release-signed.apk "$APK"
PATH="$JAVA_BIN:$PATH" "$APKSIGNER" verify "$APK"
echo "APK assinado: $APK"

[ "$SO_GERAR" = "--so-gerar" ] && exit 0
gh release create "v$VERSAO" "$APK" -R DarchLord/coillect --target main --title "cOillect Android $VERSAO" \
  --notes "Instalar: baixe \`cOillect-$VERSAO.apk\` no celular e abra o arquivo (instala por cima da versão anterior). Pacote \`app.vercel.coillect\`, código $CODIGO, Android 7.0+."
