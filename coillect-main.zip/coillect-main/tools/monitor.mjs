// Monitor ao vivo da integração do sensor: mostra cada leitura que chega na nuvem,
// os alertas e os pedidos automáticos criados. Use durante os testes com o ESP32.
//
//   node tools/monitor.mjs              acompanha todos os sensores
//   node tools/monitor.mjs ESP32-01     acompanha um sensor
//
// Requer `npx supabase login`. A chave administrativa é obtida pelo CLI e não é gravada.
import { execSync } from 'node:child_process';
import { readFileSync } from 'node:fs';

const filtro = process.argv[2];
const ref = readFileSync(new URL('../supabase/.temp/project-ref', import.meta.url), 'utf8').trim();
const url = `https://${ref}.supabase.co`;
const chaves = JSON.parse(execSync(`npx -y supabase@2.122.0 projects api-keys --project-ref ${ref} -o json`, { stdio: ['ignore', 'pipe', 'ignore'] }));
const secret = chaves.find(k => k.name === 'service_role').api_key;
const headers = { apikey: secret, Authorization: `Bearer ${secret}` };
const get = async caminho => { const r = await fetch(`${url}/rest/v1/${caminho}`, { headers }); if (!r.ok) throw new Error(`${caminho}: ${r.status}`); return r.json(); };
const hora = t => new Date(t).toLocaleTimeString('pt-BR');

const sensores = Object.fromEntries((await get('dispositivos?select=id,codigo,galao_id,ultimo_contato_em')).map(d => [d.id, d]));
const galoes = Object.fromEntries((await get('galoes?select=id,codigo,distancia_vazio_cm,distancia_cheio_cm,capacidade_litros')).map(g => [g.id, g]));
const alvo = filtro && Object.values(sensores).find(d => d.codigo === filtro);
if (filtro && !alvo) { console.error(`Sensor ${filtro} não encontrado.`); process.exit(1); }

let desde = new Date().toISOString();
console.log(`Monitorando ${alvo ? alvo.codigo : 'todos os sensores'} a partir de ${hora(desde)}. Ctrl+C para sair.`);
for (const d of Object.values(sensores).filter(d => !alvo || d.id === alvo.id)) {
  const g = galoes[d.galao_id];
  console.log(`  ${d.codigo} → ${g ? `${g.codigo} (${g.capacidade_litros} L, vazio ${g.distancia_vazio_cm} cm, cheio ${g.distancia_cheio_cm} cm)` : 'sem galão'} · último contato ${d.ultimo_contato_em ? hora(d.ultimo_contato_em) : 'nunca'}`);
}

for (;;) {
  try {
    const filtroSensor = alvo ? `&dispositivo_id=eq.${alvo.id}` : '';
    const leituras = await get(`leituras?select=*&criado_em=gt.${encodeURIComponent(desde)}${filtroSensor}&order=criado_em`);
    const alertas = await get(`alertas?select=*&criado_em=gt.${encodeURIComponent(desde)}&order=criado_em`);
    const pedidos = await get(`solicitacoes?select=*&origem=eq.automatica&criado_em=gt.${encodeURIComponent(desde)}&order=criado_em`);
    for (const l of leituras) {
      console.log(`${hora(l.criado_em)}  ${(sensores[l.dispositivo_id]?.codigo || '?').padEnd(9)} ${String(l.distancia_cm).padStart(6)} cm → ${String(l.nivel_pct).padStart(5)}%  ${l.litros} L  (${galoes[l.galao_id]?.codigo})`);
    }
    for (const a of alertas) console.log(`${hora(a.criado_em)}  ALERTA ${a.tipo === 'coleta' ? 'de troca' : 'de atenção'} no ${galoes[a.galao_id]?.codigo} (${a.nivel_pct}%)`);
    for (const p of pedidos) console.log(`${hora(p.criado_em)}  PEDIDO automático de troca do ${galoes[p.galao_id]?.codigo}`);
    const ultimos = [...leituras, ...alertas, ...pedidos].map(x => x.criado_em).sort();
    if (ultimos.length) desde = ultimos.at(-1);
  } catch (e) {
    console.log(`(sem resposta da nuvem: ${e.message}; tentando de novo)`);
  }
  await new Promise(r => setTimeout(r, 2000));
}
