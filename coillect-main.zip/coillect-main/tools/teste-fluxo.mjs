// Teste de ponta a ponta do backend, usando a API pública como o app e o ESP32 usam.
// Pré-requisito: dados de demonstração recém-criados. Recebe a saída do seed:
//
//   node tools/seed/demo.mjs > seed.txt && node tools/teste-fluxo.mjs seed.txt

import { execSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const ref = readFileSync(new URL('../supabase/.temp/project-ref', import.meta.url), 'utf8').trim();
const url = `https://${ref}.supabase.co`;
const chaves = JSON.parse(execSync(`npx -y supabase@2.122.0 projects api-keys --project-ref ${ref} -o json`, { stdio: ['ignore', 'pipe', 'ignore'] }));
const publishable = chaves.find(k => k.type === 'publishable').api_key;

assert.ok(process.argv[2], 'informe o arquivo com a saída do seed');
const seed = readFileSync(process.argv[2], 'utf8');
const valor = rotulo => seed.match(new RegExp(`^${rotulo}.*\\s(\\S+)$`, 'm'))[1];
const DEMO_SENHA_EMPRESA = valor('Empresa');
const DEMO_SENHA_CLIENTE = valor('Cliente');
const DISPOSITIVO_CHAVE = valor('Dispositivo');

async function chamar(path, { token, method = 'GET', body } = {}) {
  const res = await fetch(`${url}${path}`, {
    method,
    headers: {
      apikey: publishable,
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body && JSON.stringify(body),
  });
  const texto = await res.text();
  return { status: res.status, dados: texto ? JSON.parse(texto) : null };
}

async function entrar(email, password) {
  const { status, dados } = await chamar('/auth/v1/token?grant_type=password', { method: 'POST', body: { email, password } });
  assert.equal(status, 200, `login de ${email}`);
  return dados.access_token;
}

const leitura = distancia_cm => chamar('/rest/v1/rpc/registrar_leitura', { method: 'POST', body: { chave: DISPOSITIVO_CHAVE, distancia_cm } });

let ok = 0;
function passo(nome) { ok++; console.log(`✓ ${nome}`); }

// --- Sensor ---------------------------------------------------------------
let r = await chamar('/rest/v1/rpc/registrar_leitura', { method: 'POST', body: { chave: 'errada', distancia_cm: 10 } });
assert.notEqual(r.status, 200);
passo('chave de dispositivo inválida é rejeitada');

const cliente = await entrar('sindico@coillect.test', DEMO_SENHA_CLIENTE);
const empresa = await entrar('empresa@coillect.test', DEMO_SENHA_EMPRESA);
passo('login dos dois perfis');

// O teste envia leituras em sequência rápida: zera o intervalo mínimo e restaura no fim.
const intervaloOriginal = (await chamar('/rest/v1/configuracoes?select=intervalo_minimo_s', { token: empresa })).dados[0].intervalo_minimo_s;
const intervalo = s => chamar('/rest/v1/configuracoes?id=eq.true', { token: empresa, method: 'PATCH', body: { intervalo_minimo_s: s } });
await intervalo(0);

r = await leitura(500);
assert.notEqual(r.status, 200);
passo('distância fora da faixa do sensor (500 cm) é recusada');

r = await leitura(40);
assert.equal(r.status, 200);
assert.equal(r.dados.nivel_pct, 0);
passo('galão vazio: 40 cm → 0%');

r = await leitura(15);
assert.equal(r.dados.nivel_pct, 71.4);
assert.equal(r.dados.aguardando_confirmacao, true);
r = await chamar('/rest/v1/alertas?select=tipo', { token: cliente });
assert.equal(r.dados.length, 0);
passo('uma leitura isolada acima de 70% ainda não gera alerta (aguarda confirmação)');

r = await leitura(15);
r = await chamar('/rest/v1/alertas?select=tipo,nivel_pct', { token: cliente });
assert.deepEqual(r.dados.map(a => a.tipo), ['atencao']);
passo('segunda leitura seguida acima de 70% gera alerta de atenção visível ao cliente');

r = await leitura(14);
r = await chamar('/rest/v1/alertas?select=tipo', { token: cliente });
assert.equal(r.dados.length, 1);
passo('novas leituras acima de 70% não duplicam o alerta');

r = await leitura(7);
assert.equal(r.dados.nivel_pct, 94.3);
r = await chamar('/rest/v1/solicitacoes?select=id', { token: empresa });
assert.equal(r.dados.length, 0);
passo('uma leitura isolada acima de 90% não dispara troca (protege contra leitura falsa)');

r = await leitura(7);
r = await chamar('/rest/v1/alertas?select=tipo&order=criado_em', { token: cliente });
assert.deepEqual(r.dados.map(a => a.tipo).sort(), ['atencao', 'coleta']);
r = await chamar('/rest/v1/solicitacoes?select=id,tipo,origem,status', { token: empresa });
assert.equal(r.dados.length, 1);
assert.equal(r.dados[0].origem, 'automatica');
const coleta = r.dados[0];
passo('94,3% gera alerta de coleta e solicitação automática para a empresa');

// --- Segurança --------------------------------------------------------------
r = await chamar('/rest/v1/dispositivos?select=codigo', { token: cliente });
assert.deepEqual(r.dados, [{ codigo: 'ESP32-01' }]);
r = await chamar('/rest/v1/dispositivos?select=chave_hash', { token: cliente });
assert.notEqual(r.status, 200);
r = await chamar('/rest/v1/dispositivos?select=chave_hash', { token: empresa });
assert.notEqual(r.status, 200);
passo('cliente vê só o sensor do seu galão; ninguém lê o hash da chave pela API');

const meuPerfil = (await chamar('/rest/v1/perfis?select=id', { token: cliente })).dados[0];
r = await chamar(`/rest/v1/perfis?id=eq.${meuPerfil.id}`, { token: cliente, method: 'PATCH', body: { papel: 'empresa' } });
assert.notEqual(r.status, 204);
passo('cliente não consegue se promover a empresa');

r = await chamar('/rest/v1/rpc/concluir_coleta', { token: cliente, method: 'POST', body: { solicitacao: coleta.id, galao_novo: coleta.id } });
assert.notEqual(r.status, 200);
passo('cliente não executa ações da empresa');

r = await chamar('/rest/v1/galoes?select=id', { token: null });
assert.deepEqual(r.dados, []);
passo('visitante sem login não lê dados');

// --- Empresa atende a coleta ----------------------------------------------
r = await chamar('/rest/v1/rpc/agendar_solicitacao', { token: empresa, method: 'POST', body: { solicitacao: coleta.id, data: new Date(Date.now() + 3600e3).toISOString() } });
assert.equal(r.status, 200);
assert.equal(r.dados.status, 'agendada');
passo('empresa agenda a coleta');

const estoque = (await chamar('/rest/v1/galoes?select=id,codigo&status=eq.estoque&order=codigo', { token: empresa })).dados;
r = await chamar('/rest/v1/rpc/concluir_coleta', { token: empresa, method: 'POST', body: { solicitacao: coleta.id, galao_novo: estoque[0].id } });
assert.equal(r.status, 200, JSON.stringify(r.dados));
assert.equal(r.dados.litros_coletados, 47.2);
passo(`troca concluída: ${estoque[0].codigo} instalado, 47,2 L coletados`);

r = await chamar('/rest/v1/rpc/desfazer_coleta', { token: empresa, method: 'POST', body: { solicitacao: coleta.id } });
assert.equal(r.status, 200, JSON.stringify(r.dados));
assert.equal(r.dados.status, 'agendada');
r = await chamar('/rest/v1/reciclagens?select=id', { token: empresa });
assert.equal(r.dados.length, 0);
r = await chamar('/rest/v1/alertas?select=id&resolvido_em=is.null', { token: cliente });
assert.equal(r.dados.length, 2);
passo('desfazer troca volta pedido, alertas e reciclagem');

r = await chamar('/rest/v1/rpc/concluir_coleta', { token: empresa, method: 'POST', body: { solicitacao: coleta.id, galao_novo: estoque[0].id, litros: 45.5 } });
assert.equal(r.status, 200, JSON.stringify(r.dados));
assert.equal(r.dados.litros_coletados, 45.5);
passo('troca refeita com litros informados pela equipe (45,5 L)');

r = await chamar('/rest/v1/reciclagens?select=litros,valor_total', { token: empresa });
assert.equal(r.dados[0].valor_total, 91);
passo('reciclagem registrada: R$ 91,00');

r = await chamar('/rest/v1/alertas?select=id&resolvido_em=is.null', { token: cliente });
assert.equal(r.dados.length, 0);
passo('alertas do galão cheio resolvidos');

r = await leitura(38);
assert.equal(r.dados.galao, estoque[0].codigo);
passo(`sensor transferido: próxima leitura vai para ${estoque[0].codigo}`);

r = await chamar('/rest/v1/leituras?select=nivel_pct&order=criado_em', { token: cliente });
assert.ok(r.dados.length >= 5, `cliente vê ${r.dados.length} leituras`);
passo('histórico do local inclui leituras do galão anterior');

// --- Cliente ----------------------------------------------------------------
const local = (await chamar('/rest/v1/locais?select=id', { token: cliente })).dados[0];
r = await chamar('/rest/v1/rpc/solicitar', { token: cliente, method: 'POST', body: { local: local.id, tipo: 'entrega', observacoes: 'Segundo galão para o salão de festas' } });
assert.equal(r.status, 200);
r = await chamar('/rest/v1/rpc/solicitar', { token: cliente, method: 'POST', body: { local: local.id, tipo: 'entrega' } });
assert.notEqual(r.status, 200);
passo('cliente solicita galão; pedido duplicado em aberto é bloqueado');

const entrega = (await chamar('/rest/v1/solicitacoes?select=id&tipo=eq.entrega&status=eq.pendente', { token: empresa })).dados[0];
r = await chamar('/rest/v1/rpc/cancelar_solicitacao', { token: empresa, method: 'POST', body: { solicitacao: entrega.id } });
assert.equal(r.status, 200);
r = await chamar(`/rest/v1/solicitacoes?select=status,cancelado_por&id=eq.${entrega.id}`, { token: cliente });
assert.deepEqual(r.dados[0], { status: 'cancelada', cancelado_por: 'empresa' });
passo('cancelamento pela equipe fica visível ao cliente');

r = await chamar(`/rest/v1/solicitacoes?select=agendado_por,concluido_por&id=eq.${coleta.id}`, { token: empresa });
const idEmpresa = (await chamar('/rest/v1/perfis?select=id&papel=eq.empresa', { token: empresa })).dados[0].id;
assert.deepEqual(r.dados[0], { agendado_por: idEmpresa, concluido_por: idEmpresa });
passo('pedido registra quem agendou e quem concluiu');

await intervalo(4);
await leitura(30);
r = await leitura(29);
assert.equal(r.dados.ignorada, true);
passo('leitura com menos de 4 s da anterior é ignorada');
await intervalo(intervaloOriginal);

console.log(`\n${ok} verificações passaram.`);
