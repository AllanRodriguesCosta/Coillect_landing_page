#!/usr/bin/env bash
# Publica o build do PWA (app/dist) no site estático do Azure Blob Storage ($web),
# espelho do endereço da Vercel. Requer `az login` na assinatura do cOillect.
#   VITE_SUPABASE_URL=... VITE_SUPABASE_PUBLISHABLE_KEY=... tools/publicar-azure.sh
set -euo pipefail
CONTA=${CONTA:-coillectst}
cd "$(dirname "$0")/../app"

npm run build
az storage blob upload-batch --account-name "$CONTA" -d '$web' -s dist --overwrite --only-show-errors -o none
# index.html e service worker sem cache, para a versão nova chegar logo.
for f in index.html sw.js manifest.webmanifest; do
  [ -f "dist/$f" ] && az storage blob upload-batch --account-name "$CONTA" -d '$web' -s dist --pattern "$f" \
    --content-cache-control "no-cache" --overwrite --only-show-errors -o none
done
echo "Publicado em $(az storage account show -n "$CONTA" --query primaryEndpoints.web -o tsv)"
