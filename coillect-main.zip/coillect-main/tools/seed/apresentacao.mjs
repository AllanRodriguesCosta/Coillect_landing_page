// Cria (ou recria) o cenário de apresentação do cOillect, igual ao do protótipo validado.
//
//   node tools/seed/apresentacao.mjs
//
// Apaga os dados operacionais e recria 4 clientes, galões, sensores, pedidos, alertas,
// histórico de leituras e trocas antigas. As contas são mantidas e as senhas redefinidas
// (DEMO_SENHA define uma senha única para todas; sem ela, cada conta recebe uma senha nova).
// A chave do ESP32-01 (o sensor físico) é exibida na saída. Requer `npx supabase login`.

import { execSync } from 'node:child_process';
import { createHash, randomBytes } from 'node:crypto';
import { readFileSync } from 'node:fs';

const ref = readFileSync(new URL('../../supabase/.temp/project-ref', import.meta.url), 'utf8').trim();
const url = `https://${ref}.supabase.co`;
const chaves = JSON.parse(execSync(`npx -y supabase@2.122.0 projects api-keys --project-ref ${ref} -o json`, { stdio: ['ignore', 'pipe', 'ignore'] }));
// O CLI mascara a chave "secret" nova; a service_role (JWT) vem completa.
const secret = chaves.find(k => k.name === 'service_role').api_key;
const headers = { apikey: secret, Authorization: `Bearer ${secret}`, 'Content-Type': 'application/json' };

async function req(path, options = {}) {
  const res = await fetch(`${url}${path}`, { ...options, headers: { ...headers, ...options.headers } });
  const body = await res.text();
  if (!res.ok) throw new Error(`${options.method || 'GET'} ${path} → ${res.status}: ${body}`);
  return body ? JSON.parse(body) : null;
}
const rest = (tabela, options) => req(`/rest/v1/${tabela}`, { ...options, headers: { Prefer: 'return=representation', ...options?.headers } });
// Em lote quando todas as linhas têm os mesmos campos; senão, uma a uma (as colunas ausentes ficam no padrão do banco).
async function inserir(tabela, linhas) {
  const forma = l => Object.keys(l).sort().join();
  if (linhas.every(l => forma(l) === forma(linhas[0]))) return rest(tabela, { method: 'POST', body: JSON.stringify(linhas) });
  const saida = [];
  for (const l of linhas) saida.push(...await rest(tabela, { method: 'POST', body: JSON.stringify([l]) }));
  return saida;
}
const atualizar = (tabela, filtro, dados) => rest(`${tabela}?${filtro}`, { method: 'PATCH', body: JSON.stringify(dados) });

const senha = () => process.env.DEMO_SENHA || randomBytes(9).toString('base64url');
const hash = c => createHash('sha256').update(c).digest('hex');
const t = Date.now(), MIN = 60e3, H = 3600e3, D = 86400e3;
const iso = ms => new Date(ms).toISOString();
// Galão da demonstração: bombona de 5 L com o ESP32-01 na tampa. Meça e informe:
//   DEMO_VAZIO_CM = distância do sensor até o fundo com a bombona vazia
//   DEMO_CHEIO_CM = distância do sensor até o óleo na altura considerada cheia (abaixo do ombro)
const DEMO = { cap: 5, vazio: Number(process.env.DEMO_VAZIO_CM || 28), cheio: Number(process.env.DEMO_CHEIO_CM || 9) };
const distDemo = nivel => Math.round((DEMO.vazio - nivel / 100 * (DEMO.vazio - DEMO.cheio)) * 10) / 10;
const amanha9 = () => { const d = new Date(t + D); d.setHours(9, 0, 0, 0); return d.getTime(); };

async function conta(email, nome, telefone) {
  const s = senha();
  const { users } = await req('/auth/v1/admin/users?per_page=200');
  let u = users.find(x => x.email === email);
  if (u) await req(`/auth/v1/admin/users/${u.id}`, { method: 'PUT', body: JSON.stringify({ password: s }) });
  else u = await req('/auth/v1/admin/users', { method: 'POST', body: JSON.stringify({ email, password: s, email_confirm: true, user_metadata: { nome, telefone } }) });
  await atualizar('perfis', `id=eq.${u.id}`, { nome, telefone });
  return { id: u.id, email, senha: s };
}

// --- limpa dados operacionais ------------------------------------------------
for (const tabela of ['mensagens', 'reciclagens', 'solicitacoes', 'alertas', 'leituras', 'dispositivos', 'galoes', 'locais']) {
  await rest(`${tabela}?id=not.is.null`, { method: 'DELETE' });
}
await atualizar('configuracoes', 'id=eq.true', { limite_atencao: 70, limite_coleta: 90, valor_litro: 2 });

// --- contas -------------------------------------------------------------------
const empresa = await conta('empresa@coillect.test', 'cOillect Coletas', '(11) 4000-0000');
await atualizar('perfis', `id=eq.${empresa.id}`, { papel: 'empresa' });
const clientes = {
  aurora: await conta('sindico@coillect.test', 'Leonardo Ked', '(11) 98765-4321'),
  granja: await conta('sabordagranja@coillect.test', 'Marta Ribeiro', '(11) 97412-0088'),
  ponto7: await conta('ponto7@coillect.test', 'Carlos Mendes', '(11) 96633-1270'),
  vila: await conta('vilaverde@coillect.test', 'Ana Paula Souza', '(11) 95520-4413'),
};

// --- locais -----------------------------------------------------------------------
const [aurora, granja, ponto7, vila] = await inserir('locais', [
  { cliente_id: clientes.aurora.id, tipo: 'condominio', nome: 'Residencial Aurora', cep: '06700-000', logradouro: 'Rua das Palmeiras', numero: '120', bairro: 'Centro', cidade: 'Cotia', uf: 'SP', latitude: -23.611472, longitude: -46.930047, criado_em: iso(t - 40 * D) },
  { cliente_id: clientes.granja.id, tipo: 'restaurante', nome: 'Restaurante Sabor da Granja', cep: '06705-000', logradouro: 'Estrada da Roselândia', numero: '890', bairro: 'Roselândia', cidade: 'Cotia', uf: 'SP', latitude: -23.595419, longitude: -46.921320, criado_em: iso(t - 30 * D) },
  { cliente_id: clientes.ponto7.id, tipo: 'lanchonete', nome: 'Lanchonete Ponto 7', cep: '06717-250', logradouro: 'Rua Etelvina', numero: '455', bairro: 'Vila Mont Serrat', cidade: 'Cotia', uf: 'SP', latitude: -23.604275, longitude: -46.919500, criado_em: iso(t - 20 * D) },
  { cliente_id: clientes.vila.id, tipo: 'condominio', nome: 'Condomínio Vila Verde', cep: '06709-015', logradouro: 'Rua Jorge Caixe', numero: '77', bairro: 'Granja Viana', cidade: 'Cotia', uf: 'SP', latitude: -23.603055, longitude: -46.908999, criado_em: iso(t - 10 * D) },
]);

// --- galões -------------------------------------------------------------------------
const g = {};
for (const linha of await inserir('galoes', [
  { codigo: 'G-001', status: 'instalado', local_id: aurora.id, nivel_pct: 0, instalado_em: iso(t - 9 * D), capacidade_litros: DEMO.cap, distancia_vazio_cm: DEMO.vazio, distancia_cheio_cm: DEMO.cheio },
  { codigo: 'G-002', status: 'estoque', capacidade_litros: DEMO.cap, distancia_vazio_cm: DEMO.vazio, distancia_cheio_cm: DEMO.cheio },
  { codigo: 'G-003', status: 'instalado', local_id: ponto7.id, nivel_pct: 74.3, instalado_em: iso(t - 15 * D), ultima_leitura_em: iso(t - 3 * H) },
  { codigo: 'G-004', status: 'estoque' },
  { codigo: 'G-005', status: 'instalado', local_id: granja.id, nivel_pct: 91.4, instalado_em: iso(t - 21 * D), ultima_leitura_em: iso(t - 40e3) },
  { codigo: 'G-006', status: 'instalado', local_id: vila.id, nivel_pct: 18.6, instalado_em: iso(t - 4 * D), ultima_leitura_em: iso(t - 30e3) },
  { codigo: 'G-007', status: 'estoque' },
  { codigo: 'G-008', status: 'reciclagem' },
].map(x => ({ capacidade_litros: 50, distancia_vazio_cm: 40, distancia_cheio_cm: 5, local_id: null, nivel_pct: 0, instalado_em: null, ultima_leitura_em: null, ...x })))) g[linha.codigo] = linha;

// --- sensores (só a chave do ESP32-01, o sensor físico, é exibida) --------------------
const chave01 = randomBytes(24).toString('hex');
const d = {};
for (const linha of await inserir('dispositivos', [
  { codigo: 'ESP32-01', galao_id: g['G-001'].id, chave_hash: hash(chave01), ultimo_contato_em: iso(t - 8e3) },
  { codigo: 'ESP32-02', galao_id: g['G-005'].id, chave_hash: hash(randomBytes(24).toString('hex')), ultimo_contato_em: iso(t - 40e3) },
  { codigo: 'ESP32-03', galao_id: g['G-003'].id, chave_hash: hash(randomBytes(24).toString('hex')), ultimo_contato_em: iso(t - 3 * H) },
  { codigo: 'ESP32-04', galao_id: g['G-006'].id, chave_hash: hash(randomBytes(24).toString('hex')), ultimo_contato_em: iso(t - 30e3) },
  { codigo: 'ESP32-05' },
])) d[linha.codigo] = linha;

// --- leituras: G-001 enche ao longo de 9 dias, a cada 3 h ----------------------------
const leituras = [];
for (let k = 72; k >= 1; k--) {
  const nivel = Math.max(0, Math.round(((72 - k) / 72 * 58 + Math.sin(k) * 1.2) * 10) / 10);
  leituras.push({ dispositivo_id: d['ESP32-01'].id, galao_id: g['G-001'].id, local_id: aurora.id, distancia_cm: distDemo(nivel), nivel_pct: nivel, litros: Math.round(nivel * DEMO.cap / 10) / 10, criado_em: iso(t - k * 3 * H) });
}
for (const [disp, gal, loc, nivel, quando] of [['ESP32-02', 'G-005', granja, 91.4, t - 40e3], ['ESP32-03', 'G-003', ponto7, 74.3, t - 3 * H], ['ESP32-04', 'G-006', vila, 18.6, t - 30e3]]) {
  leituras.push({ dispositivo_id: d[disp].id, galao_id: g[gal].id, local_id: loc.id, distancia_cm: Math.round((40 - nivel / 100 * 35) * 10) / 10, nivel_pct: nivel, litros: nivel / 2, criado_em: iso(quando) });
}
await inserir('leituras', leituras);
const ultima = leituras[71];
await atualizar('galoes', `id=eq.${g['G-001'].id}`, { nivel_pct: ultima.nivel_pct, ultima_leitura_em: iso(t - 8e3) });

// --- alertas --------------------------------------------------------------------------
await inserir('alertas', [
  { galao_id: g['G-005'].id, local_id: granja.id, tipo: 'atencao', nivel_pct: 70.6, criado_em: iso(t - 3 * D), lido_em: iso(t - 3 * D + H) },
  { galao_id: g['G-005'].id, local_id: granja.id, tipo: 'coleta', nivel_pct: 90.3, criado_em: iso(t - 5 * H) },
  { galao_id: g['G-003'].id, local_id: ponto7.id, tipo: 'atencao', nivel_pct: 70.2, criado_em: iso(t - 26 * H), lido_em: iso(t - 25 * H) },
]);

// --- pedidos em aberto e trocas antigas (com reciclagem) ------------------------------
await inserir('solicitacoes', [
  { local_id: granja.id, galao_id: g['G-005'].id, tipo: 'coleta', origem: 'automatica', status: 'pendente', criado_em: iso(t - 5 * H) },
  { local_id: ponto7.id, galao_id: g['G-003'].id, tipo: 'coleta', origem: 'cliente', status: 'agendada', agendada_para: iso(amanha9()), observacoes: 'Retirar pelo portão lateral, antes das 11h.', criado_por: clientes.ponto7.id, criado_em: iso(t - 20 * H) },
  { local_id: vila.id, tipo: 'entrega', origem: 'cliente', status: 'pendente', observacoes: 'Segundo galão para o salão de festas.', criado_por: clientes.vila.id, criado_em: iso(t - 2 * H) },
]);
const antigas = [
  [aurora, 'G-002', 'G-001', 4.6, 10],
  [aurora, 'G-001', 'G-002', 4.5, 34],
  [granja, 'G-007', 'G-005', 47.0, 22],
  [ponto7, 'G-008', 'G-003', 44.8, 16],
];
for (const [loc, retirado, entregue, litros, dias] of antigas) {
  const [s] = await inserir('solicitacoes', [{ local_id: loc.id, galao_id: g[retirado].id, tipo: 'coleta', origem: 'automatica', status: 'concluida', criado_em: iso(t - (dias + 1) * D), agendada_para: iso(t - dias * D), concluida_em: iso(t - dias * D), galao_entregue_id: g[entregue].id, litros_coletados: litros }]);
  await inserir('reciclagens', [{ solicitacao_id: s.id, galao_id: g[retirado].id, local_id: loc.id, litros, valor_litro: 2, criado_em: iso(t - dias * D) }]);
}

// --- mensagem de cliente --------------------------------------------------------------
await inserir('mensagens', [{ local_id: ponto7.id, autor_id: clientes.ponto7.id, texto: 'Trocaram o roteador ontem. O sensor pode ter perdido o Wi-Fi.', criado_em: iso(t - 50 * MIN) }]);

console.log(`Projeto:     ${url}`);
console.log(`Empresa:     ${empresa.email}  senha: ${empresa.senha}`);
for (const [nome, c] of Object.entries(clientes)) console.log(`Cliente ${nome.padEnd(7)} ${c.email}  senha: ${c.senha}`);
console.log(`Dispositivo: ESP32-01 (galão G-001, bombona de 5 L, vazio ${DEMO.vazio} cm, cheio ${DEMO.cheio} cm, Residencial Aurora)  chave: ${chave01}`);
