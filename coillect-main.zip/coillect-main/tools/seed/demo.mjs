// Cria (ou recria) os dados de demonstração do cOillect no projeto Supabase ligado.
//
//   node tools/seed/demo.mjs
//
// Requer `npx supabase login` feito. A chave secreta é obtida pelo CLI em tempo de
// execução e não é gravada em disco. As senhas das contas podem ser definidas por
// DEMO_SENHA_EMPRESA e DEMO_SENHA_CLIENTE; se ausentes, são geradas e exibidas uma vez.

import { execSync } from 'node:child_process';
import { createHash, randomBytes } from 'node:crypto';
import { readFileSync } from 'node:fs';

const ref = readFileSync(new URL('../../supabase/.temp/project-ref', import.meta.url), 'utf8').trim();
const url = `https://${ref}.supabase.co`;
const chaves = JSON.parse(execSync(`npx -y supabase@2.122.0 projects api-keys --project-ref ${ref} -o json`, { stdio: ['ignore', 'pipe', 'ignore'] }));
// O CLI mascara a chave "secret" nova; a service_role (JWT) vem completa.
const secret = chaves.find(k => k.name === 'service_role').api_key;

const headers = { apikey: secret, Authorization: `Bearer ${secret}`, 'Content-Type': 'application/json' };

async function req(path, options = {}) {
  const res = await fetch(`${url}${path}`, { ...options, headers: { ...headers, ...options.headers } });
  const body = await res.text();
  if (!res.ok) throw new Error(`${options.method || 'GET'} ${path} → ${res.status}: ${body}`);
  return body ? JSON.parse(body) : null;
}

const rest = (tabela, options) => req(`/rest/v1/${tabela}`, { ...options, headers: { Prefer: 'return=representation', ...options?.headers } });

async function conta(email, senha, nome) {
  const { users } = await req('/auth/v1/admin/users?per_page=200');
  const existente = users.find(u => u.email === email);
  if (existente) {
    await req(`/auth/v1/admin/users/${existente.id}`, { method: 'PUT', body: JSON.stringify({ password: senha }) });
    return existente.id;
  }
  const criado = await req('/auth/v1/admin/users', {
    method: 'POST',
    body: JSON.stringify({ email, password: senha, email_confirm: true, user_metadata: { nome } }),
  });
  return criado.id;
}

const senha = () => randomBytes(9).toString('base64url');
const senhaEmpresa = process.env.DEMO_SENHA_EMPRESA || senha();
const senhaCliente = process.env.DEMO_SENHA_CLIENTE || senha();

const EMPRESA = 'empresa@coillect.test';
const CLIENTE = 'sindico@coillect.test';

// Limpa dados operacionais anteriores (mantém as contas).
for (const tabela of ['reciclagens', 'solicitacoes', 'alertas', 'leituras', 'dispositivos', 'galoes', 'locais']) {
  await rest(`${tabela}?id=not.is.null`, { method: 'DELETE' });
}

const empresaId = await conta(EMPRESA, senhaEmpresa, 'cOillect Coletas');
const clienteId = await conta(CLIENTE, senhaCliente, 'Leonardo Ked');
await rest(`perfis?id=eq.${empresaId}`, { method: 'PATCH', body: JSON.stringify({ papel: 'empresa', nome: 'cOillect Coletas' }) });

const [local] = await rest('locais', {
  method: 'POST',
  body: JSON.stringify({
    cliente_id: clienteId, tipo: 'condominio', nome: 'Residencial Aurora',
    cep: '06700-000', logradouro: 'Rua das Palmeiras', numero: '120', bairro: 'Centro', cidade: 'Cotia', uf: 'SP', latitude: -23.611472, longitude: -46.930047,
  }),
});

const galoes = await rest('galoes', {
  method: 'POST',
  body: JSON.stringify(['G-001', 'G-002', 'G-003', 'G-004'].map(codigo => ({ codigo, capacidade_litros: 50 }))),
});
const g1 = galoes.find(g => g.codigo === 'G-001');
await rest(`galoes?id=eq.${g1.id}`, {
  method: 'PATCH',
  body: JSON.stringify({ status: 'instalado', local_id: local.id, instalado_em: new Date().toISOString() }),
});

const chave = randomBytes(24).toString('hex');
await rest('dispositivos', {
  method: 'POST',
  body: JSON.stringify({ codigo: 'ESP32-01', galao_id: g1.id, chave_hash: createHash('sha256').update(chave).digest('hex') }),
});

console.log(`Projeto:            ${url}`);
console.log(`Empresa:            ${EMPRESA}  senha: ${senhaEmpresa}`);
console.log(`Cliente (síndico):  ${CLIENTE}  senha: ${senhaCliente}`);
console.log(`Local:              ${local.nome} — galão G-001 instalado; G-002 a G-004 em estoque`);
console.log(`Dispositivo:        ESP32-01  chave: ${chave}`);
