// Simulador do sensor: envia leituras para a nuvem pelo mesmo endpoint e com a mesma
// chave do ESP32. Serve para testes e como plano B na apresentação.
//
//   node tools/simulador/simulador.mjs --chave <CHAVE> --distancia 15        uma leitura
//   node tools/simulador/simulador.mjs --chave <CHAVE> --encher               despeja óleo aos poucos
//        [--de 38] [--ate 5] [--passo 0.8] [--intervalo 5]
//
// A chave também pode vir de DISPOSITIVO_CHAVE. A URL e a chave pública vêm do projeto ligado
// (supabase/.temp) e do CLI, ou de SUPABASE_URL / SUPABASE_PUBLISHABLE_KEY.

import { execSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { parseArgs } from 'node:util';

const { values: o } = parseArgs({
  options: {
    chave: { type: 'string' }, distancia: { type: 'string' }, encher: { type: 'boolean' },
    de: { type: 'string', default: '38' }, ate: { type: 'string', default: '5' },
    passo: { type: 'string', default: '0.8' }, intervalo: { type: 'string', default: '5' },
  },
});
const chave = o.chave || process.env.DISPOSITIVO_CHAVE;
if (!chave) { console.error('Informe --chave ou DISPOSITIVO_CHAVE.'); process.exit(1); }

let url = process.env.SUPABASE_URL, publica = process.env.SUPABASE_PUBLISHABLE_KEY;
if (!url || !publica) {
  const ref = readFileSync(new URL('../../supabase/.temp/project-ref', import.meta.url), 'utf8').trim();
  url = `https://${ref}.supabase.co`;
  const chaves = JSON.parse(execSync(`npx -y supabase@2.122.0 projects api-keys --project-ref ${ref} -o json`, { stdio: ['ignore', 'pipe', 'ignore'] }));
  publica = chaves.find(k => k.type === 'publishable').api_key;
}

async function enviar(distancia_cm) {
  const res = await fetch(`${url}/rest/v1/rpc/registrar_leitura`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', apikey: publica },
    body: JSON.stringify({ chave, distancia_cm: Math.round(distancia_cm * 10) / 10 }),
  });
  const corpo = await res.json();
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${corpo.message}`);
  console.log(`${new Date().toLocaleTimeString('pt-BR')}  ${distancia_cm.toFixed(1)} cm → ${corpo.vinculado ? `${corpo.galao} ${corpo.nivel_pct}% (${corpo.litros} L)` : 'sensor sem galão'}`);
  return corpo;
}

if (o.encher) {
  const passo = Number(o.passo), ate = Number(o.ate);
  for (let d = Number(o.de); d >= ate; d -= passo) {
    await enviar(d);
    await new Promise(r => setTimeout(r, Number(o.intervalo) * 1000));
  }
} else {
  await enviar(Number(o.distancia ?? 20));
}
