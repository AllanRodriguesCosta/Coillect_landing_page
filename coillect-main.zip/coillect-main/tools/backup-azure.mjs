// Backup diário do cOillect no Azure (rodado pela GitHub Action backup-azure.yml).
//   1. Exporta cada tabela do Supabase para o Blob: backups/<AAAA-MM-DD>/<tabela>.json
//   2. Arquiva as leituras dos últimos 2 dias na Table "leituras"
//      (PartitionKey = galão, RowKey = id da leitura com zeros à esquerda; DIAS_LEITURAS muda a janela).
//
// Variáveis: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, AZURE_STORAGE_ACCOUNT, AZURE_STORAGE_SAS
const env = (n) => process.env[n] || (() => { throw new Error(`defina ${n}`); })();
const url = env('SUPABASE_URL');
const chave = env('SUPABASE_SERVICE_ROLE_KEY');
const conta = env('AZURE_STORAGE_ACCOUNT');
const sas = env('AZURE_STORAGE_SAS').replace(/^\?/, '');

const TABELAS = ['perfis', 'locais', 'galoes', 'dispositivos', 'leituras', 'leituras_hora', 'alertas', 'solicitacoes', 'reciclagens', 'mensagens', 'configuracoes'];
const supa = { apikey: chave, Authorization: `Bearer ${chave}` };

async function exportar(tabela, filtro = '') {
  const linhas = [];
  for (let de = 0; ; de += 1000) {
    const res = await fetch(`${url}/rest/v1/${tabela}?select=*${filtro}`, { headers: { ...supa, Range: `${de}-${de + 999}` } });
    if (!res.ok) throw new Error(`${tabela}: HTTP ${res.status} ${await res.text()}`);
    const lote = await res.json();
    linhas.push(...lote);
    if (lote.length < 1000) return linhas;
  }
}

async function enviarBlob(caminho, dados) {
  const res = await fetch(`https://${conta}.blob.core.windows.net/backups/${caminho}?${sas}`, {
    method: 'PUT',
    headers: { 'x-ms-blob-type': 'BlockBlob', 'Content-Type': 'application/json' },
    body: JSON.stringify(dados, null, 1),
  });
  if (!res.ok) throw new Error(`blob ${caminho}: HTTP ${res.status} ${await res.text()}`);
}

async function gravarLeitura(l) {
  const chaveEntidade = `PartitionKey='${l.galao_id}',RowKey='${String(l.id).padStart(12, '0')}'`;
  const res = await fetch(`https://${conta}.table.core.windows.net/leituras(${chaveEntidade})?${sas}`, {
    method: 'PUT', // insert-or-replace: rodar de novo não duplica
    headers: { 'Content-Type': 'application/json', Accept: 'application/json;odata=nometadata', 'x-ms-version': '2019-02-02' },
    body: JSON.stringify({
      dispositivo_id: l.dispositivo_id, distancia_cm: Number(l.distancia_cm), nivel_pct: Number(l.nivel_pct),
      litros: Number(l.litros), criado_em: new Date(l.criado_em).toISOString(), 'criado_em@odata.type': 'Edm.DateTime',
    }),
  });
  if (!res.ok) throw new Error(`table ${l.id}: HTTP ${res.status} ${await res.text()}`);
}

const dia = new Date().toISOString().slice(0, 10);
for (const tabela of TABELAS) {
  const linhas = await exportar(tabela);
  await enviarBlob(`${dia}/${tabela}.json`, linhas);
  console.log(`${tabela.padEnd(14)} ${linhas.length} linha(s) -> blob backups/${dia}/${tabela}.json`);
}

const dias = Number(process.env.DIAS_LEITURAS || 2); // carga inicial: DIAS_LEITURAS=3650
const desde = new Date(Date.now() - dias * 864e5).toISOString();
const recentes = await exportar('leituras', `&criado_em=gte.${desde}&order=id`);
for (let i = 0; i < recentes.length; i += 20) {
  await Promise.all(recentes.slice(i, i + 20).map(gravarLeitura));
}
console.log(`leituras       ${recentes.length} arquivada(s) na Table "leituras"`);
