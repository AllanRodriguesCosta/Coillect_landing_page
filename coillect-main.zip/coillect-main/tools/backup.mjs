// Backup dos dados do cOillect em backups/<data>/, um JSON por tabela (fora do Git).
// A estrutura do banco é reproduzível pelas migrations (supabase/migrations); este backup
// guarda os dados, já que o plano gratuito do Supabase não oferece backup restaurável.
//
//   node tools/backup.mjs
//
// Requer `npx supabase login`. A chave administrativa é obtida pelo CLI e não é gravada.
import { execSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';

const TABELAS = ['perfis', 'locais', 'galoes', 'dispositivos', 'leituras', 'leituras_hora', 'alertas', 'solicitacoes', 'reciclagens', 'mensagens', 'configuracoes'];
const ref = readFileSync(new URL('../supabase/.temp/project-ref', import.meta.url), 'utf8').trim();
const url = `https://${ref}.supabase.co`;
const chaves = JSON.parse(execSync(`npx -y supabase@2.122.0 projects api-keys --project-ref ${ref} -o json`, { stdio: ['ignore', 'pipe', 'ignore'] }));
const secret = chaves.find(k => k.name === 'service_role').api_key;
const headers = { apikey: secret, Authorization: `Bearer ${secret}` };

const agora = new Date();
const pasta = new URL(`../backups/${agora.toISOString().slice(0, 16).replace(/[:T]/g, '-')}/`, import.meta.url);
mkdirSync(pasta, { recursive: true });

for (const tabela of TABELAS) {
  const linhas = [];
  for (let de = 0; ; de += 1000) {
    const res = await fetch(`${url}/rest/v1/${tabela}?select=*`, { headers: { ...headers, Range: `${de}-${de + 999}` } });
    if (!res.ok) throw new Error(`${tabela}: HTTP ${res.status} ${await res.text()}`);
    const lote = await res.json();
    linhas.push(...lote);
    if (lote.length < 1000) break;
  }
  writeFileSync(new URL(`${tabela}.json`, pasta), JSON.stringify(linhas, null, 1));
  console.log(`${tabela.padEnd(14)} ${linhas.length} linha(s)`);
}
const { users } = await (await fetch(`${url}/auth/v1/admin/users?per_page=1000`, { headers })).json();
writeFileSync(new URL('usuarios.json', pasta), JSON.stringify(users.map(u => ({ id: u.id, email: u.email, criado_em: u.created_at })), null, 1));
console.log(`usuarios       ${users.length} conta(s) (sem senhas)`);
console.log(`Backup em ${pasta.pathname}`);
