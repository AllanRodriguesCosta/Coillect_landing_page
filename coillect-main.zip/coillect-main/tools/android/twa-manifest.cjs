// Gera o twa-manifest.json do APK a partir do manifesto do PWA publicado.
//   node twa-manifest.cjs <pasta-android> <versão, ex. 1.0.1> <código da versão, inteiro crescente>
// Usado por tools/publicar-apk.sh; requer o Bubblewrap em ~/.local/share/bubblewrap.
const path = require('node:path');
const os = require('node:os');
const { TwaManifest } = require(path.join(os.homedir(), '.local/share/bubblewrap/node_modules/@bubblewrap/core'));

const [pasta, versao, codigo] = process.argv.slice(2);
if (!pasta || !/^\d+\.\d+\.\d+$/.test(versao || '') || !(Number(codigo) > 0)) {
  console.error('uso: node twa-manifest.cjs <pasta-android> <x.y.z> <código>');
  process.exit(1);
}

(async () => {
  const m = await TwaManifest.fromWebManifest('https://coillect.vercel.app/manifest.webmanifest');
  m.packageId = 'app.vercel.coillect';
  m.name = 'cOillect';
  m.launcherName = 'cOillect';
  m.appVersionName = versao;
  m.appVersionCode = Number(codigo);
  m.fallbackType = 'customtabs';
  m.minSdkVersion = 24; // Android 7.0: mínimo exigido pela androidbrowserhelper 2.7
  m.enableNotifications = false;
  m.signingKey = { path: path.join(path.resolve(pasta), 'assinatura', 'coillect.keystore'), alias: 'coillect' };
  await m.saveToFile(path.join(pasta, 'twa-manifest.json'));
})();
