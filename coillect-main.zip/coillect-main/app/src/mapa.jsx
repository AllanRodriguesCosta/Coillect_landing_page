import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const PRIORIDADE = { coleta: 3000, atencao: 2000, ok: 1000 };

// Mapa do OpenStreetMap com um marcador por local. Cada ponto:
// { id, lat, lng, rotulo (texto no marcador), titulo (nome acessível), fase ('ok' | 'atencao' | 'coleta' | 'neutro'), onClick? }
// O enquadramento só muda quando entram ou saem locais: uma leitura nova só atualiza o marcador.
export function Mapa({ pontos, altura = 320, rotulo = 'Mapa dos locais' }) {
  const caixa = useRef(null);
  const mapa = useRef(null);
  const camada = useRef(null);
  const enquadrados = useRef('');

  useEffect(() => {
    const m = L.map(caixa.current, { scrollWheelZoom: false, attributionControl: true });
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(m);
    m.setView([-23.6035, -46.9195], 13); // Cotia, até os pontos chegarem
    mapa.current = m;
    camada.current = L.layerGroup().addTo(m);
    return () => { m.remove(); mapa.current = null; enquadrados.current = ''; };
  }, []);

  useEffect(() => {
    const m = mapa.current;
    if (!m) return;
    camada.current.clearLayers();
    for (const p of pontos) {
      const icone = L.divIcon({ className: 'pino-mapa', html: `<span class="pino ${p.fase}">${p.rotulo}</span>`, iconSize: null });
      const marcador = L.marker([p.lat, p.lng], {
        icon: icone, title: p.titulo, alt: p.titulo, keyboard: !!p.onClick, interactive: !!p.onClick,
        zIndexOffset: PRIORIDADE[p.fase] || 0, // se dois marcadores se sobrepõem, o mais urgente fica por cima
      });
      if (p.onClick) marcador.on('click', p.onClick);
      marcador.addTo(camada.current);
    }
    const ids = pontos.map(p => p.id).sort().join();
    if (ids && ids !== enquadrados.current) {
      enquadrados.current = ids;
      if (pontos.length === 1) m.setView([pontos[0].lat, pontos[0].lng], 16);
      else m.fitBounds(L.latLngBounds(pontos.map(p => [p.lat, p.lng])), { padding: [40, 40], maxZoom: 16 });
    }
  }, [pontos]);

  return <div className="mapa" ref={caixa} style={{ height: altura }} role="region" aria-label={rotulo} />;
}
