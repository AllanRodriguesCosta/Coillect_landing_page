import { createContext, useCallback, useContext, useEffect, useId, useRef, useState, useSyncExternalStore } from 'react';
import { createPortal } from 'react-dom';
import { rel, diaHora, data, f1 } from './lib/formato.js';
import { faseDe, FASE_TXT, STATUS, aberto } from './lib/regras.js';

// ------------------------------------------------------------------ ícones
const I = {
  inicio: <path d="M4 11.5 12 5l8 6.5V20a1 1 0 0 1-1 1h-4.5v-6h-5v6H5a1 1 0 0 1-1-1z" />,
  pedidos: <><path d="M7 4h10a1 1 0 0 1 1 1v15l-3-2-3 2-3-2-3 2V5a1 1 0 0 1 1-1z" /><path d="M9 9h6M9 13h4" /></>,
  historico: <><path d="M4 19V5M4 19h16" /><path d="m7 15 4-4 3 3 5-6" /></>,
  conta: <><circle cx="12" cy="8.5" r="3.5" /><path d="M5 20c1-3.5 3.8-5 7-5s6 1.5 7 5" /></>,
  painel: <><rect x="4" y="4" width="7" height="7" rx="1.5" /><rect x="13" y="4" width="7" height="4" rx="1.5" /><rect x="13" y="10" width="7" height="10" rx="1.5" /><rect x="4" y="13" width="7" height="7" rx="1.5" /></>,
  galoes: <><rect x="5" y="7" width="14" height="14" rx="3" /><path d="M10 7V4h4v3M5 14h14" /></>,
  sensores: <><path d="M5 9.5a10 10 0 0 1 14 0M8 12.5a5.5 5.5 0 0 1 8 0" /><circle cx="12" cy="16" r="1.6" /><path d="M9 20h6" /></>,
  ajustes: <><circle cx="12" cy="12" r="3" /><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1" /></>,
  seta: <path d="m7 10 5 5 5-5" />,
  mapa: <><path d="M12 21s-6-5.6-6-10a6 6 0 0 1 12 0c0 4.4-6 10-6 10z" /><circle cx="12" cy="11" r="2.2" /></>,
  telefone: <path d="M6.5 3.5h3l1.5 4-2 1.3a11 11 0 0 0 5.2 5.2l1.3-2 4 1.5v3a2 2 0 0 1-2.2 2A16 16 0 0 1 4.5 5.7a2 2 0 0 1 2-2.2z" />,
  sino: <><path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z" /><path d="M10 20a2 2 0 0 0 4 0" /></>,
};
export const Icone = ({ nome, tamanho = 22 }) => (
  <svg viewBox="0 0 24 24" width={tamanho} height={tamanho} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{I[nome]}</svg>
);
export const Gota = () => (
  <svg viewBox="0 0 24 24" width="20" height="20" fill="var(--oleo)" aria-hidden="true"><path d="M12 3c3.5 4.4 6 7.9 6 11a6 6 0 0 1-12 0c0-3.1 2.5-6.6 6-11z" /></svg>
);
export const Logo = () => <span className="logo" aria-label="cOillect">c<em>Oil</em>lect</span>;
// Marca original (gota + folha + nome), em preto no tema claro e em branco no tema escuro.
export const Marca = ({ altura = 120 }) => (
  <picture>
    <source srcSet="/logo-escuro.png" media="(prefers-color-scheme: dark)" />
    <img src="/logo-claro.png" alt="cOillect" height={altura} width={Math.round(altura * 248 / 240)} style={{ display: 'block' }} />
  </picture>
);

// ------------------------------------------------------------------ tempo relativo
// Um relógio compartilhado: os "há 12 s" se atualizam sem redesenhar a tela inteira.
let agora = Date.now();
const ouvintes = new Set();
setInterval(() => { agora = Date.now(); ouvintes.forEach(f => f()); }, 10e3);
const assinar = f => { ouvintes.add(f); return () => ouvintes.delete(f); };
export const useAgora = () => useSyncExternalStore(assinar, () => agora);
export function Rel({ t }) {
  useAgora();
  return t ? <span>{rel(t)}</span> : <span>—</span>;
}

// ------------------------------------------------------------------ selos e barras
export function ChipFase({ nivel, cfg }) {
  const f = faseDe(nivel, cfg);
  return <span className={`chip ${f}`}>{FASE_TXT[f]}</span>;
}
export function ChipStatus({ pedido, perfil }) {
  const [t, c] = STATUS[perfil][pedido.status];
  return <span className={`chip ${c}`}>{t}</span>;
}
// Para o cliente, o selo do galão acompanha o pedido: depois de pedida, a troca não é tarefa dele.
export function ChipGalaoCliente({ galao, cfg, pedidos }) {
  const t = pedidos.find(p => p.galao_id === galao.id && p.tipo === 'coleta' && aberto(p));
  if (!t) return <ChipFase nivel={galao.nivel_pct} cfg={cfg} />;
  return <span className={`chip ${t.status === 'agendada' ? 'agendado' : 'coleta'}`}>{t.status === 'agendada' ? 'Troca agendada' : 'Troca pedida'}</span>;
}
export const Barra = ({ nivel, cfg, velha }) => (
  <span className={`barra${velha ? ' velha' : ''}`} style={{ '--m70': `${cfg.limite_atencao}%`, '--m90': `${cfg.limite_coleta}%` }} aria-hidden="true">
    <i className={faseDe(nivel, cfg)} style={{ width: `${nivel}%` }} />
  </span>
);

// ------------------------------------------------------------------ galão (assinatura)
const TOPO = 59, FUNDO = 225, ALT = FUNDO - TOPO;
const yDe = n => FUNDO - ALT * n / 100;
let ONDA = 'M-67 0';
for (let i = 0; i < 12; i++) ONDA += i === 0 ? ' q16.75 -3.6 33.5 0' : ' t33.5 0';
ONDA += ' V200 H-67 Z';

export function Galao({ galao, cfg, tamanho = 150, comSensor = false }) {
  const id = useId().replace(/:/g, '');
  const nivel = galao.nivel_pct;
  const fase = faseDe(nivel, cfg);
  const marca = n => {
    const y = yDe(n), ativo = nivel >= n;
    const cor = n >= cfg.limite_coleta ? 'var(--ferrugem)' : 'var(--oleo-fundo)';
    return (
      <g key={n}>
        <line x1="150" x2="167" y1={y} y2={y} stroke={ativo ? cor : 'var(--galao-borda)'} strokeWidth="2.5" strokeLinecap="round" />
        <text x="176" y={y + 4} fontSize="12" fontFamily="var(--mono)" fontWeight="600" fill={ativo ? cor : 'var(--texto-2)'}>{n}</text>
      </g>
    );
  };
  return (
    <svg viewBox="0 0 212 236" width={tamanho} role="img" aria-label={`Galão ${galao.codigo} com ${f1(nivel)}% de óleo`}>
      <defs>
        <clipPath id={`c${id}`}><rect x="33" y="59" width="134" height="166" rx="19" /></clipPath>
        <linearGradient id={`o${id}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="var(--oleo)" /><stop offset="1" stopColor="var(--oleo-fundo)" />
        </linearGradient>
      </defs>
      <path d="M128 56 V42 Q128 32 138 32 H154 Q166 32 166 44 V66" fill="none" stroke="var(--galao-borda)" strokeWidth="9" strokeLinecap="round" />
      <rect x="30" y="56" width="140" height="172" rx="22" fill="var(--galao)" stroke="var(--galao-borda)" strokeWidth="3" />
      <rect x="80" y="42" width="40" height="16" rx="4" fill="var(--galao-borda)" />
      <g clipPath={`url(#c${id})`}>
        {comSensor && <line className="feixe" x1="100" x2="100" y1="60" y2="226" stroke="var(--folha-viva)" strokeWidth="2" />}
        <g className="liquido" style={{ transform: `translateY(${yDe(nivel)}px)` }}>
          <path className="onda" d={ONDA} fill={`url(#o${id})`} />
        </g>
      </g>
      {marca(cfg.limite_atencao)}{marca(cfg.limite_coleta)}
      {comSensor && (
        <g className="sensor">
          <rect x="74" y="20" width="52" height="24" rx="6" fill="var(--grafite)" />
          <circle cx="89" cy="32" r="7" fill="var(--galao-borda)" /><circle cx="111" cy="32" r="7" fill="var(--galao-borda)" />
          <circle cx="89" cy="32" r="3" fill="var(--grafite)" /><circle cx="111" cy="32" r="3" fill="var(--grafite)" />
          <circle cx="120" cy="24" r="2" fill={fase === 'coleta' ? 'var(--ferrugem)' : 'var(--folha-viva)'} />
        </g>
      )}
    </svg>
  );
}

// ------------------------------------------------------------------ andamento do pedido
export function Rastreio({ pedido, galao, cfg, onAjuda }) {
  const entrega = pedido.tipo === 'entrega';
  const agendado = pedido.status === 'agendada';
  const etapas = [
    { nome: entrega ? 'Galão pedido' : 'Troca pedida', det: pedido.origem === 'automatica' ? `Automático, ao chegar a ${cfg.limite_coleta}%` : `Por você, ${data(pedido.criado_em)}` },
    { nome: agendado ? (entrega ? 'Entrega agendada' : 'Troca agendada') : 'Aguardando agendamento', det: agendado ? diaHora(pedido.agendada_para) : 'A equipe cOillect vai marcar o dia' },
    { nome: entrega ? 'Galão instalado' : 'Galão trocado', det: entrega ? 'O nível do galão aparece aqui' : 'Levamos o cheio e deixamos um vazio' },
  ];
  const atual = agendado ? 2 : 1;
  const titulo = agendado
    ? `${entrega ? 'Entrega' : 'Troca'} agendada para ${diaHora(pedido.agendada_para)}`
    : (entrega ? 'Seu galão está a caminho' : 'A troca do seu galão está a caminho');
  const quase = galao && galao.status === 'instalado' && galao.nivel_pct >= cfg.limite_coleta;
  const sobra = galao ? Math.max(0, Math.round(galao.capacidade_litros * (100 - galao.nivel_pct)) / 100) : 0;
  return (
    <section className="rastreio" aria-label="Andamento do pedido">
      <strong>{titulo}</strong>
      <ol>
        {etapas.map((e, i) => (
          <li key={e.nome} className={i < atual ? 'feita' : i === atual ? 'atual' : ''} aria-current={i === atual ? 'step' : undefined}>
            <span className="marco" aria-hidden="true" /><span><b>{e.nome}</b><small>{e.det}</small></span>
          </li>
        ))}
      </ol>
      {quase && (
        <div className="quase">
          <p>{sobra > 0 ? `Cabem mais cerca de ${f1(sobra)} L.` : 'O galão está cheio.'} Se encher antes da troca, pare de despejar e guarde o óleo frio numa garrafa PET fechada.</p>
          <button className="btn secundario pequeno" onClick={onAjuda}>Falar com a cOillect</button>
        </div>
      )}
    </section>
  );
}

// ------------------------------------------------------------------ folha inferior (diálogo)
const FOCAVEIS = 'button, [href], input, select, textarea, summary, [tabindex]:not([tabindex="-1"])';
export function Folha({ titulo, onFechar, children, focoInicial }) {
  const ref = useRef(null);
  useEffect(() => {
    const origem = document.activeElement;
    const el = ref.current;
    (focoInicial && el.querySelector(focoInicial) || el.querySelector('input, select, textarea, .btn'))?.focus();
    return () => { if (origem && document.contains(origem)) origem.focus({ preventScroll: true }); };
  }, [focoInicial]);
  const teclado = e => {
    if (e.key === 'Escape') { e.preventDefault(); onFechar(); return; }
    if (e.key !== 'Tab') return;
    const f = [...ref.current.querySelectorAll(FOCAVEIS)].filter(x => !x.disabled && x.offsetParent !== null);
    if (!f.length) return;
    const i = f.indexOf(document.activeElement);
    if (e.shiftKey && i <= 0) { e.preventDefault(); f.at(-1).focus(); }
    else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
  };
  return createPortal(
    <div className="fundo" onMouseDown={e => { if (e.target === e.currentTarget) onFechar(); }} onKeyDown={teclado}>
      <div className="folha" role="dialog" aria-modal="true" aria-label={titulo} ref={ref}>
        <div className="pegador" />
        <header><h3>{titulo}</h3><button className="fechar" onClick={onFechar} aria-label="Fechar">✕</button></header>
        {children}
      </div>
    </div>,
    document.querySelector('.app') || document.body,
  );
}

// Formulário dentro de uma folha: mostra erro do banco e trava o botão enquanto envia.
export function useEnvio() {
  const [erro, setErro] = useState('');
  const [enviando, setEnviando] = useState(false);
  const enviar = useCallback(async fn => {
    setErro(''); setEnviando(true);
    try { return await fn(); } catch (e) { setErro(e.message); return undefined; } finally { setEnviando(false); }
  }, []);
  return { erro, setErro, enviando, enviar };
}
export const Erro = ({ texto }) => (texto ? <div className="erro" role="alert">{texto}</div> : null);

// ------------------------------------------------------------------ aviso rápido
const ToastCtx = createContext(() => {});
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }) {
  const [msg, setMsg] = useState(null);
  const timer = useRef(null);
  const avisar = useCallback(texto => {
    setMsg({ texto, id: Date.now() });
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setMsg(null), 3600);
  }, []);
  return (
    <ToastCtx.Provider value={avisar}>
      {children}
      {msg && <div className="toast" role="status" key={msg.id}>{msg.texto}</div>}
    </ToastCtx.Provider>
  );
}
