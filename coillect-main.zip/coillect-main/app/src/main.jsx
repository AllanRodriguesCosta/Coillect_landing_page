import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import './styles.css';
import App from './App.jsx';

// Atualização automática (modo autoUpdate): ao abrir, o navegador procura uma versão nova; se
// houver, ela é ativada e a página recarrega sozinha, ainda na abertura. Com o app aberto, só
// procura quando ele vai para segundo plano (e a cada 30 min enquanto estiver lá), para o
// recarregamento nunca acontecer na frente de quem está usando.
registerSW({
  immediate: true,
  onRegisteredSW(_url, registro) {
    if (!registro) return;
    const procurar = () => { if (document.visibilityState === 'hidden' && navigator.onLine) registro.update(); };
    document.addEventListener('visibilitychange', procurar);
    setInterval(procurar, 30 * 60e3);
  },
});

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
