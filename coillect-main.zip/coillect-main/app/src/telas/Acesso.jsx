import { useState } from 'react';
import { supabase, mensagemDeErro } from '../lib/supabase.js';
import { TIPOS_LOCAL } from '../lib/formato.js';
import { coordenadasDe } from '../lib/geo.js';
import { Erro, Folha, Marca, useEnvio, useToast } from '../componentes.jsx';

export function Entrar({ onCriarConta }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [esqueci, setEsqueci] = useState(false);
  const { erro, enviando, enviar } = useEnvio();
  const entrar = e => {
    e.preventDefault();
    enviar(async () => {
      const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: senha });
      if (error) throw new Error(mensagemDeErro(error));
    });
  };
  return (
    <main className="tela sem-nav">
      <div className="auth-marca"><Marca altura={84} /><div><h1>Entrar</h1><p className="lead" style={{ marginTop: 6 }}>Acompanhe o galão de óleo do seu condomínio ou estabelecimento.</p></div></div>
      <form className="form" onSubmit={entrar}>
        <div className="campo"><label htmlFor="ent-email">E-mail</label><input id="ent-email" type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} required /></div>
        <div className="campo"><label htmlFor="ent-senha">Senha</label><input id="ent-senha" type="password" autoComplete="current-password" value={senha} onChange={e => setSenha(e.target.value)} required />
          <button type="button" className="link" style={{ justifySelf: 'start', fontSize: 13.5 }} onClick={() => setEsqueci(true)}>Esqueci minha senha</button></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>{enviando ? 'Entrando…' : 'Entrar'}</button>
      </form>
      <p style={{ textAlign: 'center', margin: 0 }}>Ainda não é cliente? <button className="link" onClick={onCriarConta}>Criar conta</button></p>
      {esqueci && <EsqueciSenha emailInicial={email} onFechar={() => setEsqueci(false)} />}
    </main>
  );
}

function EsqueciSenha({ emailInicial, onFechar }) {
  const [email, setEmail] = useState(emailInicial);
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const enviarLink = e => {
    e.preventDefault();
    enviar(async () => {
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: window.location.origin });
      if (error) throw new Error(mensagemDeErro(error));
      onFechar(); avisar('Se houver uma conta com esse e-mail, o link chega em alguns minutos.');
    });
  };
  return (
    <Folha titulo="Criar uma nova senha" onFechar={onFechar}>
      <p style={{ margin: 0 }}>Enviamos um link para o seu e-mail. Pelo link, você cria a nova senha.</p>
      <form className="form" onSubmit={enviarLink}>
        <div className="campo"><label htmlFor="es-email">E-mail da conta</label><input id="es-email" type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} required /></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>{enviando ? 'Enviando…' : 'Enviar link'}</button>
      </form>
    </Folha>
  );
}

export function NovaSenha({ onPronto }) {
  const [senha, setSenha] = useState('');
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const salvar = e => {
    e.preventDefault();
    enviar(async () => {
      const { error } = await supabase.auth.updateUser({ password: senha });
      if (error) throw new Error(mensagemDeErro(error));
      avisar('Senha alterada.'); onPronto();
    });
  };
  return (
    <main className="tela sem-nav">
      <div className="auth-marca"><Marca altura={84} /><h1>Nova senha</h1></div>
      <form className="form" onSubmit={salvar}>
        <div className="campo"><label htmlFor="ns-senha">Nova senha</label><input id="ns-senha" type="password" autoComplete="new-password" minLength={8} value={senha} onChange={e => setSenha(e.target.value)} required /><span className="ajuda">Mínimo de 8 caracteres.</span></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>Salvar senha</button>
      </form>
    </main>
  );
}

export function CriarConta({ onVoltar }) {
  const [f, setF] = useState({ nome: '', telefone: '', email: '', senha: '' });
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const campo = k => ({ value: f[k], onChange: e => setF({ ...f, [k]: e.target.value }) });
  const criar = e => {
    e.preventDefault();
    enviar(async () => {
      const { data, error } = await supabase.auth.signUp({
        email: f.email.trim(), password: f.senha,
        options: { data: { nome: f.nome.trim(), telefone: f.telefone.trim() }, emailRedirectTo: window.location.origin },
      });
      if (error) throw new Error(mensagemDeErro(error));
      if (!data.session) avisar('Conta criada. Confirme pelo link enviado ao seu e-mail e depois entre.');
    });
  };
  return (
    <main className="tela sem-nav">
      <div><button className="link" onClick={onVoltar}>← Voltar</button></div>
      <h1>Criar conta</h1><p className="lead">Passo 1 de 2 · seus dados de acesso</p>
      <form className="form" onSubmit={criar}>
        <div className="campo"><label htmlFor="cad-nome">Nome do responsável</label><input id="cad-nome" autoComplete="name" required {...campo('nome')} /></div>
        <div className="campo"><label htmlFor="cad-tel">Telefone (WhatsApp)</label><input id="cad-tel" type="tel" autoComplete="tel" placeholder="(11) 90000-0000" required {...campo('telefone')} /></div>
        <div className="campo"><label htmlFor="cad-email">E-mail</label><input id="cad-email" type="email" autoComplete="email" required {...campo('email')} /></div>
        <div className="campo"><label htmlFor="cad-senha">Senha</label><input id="cad-senha" type="password" autoComplete="new-password" minLength={8} required {...campo('senha')} /><span className="ajuda">Mínimo de 8 caracteres.</span></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>{enviando ? 'Criando conta…' : 'Continuar'}</button>
      </form>
    </main>
  );
}

// Passo 2: o cliente já tem conta, mas ainda não tem local.
export function NovoLocal({ usuarioId, onCriado, onSair }) {
  const [f, setF] = useState({ tipo: 'condominio', nome: '', cep: '', logradouro: '', numero: '', bairro: '', cidade: 'Cotia', uf: 'SP' });
  const { erro, enviando, enviar } = useEnvio();
  const campo = k => ({ value: f[k], onChange: e => setF({ ...f, [k]: e.target.value }) });
  const salvar = e => {
    e.preventDefault();
    enviar(async () => {
      const novo = { ...f, uf: f.uf.trim().toUpperCase().slice(0, 2), cliente_id: usuarioId };
      const { data, error } = await supabase.from('locais').insert(novo).select('id').single();
      if (error) throw new Error(mensagemDeErro(error));
      // Coordenadas para o mapa: à parte, para uma falha aqui não impedir o cadastro.
      const coord = await coordenadasDe(novo);
      if (coord) await supabase.from('locais').update(coord).eq('id', data.id);
      await onCriado();
    });
  };
  return (
    <main className="tela sem-nav">
      <div><button className="link" onClick={onSair}>← Sair</button></div>
      <h1>Seu local</h1><p className="lead">Passo 2 de 2 · onde o galão será instalado</p>
      <form className="form" onSubmit={salvar}>
        <fieldset className="campo" style={{ border: 0, padding: 0, margin: 0 }}>
          <legend style={{ fontWeight: 700, fontSize: 13.5, marginBottom: 6 }}>Tipo</legend>
          <div className="tipos">{Object.entries(TIPOS_LOCAL).map(([k, v]) => (
            <label key={k}><input type="radio" name="tipo" value={k} checked={f.tipo === k} onChange={() => setF({ ...f, tipo: k })} /> {v}</label>
          ))}</div>
        </fieldset>
        <div className="campo"><label htmlFor="loc-nome">Nome</label><input id="loc-nome" required placeholder="Ex.: Residencial Aurora" {...campo('nome')} /></div>
        <div className="duas">
          <div className="campo"><label htmlFor="loc-cep">CEP</label><input id="loc-cep" inputMode="numeric" autoComplete="postal-code" {...campo('cep')} /></div>
          <div className="campo"><label htmlFor="loc-num">Número</label><input id="loc-num" required {...campo('numero')} /></div>
        </div>
        <div className="campo"><label htmlFor="loc-rua">Rua</label><input id="loc-rua" autoComplete="address-line1" required {...campo('logradouro')} /></div>
        <div className="campo"><label htmlFor="loc-bairro">Bairro</label><input id="loc-bairro" {...campo('bairro')} /></div>
        <div className="duas">
          <div className="campo"><label htmlFor="loc-cidade">Cidade</label><input id="loc-cidade" autoComplete="address-level2" required {...campo('cidade')} /></div>
          <div className="campo"><label htmlFor="loc-uf">UF</label><input id="loc-uf" maxLength={2} autoComplete="address-level1" required {...campo('uf')} /></div>
        </div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>{enviando ? 'Salvando…' : 'Concluir cadastro'}</button>
      </form>
    </main>
  );
}
