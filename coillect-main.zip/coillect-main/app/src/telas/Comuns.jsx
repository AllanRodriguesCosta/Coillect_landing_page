import { useState } from 'react';
import { rpc, supabase, mensagemDeErro } from '../lib/supabase.js';
import { useDados } from '../lib/dados.jsx';
import { Erro, Folha, useEnvio, useToast } from '../componentes.jsx';

export const tituloPedido = (p, galao) => (p.tipo === 'entrega' ? 'Entrega de galão' : `Troca do galão ${galao?.codigo ?? ''}`.trim());

export function CancelarPedido({ pedido, onFechar }) {
  const { perfil, local, galao, recarregar } = useDados();
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const empresa = perfil.papel === 'empresa';
  const oQue = pedido.tipo === 'entrega' ? 'a entrega de galão' : `a troca do galão ${galao(pedido.galao_id)?.codigo ?? ''}`;
  const efeito = empresa ? 'O cliente vê um aviso no app.' : (pedido.tipo === 'entrega' ? 'A equipe não vai mais levar o galão.' : 'A equipe não vai mais ao local para esta troca.');
  const cancelar = () => enviar(async () => {
    await rpc('cancelar_solicitacao', { solicitacao: pedido.id });
    await recarregar(['pedidos']);
    onFechar(); avisar(empresa ? 'Pedido cancelado. O cliente vê um aviso no app.' : 'Pedido cancelado.');
  });
  return (
    <Folha titulo="Cancelar pedido" onFechar={onFechar}>
      <p style={{ margin: 0 }}><b>Cancelar {oQue}?</b></p>
      <p style={{ margin: 0 }}>{local(pedido.local_id)?.nome}. {efeito}</p>
      <Erro texto={erro} />
      <div className="botoes">
        <button className="btn secundario flex" onClick={onFechar}>Manter pedido</button>
        <button className="btn perigo flex" onClick={cancelar} disabled={enviando}>Cancelar pedido</button>
      </div>
    </Folha>
  );
}

export function FalarComEquipe({ localId, onFechar }) {
  const [texto, setTexto] = useState('');
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const mandar = e => {
    e.preventDefault();
    enviar(async () => {
      const { error } = await supabase.from('mensagens').insert({ local_id: localId, texto: texto.trim() });
      if (error) throw new Error(mensagemDeErro(error));
      onFechar(); avisar('Mensagem enviada para a equipe cOillect.');
    });
  };
  return (
    <Folha titulo="Falar com a cOillect" onFechar={onFechar}>
      <p style={{ margin: 0 }}>A mensagem vai para a equipe cOillect com o nome do seu local.</p>
      <form className="form" onSubmit={mandar}>
        <div className="campo"><label htmlFor="aj-msg">Mensagem</label><textarea id="aj-msg" required maxLength={2000} value={texto} onChange={e => setTexto(e.target.value)} placeholder="Ex.: o galão foi tirado do lugar e o sensor parou" /></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>{enviando ? 'Enviando…' : 'Enviar mensagem'}</button>
      </form>
    </Folha>
  );
}

export function Carregando() {
  return <main className="tela"><div className="carregando">Carregando…</div></main>;
}
