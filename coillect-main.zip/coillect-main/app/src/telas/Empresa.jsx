import { useEffect, useState } from 'react';
import { rpc, supabase, mensagemDeErro } from '../lib/supabase.js';
import { useDados } from '../lib/dados.jsx';
import { D, H, brl, data, diaHora, diaMes, dois, endereco, f0, f1, linkMapa, linkTelefone, ms, numBR, r1, TIPOS_LOCAL } from '../lib/formato.js';
import { aberto, conectado, faseDe, litrosDe, semSinal } from '../lib/regras.js';
import { Barra, ChipFase, ChipStatus, Erro, Folha, Galao, Icone, Logo, Rel, useEnvio, useToast } from '../componentes.jsx';
import { CancelarPedido, tituloPedido } from './Comuns.jsx';
import { Mapa } from '../mapa.jsx';

// ------------------------------------------------------------------ utilidades da empresa
function useEmpresa() {
  const d = useDados();
  const velho = g => semSinal(d.sensorDe(g.id));
  const cor = g => (velho(g) ? 'var(--texto-2)' : { coleta: 'var(--ferrugem)', atencao: 'var(--oleo-texto)', ok: 'inherit' }[faseDe(g.nivel_pct, d.cfg)]);
  const pedidoAberto = galaoId => d.pedidos.find(p => p.galao_id === galaoId && aberto(p));
  const urgencia = p => { const g = p.galao_id && d.galao(p.galao_id); return g && g.status === 'instalado' ? g.nivel_pct : -1; };
  const porUrgencia = (a, b) => urgencia(b) - urgencia(a) || ms(a.criado_em) - ms(b.criado_em);
  return { ...d, velho, cor, pedidoAberto, porUrgencia };
}

export function Empresa({ tela, irPara }) {
  const [folha, setFolha] = useState(null);
  const abrir = (tipo, extra) => setFolha({ tipo, ...extra });
  const fechar = () => setFolha(null);
  const telas = { painel: Painel, pedidos: Pedidos, galoes: Galoes, sensores: Sensores, ajustes: Ajustes };
  const Tela = telas[tela] || Painel;
  return (
    <>
      <Tela abrir={abrir} irPara={irPara} />
      {folha?.tipo === 'galao' && <VerGalao galaoId={folha.galaoId} onFechar={fechar} irPara={irPara} />}
      {folha?.tipo === 'agendar' && <Agendar pedido={folha.pedido} onFechar={fechar} />}
      {folha?.tipo === 'concluir' && (folha.pedido.tipo === 'entrega'
        ? <ConcluirEntrega pedido={folha.pedido} onFechar={fechar} />
        : <ConcluirTroca pedido={folha.pedido} onFechar={fechar} onConcluida={r => abrir('troca-concluida', { resultado: r })} />)}
      {folha?.tipo === 'troca-concluida' && <TrocaConcluida resultado={folha.resultado} onFechar={fechar} />}
      {folha?.tipo === 'cancelar' && <CancelarPedido pedido={folha.pedido} onFechar={fechar} />}
      {folha?.tipo === 'calibrar' && <Calibrar galao={folha.galao} onFechar={fechar} />}
      {folha?.tipo === 'novo-galao' && <NovoGalao onFechar={fechar} />}
      {folha?.tipo === 'vincular' && <Vincular sensor={folha.sensor} onFechar={fechar} />}
      {folha?.tipo === 'chave' && <GerarChave sensor={folha.sensor} onFechar={fechar} />}
    </>
  );
}

// ------------------------------------------------------------------ Painel
function Painel({ abrir }) {
  const e = useEmpresa();
  const { galoes, pedidos, reciclagens, dispositivos, mensagens, cfg, local, galao } = e;
  const inst = galoes.filter(g => g.status === 'instalado').sort((a, b) => b.nivel_pct - a.nivel_pct);
  const acima = inst.filter(g => g.nivel_pct >= cfg.limite_atencao).length;
  const aAgendar = pedidos.filter(p => p.status === 'pendente').length;
  const mes = reciclagens.filter(r => ms(r.criado_em) > Date.now() - 30 * D);
  const litros = mes.reduce((a, r) => a + Number(r.litros), 0), valor = mes.reduce((a, r) => a + Number(r.valor_total), 0);
  const offline = dispositivos.filter(d => d.galao_id && semSinal(d) && galao(d.galao_id)?.local_id);
  const naoLidas = mensagens.filter(m => !m.lida_em);
  return (
    <>
      <header className="topo so-celular"><div className="marca"><small>Central de coletas</small><Logo /></div></header>
      <h1 className="so-pc">Central de coletas</h1>
      <div className="kpis">
        <div className="kpi destaque"><div><span>Reciclado nos últimos 30 dias</span><b className="num">{f1(litros)} L</b></div><div style={{ textAlign: 'right' }}><span>Receita estimada</span><b className="num" style={{ fontSize: 22 }}>{brl(valor)}</b></div></div>
        <div className="kpi"><b className="num">{inst.length}</b><span>galões instalados</span></div>
        <div className="kpi"><b className="num" style={{ color: 'var(--oleo-texto)' }}>{acima}</b><span>acima de {cfg.limite_atencao}%</span></div>
        <div className="kpi"><b className="num" style={{ color: 'var(--ferrugem)' }}>{aAgendar}</b><span>{aAgendar === 1 ? 'pedido a agendar' : 'pedidos a agendar'}</span></div>
        <div className="kpi"><b className="num">{galoes.filter(g => g.status === 'estoque').length}</b><span>galões em estoque</span></div>
      </div>
      {offline.length > 0 && (
        <div className="aviso coleta"><strong>{offline.length === 1 ? '1 sensor sem comunicação' : `${offline.length} sensores sem comunicação`}</strong>
          <p>Peça ao responsável para conferir o Wi-Fi do local e se o ESP32 está ligado.</p>
          <div className="acoes">{offline.map(d => (
            <button key={d.id} className="btn secundario pequeno" onClick={() => abrir('galao', { galaoId: d.galao_id })}>{d.codigo} · {local(galao(d.galao_id).local_id)?.nome} · <Rel t={d.ultimo_contato_em} /></button>
          ))}</div>
        </div>
      )}
      {naoLidas.length > 0 && <Mensagens lista={naoLidas} />}
      <MapaLocais abrir={abrir} />
      <div className="so-celular" style={{ display: 'grid', gap: 12 }}>
        <h2 className="secao">Galões por nível</h2>
        <div className="lista">{inst.map(g => (
          <button key={g.id} className="item linha-galao" style={{ textAlign: 'left' }} onClick={() => abrir('galao', { galaoId: g.id })}>
            <span><span className="titulo">{local(g.local_id)?.nome}</span><br /><span className="meta mono">{g.codigo} · {g.ultima_leitura_em ? <Rel t={g.ultima_leitura_em} /> : 'sem leitura'}{e.velho(g) ? ' · sem sinal' : ''}</span></span>
            <b className="num" style={{ color: e.cor(g) }}>{f0(g.nivel_pct)}%</b>
            <Barra nivel={g.nivel_pct} cfg={cfg} velha={e.velho(g)} />
          </button>
        ))}</div>
      </div>
      <div className="so-pc"><div className="painel-pc">
        <section><h2 className="secao" style={{ marginBottom: 10 }}>Galões instalados</h2><div className="cartao sem-padding"><TabelaGaloes inst={inst} abrir={abrir} /></div></section>
        <section><Fila abrir={abrir} /></section>
      </div></div>
    </>
  );
}

// Um marcador por local com coordenadas, com o nível do galão mais cheio instalado nele.
function MapaLocais({ abrir }) {
  const { locais, galoes, cfg, velho } = useEmpresa();
  const pontos = locais.filter(l => l.latitude != null).map(l => {
    const g = galoes.filter(x => x.local_id === l.id && x.status === 'instalado').sort((a, b) => b.nivel_pct - a.nivel_pct)[0];
    if (!g) return { id: l.id, lat: Number(l.latitude), lng: Number(l.longitude), rotulo: 'sem galão', titulo: `${l.nome}: sem galão instalado`, fase: 'neutro' };
    const fase = velho(g) ? 'neutro' : faseDe(g.nivel_pct, cfg);
    return {
      id: l.id, lat: Number(l.latitude), lng: Number(l.longitude), fase,
      rotulo: `${f0(g.nivel_pct)}%`,
      titulo: `${l.nome}, galão ${g.codigo}: ${f0(g.nivel_pct)}%${fase === 'neutro' ? ', sem sinal' : ''}`,
      onClick: () => abrir('galao', { galaoId: g.id }),
    };
  });
  if (!pontos.length) return null;
  return (
    <section style={{ display: 'grid', gap: 10 }}>
      <h2 className="secao">Mapa dos locais</h2>
      <div>
        <Mapa pontos={pontos} altura={340} rotulo="Mapa dos locais com o nível de cada galão" />
        <div className="mapa-legenda" aria-hidden="true">
          <span style={{ '--cor': 'var(--folha)' }}>abaixo de {cfg.limite_atencao}%</span>
          <span style={{ '--cor': 'var(--oleo)' }}>atenção</span>
          <span style={{ '--cor': 'var(--ferrugem)' }}>{cfg.limite_coleta}% ou mais</span>
          <span style={{ '--cor': 'var(--texto-2)' }}>sem sinal ou sem galão</span>
        </div>
      </div>
    </section>
  );
}

function Mensagens({ lista }) {
  const { local, recarregar } = useDados();
  const lida = async m => { await supabase.from('mensagens').update({ lida_em: new Date().toISOString() }).eq('id', m.id); recarregar(['mensagens']); };
  return (
    <section style={{ display: 'grid', gap: 10 }}>
      <h2 className="secao">Mensagens dos clientes ({lista.length})</h2>
      <div className="lista grade">{lista.map(m => {
        const l = local(m.local_id);
        return (
          <article className="item" key={m.id}>
            <div className="linha1"><span className="titulo">{l?.nome}</span><span className="meta"><Rel t={m.criado_em} /></span></div>
            <div>“{m.texto}”</div>
            <div className="acoes">
              {l?.cliente?.telefone && <a className="btn secundario pequeno" href={linkTelefone(l.cliente.telefone)}><Icone nome="telefone" tamanho={18} />Ligar</a>}
              <button className="btn secundario pequeno" onClick={() => lida(m)}>Marcar como lida</button>
            </div>
          </article>
        );
      })}</div>
    </section>
  );
}

function Th({ campo, ordem, onOrdenar, children }) {
  const ativo = ordem.campo === campo;
  return (
    <th scope="col" aria-sort={ativo ? (ordem.desc ? 'descending' : 'ascending') : undefined}>
      <button onClick={() => onOrdenar(campo)}>{children}{ativo && <span style={{ display: 'inline-flex', transform: `rotate(${ordem.desc ? 0 : 180}deg)` }}><Icone nome="seta" tamanho={14} /></span>}</button>
    </th>
  );
}

function TabelaGaloes({ inst, abrir }) {
  const e = useEmpresa();
  const [ordem, setOrdem] = useState({ campo: 'nivel', desc: true });
  const chave = { local: g => e.local(g.local_id)?.nome || '', nivel: g => g.nivel_pct, leitura: g => ms(g.ultima_leitura_em) || 0 }[ordem.campo];
  const lista = [...inst].sort((a, b) => { const x = chave(a), y = chave(b); const c = typeof x === 'string' ? x.localeCompare(y, 'pt-BR') : x - y; return ordem.desc ? -c : c; });
  const ordenar = campo => setOrdem(o => (o.campo === campo ? { campo, desc: !o.desc } : { campo, desc: campo !== 'local' }));
  const th = (campo, rotulo) => <Th campo={campo} ordem={ordem} onOrdenar={ordenar}>{rotulo}</Th>;
  return (
    <div className="rolagem"><table className="tabela">
      <caption className="sr">Galões instalados. Use o título de uma coluna para ordenar.</caption>
      <colgroup><col style={{ width: '34%' }} /><col style={{ width: '24%' }} /><col style={{ width: '20%' }} /><col style={{ width: '22%' }} /></colgroup>
      <thead><tr>{th('local', 'Local')}{th('nivel', 'Nível')}{th('leitura', 'Última leitura')}<th scope="col">Próxima ação</th></tr></thead>
      <tbody>{lista.map(g => {
        const p = e.pedidoAberto(g.id), d = e.sensorDe(g.id), l = e.local(g.local_id);
        return (
          <tr key={g.id}>
            <td><b>{l?.nome}</b><br /><span className="meta">{TIPOS_LOCAL[l?.tipo]} · <span className="mono">{g.codigo}</span></span></td>
            <td><div className="nivel"><Barra nivel={g.nivel_pct} cfg={e.cfg} velha={e.velho(g)} /><b className="num" style={{ color: e.cor(g) }}>{f0(g.nivel_pct)}%</b></div></td>
            <td className="num"><span className={`ponto ${d ? (conectado(d) ? 'online' : 'offline') : ''}`} aria-hidden="true" />{g.ultima_leitura_em ? <Rel t={g.ultima_leitura_em} /> : 'sem leitura'}{semSinal(d) && <span className="meta"> sem sinal</span>}</td>
            <td>{p
              ? (p.status === 'pendente'
                ? <button className="btn primario pequeno" onClick={() => abrir('agendar', { pedido: p })}>Agendar</button>
                : <><button className="btn secundario pequeno" onClick={() => abrir('concluir', { pedido: p })}>Concluir troca</button><span className="meta" style={{ display: 'block', marginTop: 4 }}>{diaHora(p.agendada_para)}</span></>)
              : <button className="btn secundario pequeno" onClick={() => abrir('galao', { galaoId: g.id })}>Detalhes</button>}</td>
          </tr>
        );
      })}</tbody>
    </table></div>
  );
}

function LinhaFila({ p, abrir }) {
  const { galao, local } = useDados();
  const g = p.galao_id && galao(p.galao_id);
  return (
    <article className="item"><div className="linha1"><span className="titulo">{local(p.local_id)?.nome}</span></div>
      <div className="meta">{tituloPedido(p, g)}{g && g.status === 'instalado' && <> · <b className="num">{f0(g.nivel_pct)}%</b></>}{p.status === 'agendada' && <> · {diaHora(p.agendada_para)}</>}</div>
      <div className="acoes">{p.status === 'pendente'
        ? <button className="btn primario pequeno" onClick={() => abrir('agendar', { pedido: p })}>Agendar</button>
        : <button className="btn primario pequeno" onClick={() => abrir('concluir', { pedido: p })}>{p.tipo === 'entrega' ? 'Concluir entrega' : 'Concluir troca'}</button>}</div>
    </article>
  );
}

function Fila({ abrir }) {
  const e = useEmpresa();
  const pend = e.pedidos.filter(p => p.status === 'pendente').sort(e.porUrgencia);
  const ag = e.pedidos.filter(p => p.status === 'agendada').sort((a, b) => ms(a.agendada_para) - ms(b.agendada_para));
  return (
    <>
      <h2 className="secao" style={{ marginBottom: 10 }}>A agendar ({pend.length})</h2>
      <div className="fila">{pend.length ? pend.map(p => <LinhaFila key={p.id} p={p} abrir={abrir} />) : <p className="meta">Nenhum pedido esperando agendamento.</p>}</div>
      <h2 className="secao" style={{ margin: '18px 0 10px' }}>Agendados ({ag.length})</h2>
      <div className="fila">{ag.length ? ag.map(p => <LinhaFila key={p.id} p={p} abrir={abrir} />) : <p className="meta">Nenhuma visita agendada.</p>}</div>
    </>
  );
}

// ------------------------------------------------------------------ Pedidos
function CartaoPedido({ p, abrir }) {
  const { local, galao } = useDados();
  const l = local(p.local_id), g = p.galao_id && galao(p.galao_id);
  return (
    <article className="item">
      <div className="linha1"><span className="titulo">{tituloPedido(p, g)}</span><ChipStatus pedido={p} perfil="empresa" /></div>
      <div className="meta"><b>{l?.nome}</b> · {l && endereco(l)}</div>
      <div className="meta">{p.origem === 'automatica' ? 'Pedido automático' : 'Pedido pelo cliente'} · <Rel t={p.criado_em} />{g && g.status === 'instalado' && <> · nível <b className="num">{f1(g.nivel_pct)}%</b></>}</div>
      {p.status === 'agendada' && <div className="meta">Agendado para <b>{diaHora(p.agendada_para)}</b></div>}
      {p.status === 'cancelada' && <div className="meta">Cancelado {p.cancelado_por === 'empresa' ? 'pela equipe' : 'pelo cliente'}</div>}
      {p.litros_coletados != null && <div className="meta num">{f1(p.litros_coletados)} L para reciclagem</div>}
      {p.observacoes && <div className="meta">“{p.observacoes}”</div>}
      {aberto(p) && (
        <>
          {p.status === 'pendente'
            ? <button className="btn primario largo" onClick={() => abrir('agendar', { pedido: p })}>Agendar {p.tipo === 'entrega' ? 'entrega' : 'troca'}</button>
            : <button className="btn primario largo" onClick={() => abrir('concluir', { pedido: p })}>{p.tipo === 'entrega' ? 'Concluir entrega' : 'Concluir troca'}</button>}
          <div className="acoes">
            {l && <a className="btn secundario pequeno" href={linkMapa(l)} target="_blank" rel="noopener"><Icone nome="mapa" tamanho={18} />Mapa</a>}
            {l?.cliente?.telefone && <a className="btn secundario pequeno" href={linkTelefone(l.cliente.telefone)} aria-label={`Ligar para ${l.cliente.nome}, ${l.cliente.telefone}`}><Icone nome="telefone" tamanho={18} />Ligar</a>}
            <details className="mais"><summary>Mais opções</summary><div className="mais-menu">
              {p.status === 'pendente'
                ? <button className="btn secundario pequeno" onClick={() => abrir('concluir', { pedido: p })}>Concluir sem agendar</button>
                : <button className="btn secundario pequeno" onClick={() => abrir('agendar', { pedido: p })}>Reagendar</button>}
              <button className="btn perigo pequeno" onClick={() => abrir('cancelar', { pedido: p })}>Cancelar pedido</button>
            </div></details>
          </div>
        </>
      )}
    </article>
  );
}

function GrupoPedidos({ titulo, lista, abrir }) {
  if (!lista.length) return null;
  return <><h2 className="secao">{titulo} ({lista.length})</h2><div className="lista grade">{lista.map(p => <CartaoPedido key={p.id} p={p} abrir={abrir} />)}</div></>;
}

function Pedidos({ abrir }) {
  const e = useEmpresa();
  const [filtro, setFiltro] = useState('abertos');
  const abertos = e.pedidos.filter(aberto);
  const fimHoje = new Date().setHours(23, 59, 59, 999);
  const porData = (a, b) => ms(a.agendada_para) - ms(b.agendada_para);
  const encerrados = e.pedidos.filter(p => !aberto(p));
  return (
    <>
      <h1>Pedidos</h1><p className="lead">Entregas de galão e trocas a fazer.</p>
      <div className="filtros">
        <button aria-pressed={filtro === 'abertos'} onClick={() => setFiltro('abertos')}>Em aberto ({abertos.length})</button>
        <button aria-pressed={filtro === 'encerrados'} onClick={() => setFiltro('encerrados')}>Encerrados</button>
      </div>
      {filtro === 'abertos' ? (abertos.length ? <>
        <GrupoPedidos abrir={abrir} titulo="Para hoje" lista={abertos.filter(p => p.status === 'agendada' && ms(p.agendada_para) <= fimHoje).sort(porData)} />
        <GrupoPedidos abrir={abrir} titulo="A agendar, mais cheios primeiro" lista={abertos.filter(p => p.status === 'pendente').sort(e.porUrgencia)} />
        <GrupoPedidos abrir={abrir} titulo="Próximos dias" lista={abertos.filter(p => p.status === 'agendada' && ms(p.agendada_para) > fimHoje).sort(porData)} />
      </> : <div className="vazio"><strong>Nenhum pedido em aberto</strong><span>Pedidos chegam quando um cliente pede galão ou quando um galão passa de {e.cfg.limite_coleta}%.</span></div>)
        : (encerrados.length ? <div className="lista grade">{encerrados.map(p => <CartaoPedido key={p.id} p={p} abrir={abrir} />)}</div> : <div className="vazio"><strong>Nenhum pedido encerrado</strong></div>)}
    </>
  );
}

function Agendar({ pedido, onFechar }) {
  const { local, galao, recarregar } = useDados();
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
  const dias = Array.from({ length: 8 }, (_, i) => hoje.getTime() + i * D);
  const base = pedido.agendada_para && new Date(pedido.agendada_para);
  const [dia, setDia] = useState(base ? new Date(base).setHours(0, 0, 0, 0) : dias[1]);
  const [hora, setHora] = useState(base ? base.getHours() : 9);
  const servico = pedido.tipo === 'entrega' ? 'Entrega' : 'Troca';
  const salvar = ev => {
    ev.preventDefault();
    enviar(async () => {
      const quando = Number(dia) + Number(hora) * H;
      await rpc('agendar_solicitacao', { solicitacao: pedido.id, data: new Date(quando).toISOString() });
      await recarregar(['pedidos']);
      onFechar(); avisar(`${servico} agendada para ${diaHora(quando)}.`);
    });
  };
  return (
    <Folha titulo={pedido.status === 'agendada' ? 'Reagendar' : 'Agendar'} onFechar={onFechar}>
      <div className="resumo"><div><span>Local</span><span>{local(pedido.local_id)?.nome}</span></div><div><span>Serviço</span><span>{tituloPedido(pedido, galao(pedido.galao_id))}</span></div></div>
      <form className="form" onSubmit={salvar}>
        <div className="duas">
          <div className="campo"><label htmlFor="ag-dia">Dia</label><select id="ag-dia" value={dia} onChange={e => setDia(e.target.value)}>
            {dias.map((t, i) => <option key={t} value={t}>{i === 0 ? 'Hoje, ' : i === 1 ? 'Amanhã, ' : ''}{diaMes(t)}</option>)}</select></div>
          <div className="campo"><label htmlFor="ag-hora">Horário</label><select id="ag-hora" value={hora} onChange={e => setHora(e.target.value)}>
            {Array.from({ length: 11 }, (_, i) => i + 8).map(h => <option key={h} value={h}>{dois(h)}:00</option>)}</select></div>
        </div>
        <span className="ajuda">O cliente vê o dia e o horário no app.</span>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>{pedido.status === 'agendada' ? 'Salvar novo horário' : `Agendar ${servico.toLowerCase()}`}</button>
      </form>
    </Folha>
  );
}

const opcoesEstoque = galoes => galoes.filter(g => g.status === 'estoque').map(g => <option key={g.id} value={g.id}>{g.codigo} · {f0(g.capacidade_litros)} L</option>);

function ConcluirEntrega({ pedido, onFechar }) {
  const { galoes, dispositivos, local, recarregar } = useDados();
  const estoque = galoes.filter(g => g.status === 'estoque');
  const livres = dispositivos.filter(d => !d.galao_id);
  const [galaoId, setGalaoId] = useState(estoque[0]?.id || '');
  const [sensorId, setSensorId] = useState('');
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const concluir = ev => {
    ev.preventDefault();
    enviar(async () => {
      await rpc('concluir_entrega', { solicitacao: pedido.id, galao: galaoId });
      if (sensorId) {
        const { error } = await supabase.from('dispositivos').update({ galao_id: galaoId }).eq('id', sensorId);
        if (error) throw new Error(mensagemDeErro(error));
      }
      await recarregar();
      onFechar(); avisar('Entrega concluída. O galão já aparece para o cliente.');
    });
  };
  if (!estoque.length) return <SemEstoque onFechar={onFechar} />;
  return (
    <Folha titulo="Concluir entrega" onFechar={onFechar}>
      <div className="resumo"><div><span>Local</span><span>{local(pedido.local_id)?.nome}</span></div></div>
      <form className="form" onSubmit={concluir}>
        <div className="campo"><label htmlFor="ce-galao">Galão entregue</label><select id="ce-galao" value={galaoId} onChange={e => setGalaoId(e.target.value)}>{opcoesEstoque(galoes)}</select></div>
        <div className="campo"><label htmlFor="ce-disp">Sensor instalado</label><select id="ce-disp" value={sensorId} onChange={e => setSensorId(e.target.value)}>
          <option value="">Instalar sensor depois</option>{livres.map(d => <option key={d.id} value={d.id}>{d.codigo}</option>)}</select></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>Concluir entrega</button>
      </form>
    </Folha>
  );
}

function SemEstoque({ onFechar }) {
  return (
    <Folha titulo="Sem galão vazio no estoque" onFechar={onFechar}>
      <p style={{ margin: 0 }}>Para concluir, é preciso um galão vazio. Em Galões, devolva ao estoque um galão higienizado ou cadastre um novo.</p>
      <button className="btn primario" onClick={onFechar}>Entendi</button>
    </Folha>
  );
}

function ConcluirTroca({ pedido, onFechar, onConcluida }) {
  const { galoes, galao, local, sensorDe, cfg, recarregar } = useDados();
  const antigo = galao(pedido.galao_id);
  const est = litrosDe(antigo);
  const d = sensorDe(antigo.id);
  const estoque = galoes.filter(g => g.status === 'estoque');
  const [novoId, setNovoId] = useState(estoque[0]?.id || '');
  const [litros, setLitros] = useState(f1(est));
  const { erro, setErro, enviando, enviar } = useEnvio();
  const concluir = ev => {
    ev.preventDefault();
    const l = r1(numBR(litros));
    if (!(l > 0 && l <= antigo.capacidade_litros)) { setErro(`Informe um volume entre 0,1 e ${f0(antigo.capacidade_litros)} L.`); return; }
    enviar(async () => {
      await rpc('concluir_coleta', { solicitacao: pedido.id, galao_novo: novoId, litros: l });
      await recarregar();
      onConcluida({ pedidoId: pedido.id, antigo: { ...antigo }, novoId, litros: l, valor: l * cfg.valor_litro, sensor: d?.codigo, localNome: local(pedido.local_id)?.nome });
    });
  };
  if (!estoque.length) return <SemEstoque onFechar={onFechar} />;
  return (
    <Folha titulo="Concluir troca" onFechar={onFechar}>
      <div className="resumo">
        <div><span>Local</span><span>{local(pedido.local_id)?.nome}</span></div>
        <div><span>Galão retirado</span><span className="mono">{antigo.codigo} · {f1(antigo.nivel_pct)}%</span></div>
        {d && <div><span>Sensor</span><span>{d.codigo} passa para o galão novo</span></div>}
      </div>
      <form className="form" onSubmit={concluir}>
        <div className="campo"><label htmlFor="cc-galao">Galão vazio instalado</label><select id="cc-galao" value={novoId} onChange={e => setNovoId(e.target.value)}>{opcoesEstoque(galoes)}</select></div>
        <div className="campo"><label htmlFor="cc-litros">Litros retirados</label><input id="cc-litros" type="text" inputMode="decimal" autoComplete="off" value={litros} onChange={e => setLitros(e.target.value)} required />
          <span className="ajuda">O sensor estimou {f1(est)} L. Corrija se o galão tiver outro volume.</span></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>{enviando ? 'Concluindo…' : 'Concluir troca'}</button>
      </form>
    </Folha>
  );
}

// O galão cheio sai para a reciclagem, o vazio entra e o sensor pousa nele.
function TrocaConcluida({ resultado: r, onFechar }) {
  const { galao, cfg, recarregar } = useDados();
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const novo = galao(r.novoId);
  const desfazer = () => enviar(async () => {
    await rpc('desfazer_coleta', { solicitacao: r.pedidoId });
    await recarregar();
    onFechar(); avisar('Troca desfeita. O pedido voltou para a lista.');
  });
  return (
    <Folha titulo="Troca concluída" onFechar={onFechar} focoInicial=".btn.primario">
      <div className="troca-anim" aria-hidden="true">
        <figure className="sai"><Galao galao={r.antigo} cfg={cfg} tamanho={96} /><figcaption>{r.antigo.codigo} · reciclagem</figcaption></figure>
        {novo && <figure className="entra"><Galao galao={novo} cfg={cfg} tamanho={96} comSensor={!!r.sensor} /><figcaption>{novo.codigo} · instalado</figcaption></figure>}
      </div>
      <p style={{ margin: 0 }}><b className="num">{f1(r.litros)} L</b> de óleo de {r.localNome} seguem para a reciclagem.{r.sensor && novo && <> O <span className="cod">{r.sensor}</span> já está medindo o <span className="cod">{novo.codigo}</span>.</>}</p>
      <div className="resumo"><div><span>Receita estimada</span><span className="num"><b>{brl(r.valor)}</b></span></div></div>
      <Erro texto={erro} />
      <button className="btn primario largo" onClick={onFechar}>Pronto</button>
      <p className="centro"><button className="link" onClick={desfazer} disabled={enviando}>Desfazer troca</button></p>
    </Folha>
  );
}

function VerGalao({ galaoId, onFechar, irPara }) {
  const { galao, local, sensorDe, cfg, pedidos } = useDados();
  const g = galao(galaoId);
  const l = local(g?.local_id);
  if (!g || !l) return null;
  const d = sensorDe(g.id);
  const p = pedidos.find(x => x.galao_id === g.id && aberto(x));
  return (
    <Folha titulo={l.nome} onFechar={onFechar}>
      <div className="cartao cartao-galao"><Galao galao={g} cfg={cfg} tamanho={130} comSensor={!!d} />
        <div className="medida"><div className="codigo">{g.codigo}</div><div className="pct num">{f0(g.nivel_pct)}<small>%</small></div><div className="litros num">{f1(litrosDe(g))} L</div><div style={{ marginTop: 8 }}><ChipFase nivel={g.nivel_pct} cfg={cfg} /></div></div></div>
      <div className="resumo">
        <div><span>Responsável</span><span>{l.cliente?.nome || '—'}</span></div>
        <div><span>Telefone</span>{l.cliente?.telefone ? <a className="num" href={linkTelefone(l.cliente.telefone)}>{l.cliente.telefone}</a> : <span>—</span>}</div>
        <div><span>Endereço</span><span style={{ textAlign: 'right' }}>{endereco(l)}<br /><a href={linkMapa(l)} target="_blank" rel="noopener">Abrir no mapa</a></span></div>
        <div><span>Instalado</span><span>{g.instalado_em ? data(g.instalado_em) : '—'}</span></div>
      </div>
      {semSinal(d) && <div className="aviso coleta"><strong>{d.codigo} sem sinal <Rel t={d.ultimo_contato_em} /></strong><p>Peça para conferir se o ESP32 está ligado na tomada e se o Wi-Fi do local mudou de senha.</p></div>}
      {l.cliente?.telefone && <a className="btn primario" href={linkTelefone(l.cliente.telefone)}><Icone nome="telefone" tamanho={18} />Ligar para {l.cliente.nome.split(' ')[0]}</a>}
      {p && <button className="btn secundario" onClick={() => { onFechar(); irPara('pedidos'); }}>Ver pedido em aberto</button>}
    </Folha>
  );
}

// ------------------------------------------------------------------ Galões
function Galoes({ abrir }) {
  const { galoes, cfg, local, sensorDe, recarregar } = useDados();
  const [filtro, setFiltro] = useState('instalado');
  const avisar = useToast();
  const nomes = { instalado: 'Instalados', estoque: 'Em estoque', reciclagem: 'Na reciclagem' };
  const lista = galoes.filter(g => g.status === filtro).sort((a, b) => (filtro === 'instalado' ? b.nivel_pct - a.nivel_pct : a.codigo.localeCompare(b.codigo)));
  const liberar = async g => {
    try { await rpc('liberar_galao', { galao: g.id }); await recarregar(['galoes']); avisar(`${g.codigo} higienizado e de volta ao estoque.`); } catch (e) { avisar(e.message); }
  };
  return (
    <>
      <h1>Galões</h1><p className="lead">Onde está cada galão e como o sensor está calibrado.</p>
      <div className="filtros">{Object.entries(nomes).map(([k, v]) => <button key={k} aria-pressed={filtro === k} onClick={() => setFiltro(k)}>{v} ({galoes.filter(g => g.status === k).length})</button>)}</div>
      <div className="lista grade">{lista.length ? lista.map(g => {
        const d = sensorDe(g.id);
        return (
          <article className="item" key={g.id}>
            <div className="linha1"><span className="titulo mono">{g.codigo}</span>{g.status === 'instalado' ? <ChipFase nivel={g.nivel_pct} cfg={cfg} /> : g.status === 'reciclagem' ? <span className="chip neutro">Aguardando higienização</span> : <span className="chip ok">Disponível</span>}</div>
            <div className="meta">{g.status === 'instalado' ? <><b>{local(g.local_id)?.nome}</b> · {f1(litrosDe(g))} de {f0(g.capacidade_litros)} L</> : `${f0(g.capacidade_litros)} L`} · {d ? `sensor ${d.codigo}` : 'sem sensor'}</div>
            {g.status === 'instalado' && <Barra nivel={g.nivel_pct} cfg={cfg} velha={semSinal(d)} />}
            <div className="acoes">
              <button className="btn secundario pequeno" onClick={() => abrir('calibrar', { galao: g })}>Calibrar</button>
              {g.status === 'reciclagem' && <button className="btn primario pequeno" onClick={() => liberar(g)}>Devolver ao estoque</button>}
            </div>
          </article>
        );
      }) : <div className="vazio"><span>Nenhum galão nesta situação.</span></div>}</div>
      <button className="btn secundario largo" onClick={() => abrir('novo-galao')}>Cadastrar galão</button>
    </>
  );
}

// Última distância medida pelo sensor do galão; atualiza a cada nova leitura recebida.
function useUltimaMedicao(galaoId) {
  const { sensorDe } = useDados();
  const contato = sensorDe(galaoId)?.ultimo_contato_em;
  const [medicao, setMedicao] = useState(null);
  useEffect(() => {
    let ativo = true;
    supabase.from('leituras').select('distancia_cm, criado_em').eq('galao_id', galaoId).order('criado_em', { ascending: false }).limit(1)
      .then(({ data: ls }) => { if (ativo) setMedicao(ls?.[0] || null); });
    return () => { ativo = false; };
  }, [galaoId, contato]);
  return medicao;
}

function Calibrar({ galao: g, onFechar }) {
  const { recarregar, sensorDe } = useDados();
  const medicao = useUltimaMedicao(g.id);
  const [f, setF] = useState({ cap: f1(g.capacidade_litros), vazio: f1(g.distancia_vazio_cm), cheio: f1(g.distancia_cheio_cm), teste: '15,0' });
  const usar = k => setF(x => ({ ...x, [k]: f1(medicao.distancia_cm), teste: f1(medicao.distancia_cm) }));
  const { erro, setErro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const v = numBR(f.vazio), c = numBR(f.cheio), m = numBR(f.teste), cap = numBR(f.cap);
  const exemplo = v > c ? `Com essa calibração, ${f1(m)} cm medidos = ${f1(Math.min(100, Math.max(0, (v - m) / (v - c) * 100)))}% de óleo.` : 'A distância vazio precisa ser maior que a distância cheio.';
  const campo = k => ({ value: f[k], onChange: e => setF({ ...f, [k]: e.target.value }), inputMode: 'decimal', type: 'text' });
  const salvar = ev => {
    ev.preventDefault();
    if (!(v > c && c >= 0)) { setErro('A distância com o galão vazio precisa ser maior que a distância cheio.'); return; }
    if (!(cap > 0)) { setErro('Informe a capacidade em litros.'); return; }
    enviar(async () => {
      const { error } = await supabase.from('galoes').update({ capacidade_litros: cap, distancia_vazio_cm: v, distancia_cheio_cm: c }).eq('id', g.id);
      if (error) throw new Error(mensagemDeErro(error));
      await recarregar(['galoes']); onFechar(); avisar(`Calibração de ${g.codigo} salva.`);
    });
  };
  return (
    <Folha titulo={`Calibrar ${g.codigo}`} onFechar={onFechar}>
      <p style={{ margin: 0 }}>Com o sensor na tampa, meça primeiro com o galão vazio e depois com o óleo na altura que conta como cheio (abaixo do “ombro” do galão).</p>
      {sensorDe(g.id) && (
        <div className="resumo" aria-live="polite">
          <div><span>Medição atual do sensor</span><span className="num"><b>{medicao ? `${f1(medicao.distancia_cm)} cm` : '—'}</b>{medicao && <> · <Rel t={medicao.criado_em} /></>}</span></div>
          <div className="acoes" style={{ justifyContent: 'flex-end' }}>
            <button type="button" className="btn secundario pequeno" disabled={!medicao} onClick={() => usar('vazio')}>Usar como vazio</button>
            <button type="button" className="btn secundario pequeno" disabled={!medicao} onClick={() => usar('cheio')}>Usar como cheio</button>
          </div>
        </div>
      )}
      <form className="form" onSubmit={salvar}>
        <div className="campo"><label htmlFor="cal-cap">Capacidade (L)</label><input id="cal-cap" required {...campo('cap')} /></div>
        <div className="duas">
          <div className="campo"><label htmlFor="cal-vazio">Distância vazio (cm)</label><input id="cal-vazio" required {...campo('vazio')} /></div>
          <div className="campo"><label htmlFor="cal-cheio">Distância cheio (cm)</label><input id="cal-cheio" required {...campo('cheio')} /></div>
        </div>
        <div className="campo"><label htmlFor="cal-teste">Medida de teste (cm)</label><input id="cal-teste" {...campo('teste')} /><span className="ajuda">{exemplo}</span></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>Salvar calibração</button>
      </form>
    </Folha>
  );
}

function NovoGalao({ onFechar }) {
  const { galoes, recarregar } = useDados();
  const proximo = 'G-' + String(Math.max(0, ...galoes.map(g => Number(g.codigo.replace(/\D/g, '')) || 0)) + 1).padStart(3, '0');
  const [f, setF] = useState({ codigo: proximo, cap: '50' });
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const salvar = ev => {
    ev.preventDefault();
    enviar(async () => {
      const { error } = await supabase.from('galoes').insert({ codigo: f.codigo.trim(), capacidade_litros: numBR(f.cap) });
      if (error) throw new Error(/duplicate/.test(error.message) ? 'Já existe um galão com esse código.' : mensagemDeErro(error));
      await recarregar(['galoes']); onFechar(); avisar('Galão cadastrado no estoque.');
    });
  };
  return (
    <Folha titulo="Cadastrar galão" onFechar={onFechar}>
      <form className="form" onSubmit={salvar}>
        <div className="duas">
          <div className="campo"><label htmlFor="ng-cod">Código</label><input id="ng-cod" value={f.codigo} onChange={e => setF({ ...f, codigo: e.target.value })} required /></div>
          <div className="campo"><label htmlFor="ng-cap">Capacidade (L)</label><input id="ng-cap" inputMode="decimal" value={f.cap} onChange={e => setF({ ...f, cap: e.target.value })} required /></div>
        </div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>Cadastrar galão</button>
      </form>
    </Folha>
  );
}

// ------------------------------------------------------------------ Sensores
function Sensores({ abrir }) {
  const { dispositivos, galao, local, recarregar } = useDados();
  const avisar = useToast();
  const novo = async () => {
    const n = Math.max(0, ...dispositivos.map(d => Number(d.codigo.replace(/\D/g, '').slice(-2)) || 0)) + 1;
    const codigo = 'ESP32-' + dois(n);
    const { error } = await supabase.from('dispositivos').insert({ codigo });
    if (error) { avisar(mensagemDeErro(error)); return; }
    await recarregar(['dispositivos']); avisar(`${codigo} cadastrado. Gere a chave e vincule a um galão.`);
  };
  return (
    <>
      <h1>Sensores</h1><p className="lead">ESP32 com sensor ultrassônico, um por galão.</p>
      <div className="lista grade">{dispositivos.map(d => {
        const g = d.galao_id && galao(d.galao_id);
        return (
          <article className="item" key={d.id}>
            <div className="linha1"><span className="titulo mono">{d.codigo}</span><span className="meta"><span className={`ponto ${d.ultimo_contato_em ? (conectado(d) ? 'online' : 'offline') : ''}`} />{d.ultimo_contato_em ? (conectado(d) ? 'Conectado' : 'Sem sinal') : (d.galao_id ? 'Aguardando 1ª leitura' : 'Nunca conectou')}</span></div>
            <div className="meta">{g ? <>Galão <b className="mono">{g.codigo}</b>{g.local_id && <> · {local(g.local_id)?.nome}</>}</> : 'Sem galão vinculado'} · última leitura {d.ultimo_contato_em ? <Rel t={d.ultimo_contato_em} /> : '—'}</div>
            <div className="acoes">
              <button className="btn secundario pequeno" onClick={() => abrir('vincular', { sensor: d })}>{g ? 'Mudar de galão' : 'Vincular a um galão'}</button>
              <button className="btn secundario pequeno" onClick={() => abrir('chave', { sensor: d })}>Gerar chave</button>
            </div>
          </article>
        );
      })}</div>
      <button className="btn secundario largo" onClick={novo}>Cadastrar sensor</button>
    </>
  );
}

function Vincular({ sensor, onFechar }) {
  const { galoes, dispositivos, local, recarregar } = useDados();
  const ocupados = new Set(dispositivos.filter(d => d.galao_id && d.id !== sensor.id).map(d => d.galao_id));
  const opcoes = galoes.filter(g => g.status !== 'reciclagem' && !ocupados.has(g.id));
  const [galaoId, setGalaoId] = useState(sensor.galao_id || '');
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const salvar = ev => {
    ev.preventDefault();
    enviar(async () => {
      const { error } = await supabase.from('dispositivos').update({ galao_id: galaoId || null }).eq('id', sensor.id);
      if (error) throw new Error(mensagemDeErro(error));
      await recarregar(['dispositivos']); onFechar(); avisar('Vínculo salvo.');
    });
  };
  return (
    <Folha titulo={`Vincular ${sensor.codigo}`} onFechar={onFechar}>
      <form className="form" onSubmit={salvar}>
        <div className="campo"><label htmlFor="vin-g">Galão</label><select id="vin-g" value={galaoId} onChange={e => setGalaoId(e.target.value)}>
          <option value="">Nenhum (sensor guardado)</option>
          {opcoes.map(g => <option key={g.id} value={g.id}>{g.codigo} · {g.local_id ? local(g.local_id)?.nome : 'estoque'}</option>)}</select></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>Salvar vínculo</button>
      </form>
    </Folha>
  );
}

function GerarChave({ sensor, onFechar }) {
  const [chave, setChave] = useState(null);
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const online = conectado(sensor);
  const gerar = () => enviar(async () => setChave(await rpc('gerar_chave_dispositivo', { dispositivo: sensor.id })));
  const copiar = () => navigator.clipboard?.writeText(chave).then(() => avisar('Chave copiada.'), () => avisar('Selecione e copie a chave.'));
  if (chave) {
    return (
      <Folha titulo={`Chave do ${sensor.codigo}`} onFechar={onFechar}>
        <p style={{ margin: 0 }}>Grave esta chave no <span className="mono">config.py</span> do ESP32. Ela aparece só agora; a chave anterior deixou de funcionar.</p>
        <div className="chave">{chave}</div>
        <div className="botoes"><button className="btn primario flex" onClick={copiar}>Copiar chave</button><button className="btn secundario flex" onClick={onFechar}>Pronto</button></div>
      </Folha>
    );
  }
  return (
    <Folha titulo={`Gerar nova chave para o ${sensor.codigo}?`} onFechar={onFechar}>
      <p style={{ margin: 0 }}>{online
        ? `O ${sensor.codigo} está enviando leituras agora. Com a chave nova, ele para de enviar até você gravar essa chave no config.py do ESP32.`
        : 'A chave anterior, se existir, deixa de funcionar. A nova chave aparece uma única vez.'}</p>
      <Erro texto={erro} />
      <div className="botoes"><button className="btn secundario flex" onClick={onFechar}>{online ? 'Manter chave atual' : 'Agora não'}</button><button className={`btn ${online ? 'perigo' : 'primario'} flex`} onClick={gerar} disabled={enviando}>Gerar nova chave</button></div>
    </Folha>
  );
}

// ------------------------------------------------------------------ Ajustes
function Ajustes() {
  const { cfg, locais, galoes, recarregar } = useDados();
  const [f, setF] = useState({ atencao: String(cfg.limite_atencao), coleta: String(cfg.limite_coleta), valor: Number(cfg.valor_litro).toFixed(2).replace('.', ',') });
  const { erro, setErro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const salvar = ev => {
    ev.preventDefault();
    const a = numBR(f.atencao), c = numBR(f.coleta), v = numBR(f.valor);
    if (!(a > 0 && c <= 100 && a < c)) { setErro('O aviso de atenção precisa ser menor que o nível da troca automática.'); return; }
    if (!(v >= 0)) { setErro('Informe o valor por litro em reais, por exemplo 2,00.'); return; }
    enviar(async () => {
      const { error } = await supabase.from('configuracoes').update({ limite_atencao: a, limite_coleta: c, valor_litro: v }).eq('id', true);
      if (error) throw new Error(mensagemDeErro(error));
      await recarregar(['configuracoes']); avisar('Ajustes salvos.');
    });
  };
  return (
    <>
      <h1>Ajustes</h1>
      <form className="form cartao" onSubmit={salvar}>
        <div className="duas">
          <div className="campo"><label htmlFor="cfg-atencao">Aviso de atenção (%)</label><input id="cfg-atencao" inputMode="numeric" value={f.atencao} onChange={e => setF({ ...f, atencao: e.target.value })} required /></div>
          <div className="campo"><label htmlFor="cfg-coleta">Troca automática (%)</label><input id="cfg-coleta" inputMode="numeric" value={f.coleta} onChange={e => setF({ ...f, coleta: e.target.value })} required /></div>
        </div>
        <div className="campo"><label htmlFor="cfg-valor">Valor pago por litro na reciclagem (R$)</label><input id="cfg-valor" inputMode="decimal" value={f.valor} onChange={e => setF({ ...f, valor: e.target.value })} required /><span className="ajuda">Usado para estimar a receita de cada troca.</span></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>Salvar ajustes</button>
      </form>
      <h2 className="secao">Clientes atendidos</h2>
      <div className="lista grade">{locais.map(l => (
        <article className="item" key={l.id}>
          <div className="linha1"><span className="titulo">{l.nome}</span><span className="chip neutro sem-ponto">{TIPOS_LOCAL[l.tipo]}</span></div>
          <div className="meta">{endereco(l)}</div>
          <div className="meta">{l.cliente?.nome} · {l.cliente?.telefone ? <a className="num" href={linkTelefone(l.cliente.telefone)}>{l.cliente.telefone}</a> : 'sem telefone'} · {galoes.filter(g => g.local_id === l.id).length === 1 ? '1 galão' : `${galoes.filter(g => g.local_id === l.id).length} galões`}</div>
        </article>
      ))}</div>
      <button className="btn secundario largo" onClick={() => supabase.auth.signOut()}>Sair da conta</button>
    </>
  );
}
