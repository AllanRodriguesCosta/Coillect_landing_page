import { useEffect, useMemo, useState } from 'react';
import { rpc, supabase } from '../lib/supabase.js';
import { useDados } from '../lib/dados.jsx';
import { D, data, diaHora, endereco, f0, f1, ms, r1, TIPOS_LOCAL } from '../lib/formato.js';
import { aberto, faseDe, litrosDe, semSinal } from '../lib/regras.js';
import { ChipGalaoCliente, ChipStatus, Erro, Folha, Galao, Gota, Icone, Rastreio, Rel, useEnvio, useToast } from '../componentes.jsx';
import { CancelarPedido, FalarComEquipe, tituloPedido } from './Comuns.jsx';
import { Mapa } from '../mapa.jsx';

// Avisos de cancelamento já vistos ficam só neste aparelho.
const VISTOS = 'coillect-cancelamentos-vistos';
const lerVistos = () => { try { return new Set(JSON.parse(localStorage.getItem(VISTOS) || '[]')); } catch { return new Set(); } };
const salvarVistos = s => { try { localStorage.setItem(VISTOS, JSON.stringify([...s])); } catch { /* sem armazenamento: o aviso volta na próxima visita */ } };

function useAvisos(localId) {
  const { alertas, pedidos } = useDados();
  const [vistos, setVistos] = useState(lerVistos);
  const lista = useMemo(() => {
    const deAlertas = alertas.filter(a => a.local_id === localId).map(a => ({ ...a, chave: a.id, novo: !a.lido_em, quando: a.criado_em }));
    const cancelamentos = pedidos
      .filter(p => p.local_id === localId && p.status === 'cancelada' && p.cancelado_por === 'empresa' && Date.now() - ms(p.cancelada_em) < 30 * D)
      .map(p => ({ tipo: 'cancelado', pedido: p, chave: 'c' + p.id, novo: !vistos.has(p.id), quando: p.cancelada_em }));
    return [...deAlertas, ...cancelamentos].sort((a, b) => ms(b.quando) - ms(a.quando));
  }, [alertas, pedidos, localId, vistos]);
  const marcarLidos = async () => {
    const ids = lista.filter(a => a.novo && a.tipo !== 'cancelado').map(a => a.id);
    if (ids.length) await supabase.from('alertas').update({ lido_em: new Date().toISOString() }).in('id', ids);
    const novos = new Set(vistos);
    lista.filter(a => a.tipo === 'cancelado').forEach(a => novos.add(a.pedido.id));
    salvarVistos(novos); setVistos(novos);
  };
  return { lista, naoLidos: lista.filter(a => a.novo).length, marcarLidos };
}

export function Cliente({ tela }) {
  const { locais, carregado } = useDados();
  const local = locais[0];
  if (!carregado || !local) return null;
  if (tela === 'pedidos') return <Pedidos local={local} />;
  if (tela === 'historico') return <Historico local={local} />;
  if (tela === 'conta') return <Conta local={local} />;
  return <Inicio local={local} />;
}

function Inicio({ local }) {
  const { galoes, pedidos, cfg, sensorDe, recarregar } = useDados();
  const [folha, setFolha] = useState(null);
  const avisos = useAvisos(local.id);
  const meus = galoes.filter(g => g.local_id === local.id && g.status === 'instalado');
  const entrega = pedidos.find(p => p.local_id === local.id && p.tipo === 'entrega' && aberto(p));
  return (
    <>
      <header className="topo">
        <div className="marca"><small>{TIPOS_LOCAL[local.tipo]}</small><strong>{local.nome}</strong></div>
        <button className="sino" onClick={() => setFolha({ tipo: 'avisos' })} aria-label={`Avisos${avisos.naoLidos ? `, ${avisos.naoLidos} não lidos` : ''}`}>
          <Icone nome="sino" />{avisos.naoLidos > 0 && <span className="badge">{avisos.naoLidos}</span>}
        </button>
      </header>
      {!meus.length && (entrega
        ? <Rastreio pedido={entrega} cfg={cfg} />
        : <section className="cartao vazio"><strong>Você ainda não tem um galão</strong><span>Peça um galão com sensor. Nós levamos até você e instalamos.</span>
            <button className="btn primario" onClick={() => setFolha({ tipo: 'pedir-galao' })}>Pedir galão</button></section>)}
      {meus.map(g => {
        const troca = pedidos.find(p => p.galao_id === g.id && p.tipo === 'coleta' && aberto(p));
        return (
          <div key={g.id} style={{ display: 'grid', gap: 16 }}>
            <CartaoGalao galao={g} sensor={sensorDe(g.id)} />
            {troca ? <Rastreio pedido={troca} galao={g} cfg={cfg} onAjuda={() => setFolha({ tipo: 'ajuda' })} /> : <AvisoFase galao={g} />}
            {!troca && <button className="btn secundario largo" onClick={() => setFolha({ tipo: 'antecipar', galao: g })}>Antecipar a troca</button>}
          </div>
        );
      })}
      {meus.length > 0 && (entrega ? <Rastreio pedido={entrega} cfg={cfg} /> : <p className="centro"><button className="link" onClick={() => setFolha({ tipo: 'pedir-galao' })}>Pedir mais um galão</button></p>)}
      <MapaDoLocal local={local} galoes={meus} />
      <div className="dica"><Gota /><span>Despeje o óleo já frio e coado, pelo funil. Não misture água, detergente ou restos de comida.</span></div>

      {folha?.tipo === 'avisos' && <Avisos avisos={avisos} onFechar={() => setFolha(null)} />}
      {folha?.tipo === 'pedir-galao' && <PedirGalao local={local} onFechar={() => setFolha(null)} />}
      {folha?.tipo === 'antecipar' && <Antecipar local={local} galao={folha.galao} onFechar={() => setFolha(null)} recarregar={recarregar} />}
      {folha?.tipo === 'ajuda' && <FalarComEquipe localId={local.id} onFechar={() => setFolha(null)} />}
    </>
  );
}

function MapaDoLocal({ local, galoes }) {
  const { cfg, sensorDe } = useDados();
  if (local.latitude == null) return null;
  const g = [...galoes].sort((a, b) => b.nivel_pct - a.nivel_pct)[0];
  const fase = !g || semSinal(sensorDe(g.id)) ? 'neutro' : faseDe(g.nivel_pct, cfg);
  const rotulo = g ? `${f0(g.nivel_pct)}%` : local.nome;
  const pontos = [{ id: local.id, lat: Number(local.latitude), lng: Number(local.longitude), fase, rotulo, titulo: `${local.nome}${g ? `: ${rotulo}` : ''}` }];
  return (
    <section style={{ display: 'grid', gap: 8 }}>
      <h2 className="secao">Seu local no mapa</h2>
      <Mapa pontos={pontos} altura={200} rotulo={`Mapa de ${local.nome}`} />
      <span className="meta">{endereco(local)}</span>
    </section>
  );
}

function CartaoGalao({ galao, sensor }) {
  const { cfg, pedidos } = useDados();
  return (
    <>
      <section className="cartao cartao-galao">
        <Galao galao={galao} cfg={cfg} comSensor={!!sensor} />
        <div className="medida">
          <div className="codigo">Galão {galao.codigo}</div>
          <div className="pct num">{f0(galao.nivel_pct)}<small>%</small></div>
          <div className="litros num">{f1(litrosDe(galao))} L de {f0(galao.capacidade_litros)} L</div>
          <div style={{ marginTop: 8 }}><ChipGalaoCliente galao={galao} cfg={cfg} pedidos={pedidos} /></div>
          <div className="det"><span>{sensor ? (galao.ultima_leitura_em ? <>Atualizado <Rel t={galao.ultima_leitura_em} /></> : 'Aguardando a primeira leitura') : 'Sem sensor instalado'}</span></div>
        </div>
      </section>
      {sensor && (
        <details className="detalhes"><summary>Detalhes do sensor</summary>
          <div className="resumo">
            <div><span>Sensor</span><span className="mono">{sensor.codigo}</span></div>
            <div><span>Último contato</span><span><Rel t={sensor.ultimo_contato_em} /></span></div>
            <div><span>Capacidade do galão</span><span className="num">{f0(galao.capacidade_litros)} L</span></div>
          </div>
        </details>
      )}
    </>
  );
}

function AvisoFase({ galao }) {
  const { cfg, pedidos } = useDados();
  const recente = pedidos.find(p => p.tipo === 'coleta' && p.status === 'concluida' && p.galao_entregue_id === galao.id && Date.now() - ms(p.concluida_em) < D);
  if (recente && galao.nivel_pct < cfg.limite_atencao) {
    return <div className="aviso ok"><strong>Galão trocado <Rel t={recente.concluida_em} /></strong><p>{f1(recente.litros_coletados)} L do seu óleo seguiram para a reciclagem. O <span className="cod">{galao.codigo}</span> já está medindo.</p></div>;
  }
  if (faseDe(galao.nivel_pct, cfg) === 'atencao') {
    return <div className="aviso atencao"><strong>O galão passou de {cfg.limite_atencao}%</strong><p>Quando chegar a {cfg.limite_coleta}%, pedimos a troca para você.</p></div>;
  }
  return <div className="aviso ok"><strong>Tudo certo</strong><p>Cabem mais {f1(Math.max(0, galao.capacidade_litros * (cfg.limite_atencao - galao.nivel_pct) / 100))} L até o aviso de {cfg.limite_atencao}%.</p></div>;
}

function Avisos({ avisos, onFechar }) {
  const { cfg, galao, pedidos } = useDados();
  const situacao = a => {
    if (a.tipo === 'cancelado') return 'A equipe cOillect cancelou este pedido. Se ainda precisar, peça de novo pelo app.';
    if (a.resolvido_em) return `Galão trocado em ${data(a.resolvido_em)}.`;
    if (a.tipo === 'coleta') return 'Pedimos a troca para você.';
    return pedidos.some(p => p.galao_id === a.galao_id && p.tipo === 'coleta' && aberto(p)) ? 'A troca já foi pedida.' : `Quando chegar a ${cfg.limite_coleta}%, pedimos a troca para você.`;
  };
  const titulo = a => {
    if (a.tipo === 'cancelado') return `${tituloPedido(a.pedido, galao(a.pedido.galao_id))} cancelada`;
    const cod = galao(a.galao_id)?.codigo ?? '';
    return a.tipo === 'coleta' ? `Galão ${cod} chegou a ${f0(a.nivel_pct)}%` : `Galão ${cod} passou de ${cfg.limite_atencao}%`;
  };
  return (
    <Folha titulo="Avisos" onFechar={onFechar}>
      <div className="lista">
        {avisos.lista.length ? avisos.lista.map(a => (
          <article className="item" key={a.chave}>
            <div className="linha1"><span className="titulo">{titulo(a)}</span>{a.novo && <span className="chip coleta sem-ponto">Novo</span>}</div>
            <div className="meta">{situacao(a)} · <Rel t={a.quando} /></div>
          </article>
        )) : <div className="vazio"><span>Nenhum aviso por enquanto. Avisamos aqui quando o galão passar de {cfg.limite_atencao}%.</span></div>}
      </div>
      {avisos.naoLidos > 0 && <button className="btn secundario" onClick={async () => { await avisos.marcarLidos(); onFechar(); }}>Marcar todos como lidos</button>}
    </Folha>
  );
}

function PedirGalao({ local, onFechar }) {
  const { recarregar } = useDados();
  const [obs, setObs] = useState('');
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const pedir = e => {
    e.preventDefault();
    enviar(async () => {
      await rpc('solicitar', { local: local.id, tipo: 'entrega', galao: null, observacoes: obs.trim() || null });
      await recarregar(['pedidos']);
      onFechar(); avisar('Pedido enviado. A equipe cOillect vai agendar a entrega.');
    });
  };
  return (
    <Folha titulo="Pedir galão" onFechar={onFechar}>
      <p style={{ margin: 0 }}>Levamos um galão com sensor e instalamos no local. Você acompanha o nível pelo app.</p>
      <form className="form" onSubmit={pedir}>
        <div className="campo"><label htmlFor="pg-obs">Observação para a equipe (opcional)</label><textarea id="pg-obs" value={obs} onChange={e => setObs(e.target.value)} placeholder="Ex.: deixar ao lado das lixeiras da garagem" /></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>{enviando ? 'Enviando…' : 'Enviar pedido'}</button>
      </form>
    </Folha>
  );
}

function Antecipar({ local, galao, onFechar, recarregar }) {
  const { cfg } = useDados();
  const [obs, setObs] = useState('');
  const { erro, enviando, enviar } = useEnvio();
  const avisar = useToast();
  const pedir = e => {
    e.preventDefault();
    enviar(async () => {
      await rpc('solicitar', { local: local.id, tipo: 'coleta', galao: galao.id, observacoes: obs.trim() || null });
      await recarregar(['pedidos']);
      onFechar(); avisar('Troca pedida. O dia agendado aparece no Início.');
    });
  };
  return (
    <Folha titulo="Antecipar a troca" onFechar={onFechar}>
      <p style={{ margin: 0 }}>O galão {galao.codigo} está com {f1(galao.nivel_pct)}%. A troca é pedida sozinha em {cfg.limite_coleta}%, mas você pode antecipar, por exemplo antes de um evento.</p>
      <form className="form" onSubmit={pedir}>
        <div className="campo"><label htmlFor="pt-obs">Observação (opcional)</label><textarea id="pt-obs" value={obs} onChange={e => setObs(e.target.value)} placeholder="Ex.: festa no salão no sábado" /></div>
        <Erro texto={erro} />
        <button className="btn primario" type="submit" disabled={enviando}>Pedir troca</button>
      </form>
    </Folha>
  );
}

function Pedidos({ local }) {
  const { pedidos, galoes, galao } = useDados();
  const [cancelar, setCancelar] = useState(null);
  const [pedir, setPedir] = useState(false);
  const meus = pedidos.filter(p => p.local_id === local.id);
  const entrega = meus.find(p => p.tipo === 'entrega' && aberto(p));
  const temGalao = galoes.some(g => g.local_id === local.id && g.status === 'instalado');
  return (
    <>
      <h1>Pedidos</h1><p className="lead">Entregas e trocas de galão do seu local.</p>
      <div className="lista">
        {meus.length ? meus.map(p => (
          <article className="item" key={p.id}>
            <div className="linha1"><span className="titulo">{tituloPedido(p, galao(p.galao_id))}</span><ChipStatus pedido={p} perfil="cliente" /></div>
            <div className="meta">{p.origem === 'automatica' ? 'Pedido automático' : 'Pedido por você'} · {data(p.criado_em)}</div>
            {p.status === 'agendada' && <div className="meta">Agendado para <b>{diaHora(p.agendada_para)}</b></div>}
            {p.status === 'cancelada' && p.cancelado_por === 'empresa' && <div className="meta">Cancelado pela equipe cOillect</div>}
            {p.litros_coletados != null && <div className="meta num">{f1(p.litros_coletados)} L enviados para reciclagem</div>}
            {p.observacoes && <div className="meta">“{p.observacoes}”</div>}
            {p.origem === 'cliente' && aberto(p) && <div className="acoes"><button className="btn perigo pequeno" onClick={() => setCancelar(p)}>Cancelar pedido</button></div>}
          </article>
        )) : <div className="vazio"><strong>Nenhum pedido ainda</strong><span>Seus pedidos de galão e de troca aparecem aqui.</span></div>}
      </div>
      {!entrega && <button className="btn secundario largo" onClick={() => setPedir(true)}>{temGalao ? 'Pedir mais um galão' : 'Pedir galão'}</button>}
      {cancelar && <CancelarPedido pedido={cancelar} onFechar={() => setCancelar(null)} />}
      {pedir && <PedirGalao local={local} onFechar={() => setPedir(false)} />}
    </>
  );
}

function Grafico({ leituras, cfg }) {
  if (leituras.length < 2) return <div className="vazio"><span>O gráfico aparece após as primeiras leituras do sensor.</span></div>;
  const W = 330, Hh = 170, pl = 30, pr = 8, pt = 10, pb = 24;
  const t0 = ms(leituras[0].criado_em), t1 = ms(leituras.at(-1).criado_em);
  const x = t => pl + (W - pl - pr) * (t - t0) / Math.max(1, t1 - t0);
  const y = n => pt + (Hh - pt - pb) * (1 - n / 100);
  const pts = leituras.map(l => `${x(ms(l.criado_em)).toFixed(1)},${y(l.nivel_pct).toFixed(1)}`);
  const ultimo = leituras.at(-1);
  return (
    <svg viewBox={`0 0 ${W} ${Hh}`} role="img" aria-label="Nível do galão nos últimos dias">
      {[0, 50, 100].map(n => <g key={n}><line x1={pl} x2={W - pr} y1={y(n)} y2={y(n)} stroke="var(--linha)" /><text x={pl - 6} y={y(n) + 4} textAnchor="end" fontSize="10" fill="var(--texto-2)">{n}</text></g>)}
      {[[cfg.limite_atencao, 'var(--oleo-fundo)'], [cfg.limite_coleta, 'var(--ferrugem)']].map(([n, c]) => (
        <g key={n}><line x1={pl} x2={W - pr} y1={y(n)} y2={y(n)} stroke={c} strokeDasharray="4 4" /><text x={W - pr} y={y(n) - 4} textAnchor="end" fontSize="10" fill={c}>{n}%</text></g>
      ))}
      <path d={`M${x(t0)},${y(0)} L${pts.join(' L')} L${x(t1)},${y(0)} Z`} fill="var(--oleo)" opacity=".18" />
      <polyline points={pts.join(' ')} fill="none" stroke="var(--oleo-fundo)" strokeWidth="2.2" strokeLinejoin="round" />
      <circle cx={x(ms(ultimo.criado_em))} cy={y(ultimo.nivel_pct)} r="4.5" fill="var(--oleo-fundo)" stroke="var(--superficie)" strokeWidth="2" />
      <text x={pl} y={Hh - 6} fontSize="10" fill="var(--texto-2)">{data(t0)}</text>
      <text x={W - pr} y={Hh - 6} fontSize="10" textAnchor="end" fill="var(--texto-2)">hoje</text>
    </svg>
  );
}

function Historico({ local }) {
  const { reciclagens, galoes, galao, cfg } = useDados();
  const [leituras, setLeituras] = useState([]);
  const versao = galoes.filter(g => g.local_id === local.id).map(g => g.ultima_leitura_em).join();
  useEffect(() => {
    let ativo = true;
    const desde = new Date(Date.now() - 10 * D).toISOString();
    supabase.from('leituras').select('nivel_pct, criado_em').eq('local_id', local.id).gte('criado_em', desde).order('criado_em').limit(2000)
      .then(({ data: ls }) => { if (ativo && ls) setLeituras(ls); });
    return () => { ativo = false; };
  }, [local.id, versao]);
  const minhas = reciclagens.filter(r => r.local_id === local.id);
  const total = r1(minhas.reduce((a, r) => a + Number(r.litros), 0));
  const houveTroca = leituras.some((l, i) => i > 0 && leituras[i - 1].nivel_pct - l.nivel_pct > 40);
  return (
    <>
      <h1>Histórico</h1><p className="lead">Como o seu galão enche e o que já foi reciclado.</p>
      <section className="impacto">
        <span>Óleo enviado para reciclagem</span>
        <b className="num">{f1(total)} L</b>
        <p>Pela estimativa da Sabesp, cada litro de óleo jogado na pia pode contaminar até 25 mil litros de água. Por essa conta, esse óleo deixou de contaminar até {f1(total * 25 / 1000)} milhões de litros.</p>
        <small>Fonte: Sabesp (estimativa).</small>
      </section>
      <section className="cartao grafico"><h2 className="secao" style={{ margin: '0 0 8px' }}>Nível do galão nos últimos 10 dias</h2><Grafico leituras={leituras} cfg={cfg} />
        {houveTroca && <p className="legenda">A queda para perto de 0% marca uma troca de galão.</p>}</section>
      <h2 className="secao">Trocas realizadas</h2>
      <div className="lista">
        {minhas.length ? minhas.map(r => (
          <article className="item" key={r.id}><div className="linha1"><span className="titulo">Troca de {data(r.criado_em)}</span><span className="num"><b>{f1(r.litros)} L</b></span></div><div className="meta">{galao(r.galao_id) ? `Galão ${galao(r.galao_id).codigo} · ` : ''}enviados para reciclagem</div></article>
        )) : <div className="vazio"><span>A primeira troca aparece aqui depois que o galão encher.</span></div>}
      </div>
    </>
  );
}

function Conta({ local }) {
  const { perfil, sessao } = useDados();
  const [ajuda, setAjuda] = useState(false);
  return (
    <>
      <h1>Conta</h1>
      <section className="resumo">
        <div><span>Responsável</span><span>{perfil.nome}</span></div>
        <div><span>E-mail</span><span>{sessao.user.email}</span></div>
        <div><span>Telefone</span><span>{perfil.telefone || '—'}</span></div>
      </section>
      <h2 className="secao">Local atendido</h2>
      <section className="resumo">
        <div><span>Tipo</span><span>{TIPOS_LOCAL[local.tipo]}</span></div>
        <div><span>Nome</span><span>{local.nome}</span></div>
        <div><span>Endereço</span><span style={{ textAlign: 'right' }}>{endereco(local)}</span></div>
      </section>
      <button className="btn secundario largo" onClick={() => setAjuda(true)}>Falar com a cOillect</button>
      <button className="btn secundario largo" onClick={() => supabase.auth.signOut()}>Sair da conta</button>
      {ajuda && <FalarComEquipe localId={local.id} onFechar={() => setAjuda(false)} />}
    </>
  );
}
