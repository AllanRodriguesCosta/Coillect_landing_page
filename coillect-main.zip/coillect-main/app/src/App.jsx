import { useCallback, useEffect, useState } from 'react';
import { supabase } from './lib/supabase.js';
import { DadosProvider, useDados } from './lib/dados.jsx';
import { Icone, Logo, Marca, ToastProvider } from './componentes.jsx';
import { CriarConta, Entrar, NovaSenha, NovoLocal } from './telas/Acesso.jsx';
import { Cliente } from './telas/Cliente.jsx';
import { Empresa } from './telas/Empresa.jsx';
import { Carregando } from './telas/Comuns.jsx';

const NAV = {
  cliente: [['inicio', 'Início'], ['pedidos', 'Pedidos'], ['historico', 'Histórico'], ['conta', 'Conta']],
  empresa: [['painel', 'Painel'], ['pedidos', 'Pedidos'], ['galoes', 'Galões'], ['sensores', 'Sensores'], ['ajustes', 'Ajustes']],
};

// Abertura: o logo entra com uma animação curta e some quando o app já sabe se há sessão,
// nunca antes de SPLASH_MS desde o carregamento da página.
const REDUZ_MOVIMENTO = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const SPLASH_MS = REDUZ_MOVIMENTO ? 500 : 1500, SPLASH_SAIDA_MS = 400;

function Splash({ saindo }) {
  return (
    <div className={`splash${saindo ? ' saindo' : ''}`} aria-hidden="true">
      <div className="splash-halo" />
      <div className="splash-logo"><Marca altura={120} /></div>
    </div>
  );
}

export default function App() {
  const [sessao, setSessao] = useState(undefined);
  const [perfil, setPerfil] = useState(null);
  const [recuperando, setRecuperando] = useState(false);
  const [cadastro, setCadastro] = useState(false);
  const [splash, setSplash] = useState('ativa'); // 'ativa' → 'saindo' → null
  const sessaoConhecida = sessao !== undefined;

  useEffect(() => {
    if (!sessaoConhecida) return;
    const resta = Math.max(0, SPLASH_MS - performance.now());
    const t1 = setTimeout(() => setSplash('saindo'), resta);
    const t2 = setTimeout(() => setSplash(null), resta + SPLASH_SAIDA_MS);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [sessaoConhecida]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSessao(data.session));
    const { data } = supabase.auth.onAuthStateChange((evento, s) => {
      setSessao(s);
      if (evento === 'PASSWORD_RECOVERY') setRecuperando(true);
      if (evento === 'SIGNED_OUT') { setPerfil(null); setCadastro(false); }
    });
    return () => data.subscription.unsubscribe();
  }, []);

  const carregarPerfil = useCallback(async () => {
    if (!sessao) return;
    const { data } = await supabase.from('perfis').select('*').eq('id', sessao.user.id).single();
    setPerfil(data);
  }, [sessao]);
  useEffect(() => { carregarPerfil(); }, [carregarPerfil]);

  let conteudo;
  if (sessao === undefined) conteudo = <Carregando />;
  else if (recuperando && sessao) conteudo = <NovaSenha onPronto={() => setRecuperando(false)} />;
  else if (!sessao) conteudo = cadastro ? <CriarConta onVoltar={() => setCadastro(false)} /> : <Entrar onCriarConta={() => setCadastro(true)} />;
  else if (!perfil) conteudo = <Carregando />;
  else conteudo = <DadosProvider sessao={sessao} perfil={perfil}><Area /></DadosProvider>;

  return <ToastProvider><div className="app">{conteudo}{splash && <Splash saindo={splash === 'saindo'} />}</div></ToastProvider>;
}

function Area() {
  const { perfil, locais, carregado, pedidos, recarregar, sessao } = useDados();
  const papel = perfil.papel;
  const [tela, setTela] = useState(NAV[papel][0][0]);
  if (!carregado) return <Carregando />;
  if (papel === 'cliente' && !locais.length) {
    return <NovoLocal usuarioId={sessao.user.id} onCriado={() => recarregar(['locais'])} onSair={() => supabase.auth.signOut()} />;
  }
  const aAgendar = pedidos.filter(p => p.status === 'pendente').length;
  return (
    <>
      <main className={`tela${papel === 'cliente' ? ' estreita' : ''}`} key={tela}>
        {papel === 'empresa' ? <Empresa tela={tela} irPara={setTela} /> : <Cliente tela={tela} />}
      </main>
      <nav className="nav" style={{ '--n': NAV[papel].length }} aria-label="Navegação">
        <div className="nav-marca"><Logo /></div>
        {NAV[papel].map(([k, rot]) => (
          <button key={k} onClick={() => setTela(k)} aria-current={k === tela ? 'page' : undefined}>
            <Icone nome={k} /><span>{rot}</span>
            {papel === 'empresa' && k === 'pedidos' && aAgendar > 0 && <span className="badge" aria-label={`${aAgendar} a agendar`}>{aAgendar}</span>}
          </button>
        ))}
      </nav>
    </>
  );
}
