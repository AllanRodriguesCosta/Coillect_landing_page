# cOillect — aplicativo

App web mobile-first (PWA) em React + Vite, com dados do Supabase em tempo real.
A interface segue o protótipo validado em [`docs/prototipo`](../docs/prototipo/index.html).

## Rodar

```bash
cp .env.example .env.local   # preencha a chave publishable do projeto
npm install
npm run dev                  # http://localhost:5173
npm run build                # gera dist/ com o service worker do PWA
```

## Estrutura

| Arquivo | Conteúdo |
|---|---|
| `src/App.jsx` | Sessão, perfil, navegação (barra inferior no celular, menu lateral no computador) |
| `src/lib/dados.jsx` | Carrega as tabelas que o perfil pode ver e recarrega a cada mudança em tempo real |
| `src/lib/supabase.js` | Cliente Supabase e mensagens de erro em português |
| `src/lib/formato.js`, `regras.js` | Datas, números pt-BR, fases do galão e status de pedido |
| `src/componentes.jsx` | Galão (SVG), barra, selos, andamento do pedido, folha inferior, aviso rápido |
| `src/telas/` | Telas de acesso, cliente e empresa |

As regras de negócio ficam no banco (`supabase/migrations`); o app só chama as funções.
